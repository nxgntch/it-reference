# Consolidation Team Selection Guide

**Purpose**: Framework to identify the right 3 people from YOUR organization  
**Status**: Ready to use - Fill in your candidates and evaluate  
**Time to Complete**: 2-3 hours of assessment

---

## PART 1: Understand Your Candidates

### Skills Assessment Matrix

Create a table of your potential candidates with these skills:

```
Name | Python | Git | Arch | Batching | Analytics | CLI/Sync | Testing | Leadership
-----|--------|-----|------|----------|-----------|----------|---------|----------
[A]  |   9/10 |  8  |  9   |    8     |     7     |    6     |   8     |    9
[B]  |   8/10 |  9  |  6   |    9     |     8     |    7     |   7     |    5
[C]  |   7/10 |  9  |  7   |    6     |     9     |    9     |   6     |    4
```

**Scoring**: 1-10 scale
- 1-3: Beginner
- 4-6: Intermediate
- 7-8: Advanced
- 9-10: Expert

### Availability Assessment

```
Name | Can commit 2-3 hrs/day? | Has upcoming vacation? | Other projects? | Notes
-----|-------------------------|----------------------|-----------------|-------
[A]  | YES                     | None until Oct        | Minor           | Available
[B]  | MAYBE (1 other proj)    | Aug 15-22             | Major           | Tight
[C]  | YES                     | None                  | None            | Available
```

### Team Fit Assessment

```
Name | Works well with others? | Handles pressure? | Self-directed? | Communication?
-----|------------------------|-------------------|----------------|----------------
[A]  | YES                    | YES                | Strong         | Excellent
[B]  | YES                    | Maybe              | Needs guidance  | Good
[C]  | YES                    | YES                | Excellent      | Good
```

---

## PART 2: Three Team Composition Scenarios

### SCENARIO 1: "Balanced Team" (Recommended)

**Best for**: Most organizations with mixed skill levels

```
TEAM COMPOSITION:
┌─────────────────────────────────────────┐
│ Person A: Consolidation Lead            │
│ ├─ Deep Python (9/10)                   │
│ ├─ Strong leadership (9/10)             │
│ ├─ Architectural skills (9/10)          │
│ └─ Available (Full commitment)          │
│                                         │
│ Person B: Developer 1 (App Core)        │
│ ├─ Advanced Python (8/10)               │
│ ├─ Batching expertise (9/10)            │
│ ├─ Testing mindset (7/10)               │
│ └─ Available (Full commitment)          │
│                                         │
│ Person C: Developer 2 (Infrastructure)  │
│ ├─ Strong git/sync (9/10)               │
│ ├─ Advanced Python (7/10)               │
│ ├─ Can learn analytics (6/10)           │
│ └─ Available (Full commitment)          │
└─────────────────────────────────────────┘

STRENGTHS:
✅ All expert in their domain
✅ Good communication
✅ Can make autonomous decisions
✅ All fully available
✅ Diverse skill sets cover all phases

RISKS:
⚠️ Leadership only person A (no backup)

BEST SUITED FOR:
→ Teams with clear role separation
→ Organizations with deep specialists
→ High-trust collaborative culture
```

### SCENARIO 2: "Talent Development Team"

**Best for**: Growing junior talent, investing in development

```
TEAM COMPOSITION:
┌─────────────────────────────────────────┐
│ Person A: Senior Lead                   │
│ ├─ 10+ years experience                 │
│ ├─ Can mentor others                    │
│ ├─ Strong decision-making               │
│ └─ 60% time (mentoring included)        │
│                                         │
│ Person B: Mid-level Developer           │
│ ├─ 3-5 years experience                 │
│ ├─ Solid Python skills (7/10)           │
│ ├─ Eager to learn (8/10)                │
│ └─ 100% available                       │
│                                         │
│ Person C: Junior Developer              │
│ ├─ 1-2 years experience                 │
│ ├─ Python basics (6/10)                 │
│ ├─ Very eager (10/10)                   │
│ └─ 100% available                       │
└─────────────────────────────────────────┘

STRENGTHS:
✅ Clear mentorship structure
✅ Develops team capabilities
✅ Knowledge transfer happens
✅ Invests in future growth
✅ High engagement from juniors

RISKS:
⚠️ Slower initial progress (teaching overhead)
⚠️ More review burden on lead
⚠️ May need outside help on tough problems

BEST SUITED FOR:
→ Organizations investing in talent
→ Teams with growth mindset
→ 3-month+ view (not just 2 weeks)
→ Senior who enjoys mentoring
```

### SCENARIO 3: "Speed + Backup Team"

**Best for**: Organizations that need high confidence, multiple backup options

```
TEAM COMPOSITION:
┌─────────────────────────────────────────┐
│ Person A: Consolidation Lead            │
│ ├─ Expert (9/10 in all areas)           │
│ ├─ Decision-maker                       │
│ └─ 100% available                       │
│                                         │
│ Person B: Senior Developer 1            │
│ ├─ Expert in Phases 22, 23 (9/10)       │
│ ├─ Can backup Person A if needed        │
│ ├─ Can mentor Person C                  │
│ └─ 100% available                       │
│                                         │
│ Person C: Senior Developer 2            │
│ ├─ Expert in Phases 27, 26 (9/10)       │
│ ├─ Can backup Person A if needed        │
│ ├─ Can mentor Person B                  │
│ └─ 100% available                       │
└─────────────────────────────────────────┘

STRENGTHS:
✅ All experts (9+ in their domain)
✅ Multiple backups if lead unavailable
✅ Fastest execution (minimal teaching)
✅ High confidence in delivery
✅ Peer review quality high

RISKS:
⚠️ Requires 3 senior people (expensive)
⚠️ Overkill for routine execution
⚠️ May feel inefficient (over-resourced)

BEST SUITED FOR:
→ High-stakes consolidation
→ Organizations with senior bench
→ Risk-averse leadership
→ Critical production code
→ Previous consolidations went wrong
```

---

## PART 3: Evaluation Framework

### Role-Specific Candidate Assessment

#### For Team Lead Role

```
CRITICAL REQUIREMENTS:
□ Leadership experience (managed people or projects)
□ Decision-making comfort (can decide with imperfect info)
□ Communication skills (daily standups, escalations)
□ Technical depth (understands all 8 phases)
□ Availability (full 7.5 hours/week for 2 weeks)

ASSESSMENT QUESTIONS:
1. "Tell me about a time you led a technical initiative."
   ├─ Look for: Clear decision-making, team communication
   └─ Red flag: Needed constant approvals

2. "How do you handle a blocker that needs resolution in 30 minutes?"
   ├─ Look for: Framework/process, decisive action
   └─ Red flag: "I'd wait for guidance"

3. "Describe a time you had to make a trade-off decision."
   ├─ Look for: Clear thinking, accepted consequences
   └─ Red flag: Avoided decision, escalated

SCORE CALCULATION:
Technical skills: 40% (understands all code)
Leadership: 40% (can make decisions)
Availability: 20% (can commit time)
```

#### For Developer 1 Role (App Core)

```
CRITICAL REQUIREMENTS:
□ Deep Python expertise (7+ years or equivalent)
□ Understands batching concepts (or willing to learn)
□ Comfortable with refactoring large modules
□ Test-driven mindset
□ Availability (full 7.5 hours/week for 2 weeks)

ASSESSMENT QUESTIONS:
1. "Show me code you've written that consolidates duplicated logic."
   ├─ Look for: Clear refactoring approach, testing
   └─ Red flag: Left duplicated code

2. "How do you ensure tests pass during large refactors?"
   ├─ Look for: Incremental approach, test discipline
   └─ Red flag: "Just rewrite and test after"

3. "What's your experience with batch processing?"
   ├─ Look for: Some background (even if different domain)
   └─ Red flag: "Never heard of it"

SCORE CALCULATION:
Python expertise: 40% (can write solid code)
Refactoring experience: 35% (can consolidate)
Testing discipline: 25% (ensures quality)
```

#### For Developer 2 Role (Infrastructure)

```
CRITICAL REQUIREMENTS:
□ Strong git/subprocess knowledge
□ Understands repository sync operations
□ Comfortable with script-level refactoring
□ Testing mindset
□ Availability (full 5 hours/week for 2 weeks)

ASSESSMENT QUESTIONS:
1. "Describe a time you consolidated duplicate shell/Python scripts."
   ├─ Look for: Clear approach, testing strategy
   └─ Red flag: "Just delete the duplicates"

2. "What's your experience with git operations and repository sync?"
   ├─ Look for: Real hands-on experience
   └─ Red flag: "Mostly use UI tools"

3. "How would you test a consolidated git wrapper?"
   ├─ Look for: Concrete testing approach
   └─ Red flag: "Manual testing is fine"

SCORE CALCULATION:
Git/subprocess skills: 40% (core capability)
Sync operations knowledge: 35% (domain expertise)
Testing approach: 25% (quality mindset)
```

---

## PART 4: Scoring & Selection

### Candidate Scoring Sheet

```
CANDIDATE: [Name]

SECTION A: Technical Skills
  Python expertise (1-10):           ___/10
  Domain knowledge (1-10):           ___/10
  Testing mindset (1-10):            ___/10
  Subtotal (out of 30):              ___/30

SECTION B: Soft Skills
  Leadership/autonomy (1-10):        ___/10
  Communication (1-10):              ___/10
  Pressure handling (1-10):          ___/10
  Subtotal (out of 30):              ___/30

SECTION C: Availability
  Hours/week available (1-10):       ___/10
  Commitment level (1-10):           ___/10
  Subtotal (out of 20):              ___/20

TOTAL SCORE:                         ___/80

INTERVIEW NOTES:
[Add notes from interview]

RECOMMENDATION:
□ Strong candidate (70+ score)
□ Good candidate (60-69 score)
□ Consider alternatives (below 60)
```

### Selection Flowchart

```
FOR EACH CANDIDATE:

1. Score in three sections (above)
2. Total score: Add all sections
3. Evaluate against role requirements

PERSON A (Team Lead):
  Score target: 70+
  Must have: Leadership experience
  Must be: Available full-time

PERSON B (Developer 1):
  Score target: 60+
  Must have: Python expertise
  Must be: Available full-time

PERSON C (Developer 2):
  Score target: 60+
  Must have: Git/sync knowledge
  Must be: Available full-time

IF YOU DON'T HAVE 3 CANDIDATES SCORING 60+:
  → Lower bar to 55 and reassess
  → Consider training/mentoring approach
  → Extend timeline if needed
  → Ask for outside help
```

---

## PART 5: Decision Matrix

### Final Selection Template

```
CANDIDATE POOL:
┌──────────────┬────────┬────────┬──────────────┬──────────────┐
│ Name         │ Score  │ Role   │ Strengths    │ Risks        │
├──────────────┼────────┼────────┼──────────────┼──────────────┤
│ [A]          │ 75/80  │ Lead   │ Leadership   │ Part-time?   │
│ [B]          │ 68/80  │ Dev1   │ Python exp   │ New to sync  │
│ [C]          │ 70/80  │ Dev2   │ Git expert   │ Less Python  │
│ [D]          │ 62/80  │ Alt    │ Eager        │ Junior       │
│ [E]          │ 55/80  │ Alt    │ Available    │ Skill gaps   │
└──────────────┴────────┴────────┴──────────────┴──────────────┘

TOP 3 SELECTION:
✅ Person A → Team Lead (Score: 75, Fully available)
✅ Person B → Developer 1 (Score: 68, Strong Python)
✅ Person C → Developer 2 (Score: 70, Git expertise)

BACKUP OPTIONS:
⚠️ Person D → If C unavailable (junior but eager)
⚠️ Person E → If B unavailable (available but less skilled)

SELECTION RATIONALE:
- A has clear leadership and strong availability
- B brings critical Python expertise for core consolidation
- C covers infrastructure needs perfectly
- All three score above minimum threshold
- Team has complementary skills
```

---

## PART 6: Validation Checklist

Before you finalize your team, verify:

```
TEAM LEAD (Person A):
□ Has led technical projects before
□ Scores 70+ on assessment
□ Can commit 7.5 hours/week for 2 weeks
□ Comfortable making decisions with limited info
□ Available for daily standups

DEVELOPER 1 (Person B):
□ Python expertise (7+ years or equivalent)
□ Scores 60+ on assessment
□ Can commit 7.5 hours/week for 2 weeks
□ Comfortable refactoring large codebases
□ Interested in consolidation work

DEVELOPER 2 (Person C):
□ Git/subprocess expertise
□ Scores 60+ on assessment
□ Can commit 5 hours/week for 2 weeks
□ Familiar with sync operations
□ Comfortable with infrastructure code

TEAM DYNAMICS:
□ All three communicate well
□ No significant conflicts
□ Can work effectively together
□ Committed to 2-week sprint

APPROVALS:
□ Manager approves taking all 3 off other work
□ Team lead confirms availability
□ All 3 sign Team Charter
□ Kickoff scheduled for Monday
```

---

## PART 7: If You Can't Find 3 Great Candidates

### Option A: Extend the Timeline
```
If you only have 2 strong candidates:
- Extend from 2 weeks to 3-4 weeks
- Allows more mentoring of third person
- Reduces pressure on junior developer
- Better knowledge transfer

Timeline: 2 weeks → 4 weeks
Effort: 14 hours → 20 hours
```

### Option B: Bring in Outside Support
```
If you have 2 strong + 1 weak:
- Keep your 2 strongest full-time
- Hire contractor/consultant for weak area
- Cost: ~$5-10k for 2 weeks
- Benefit: Guaranteed execution + knowledge transfer
```

### Option C: Defer Non-Critical Phases
```
If you only have 2 candidates:
- Do Phases 22-26 (Application core) with 2 people
- Defer Phases 27-29 (Infrastructure) to next month
- Allows hiring/finding third person
- Phase 27-29 can be backfilled later
```

---

## NEXT STEPS

1. **Fill in your candidate list** (Name, Skills, Availability)
2. **Interview each candidate** (Use questions provided)
3. **Score each candidate** (Use scoring sheet)
4. **Select top 3** (Use decision matrix)
5. **Get commitments** (Have them sign Team Charter)
6. **Schedule kickoff** (Pick a Monday)

---

**How to Use This Guide**:

1. Print or copy the assessment tables
2. List all potential candidates (5-10 people)
3. Score each one (15 min per person)
4. Interview top 5 (15 min each = 75 min)
5. Make final selection (30 min analysis)
6. Present to team (1 hour onboarding)

**Total time: 3-4 hours to identify and commit your team**

---

**Once you have your 3 people:**

1. Have them read: CONSOLIDATION_QUICK_REFERENCE.md
2. Have them review: Their phase implementation spec
3. Have them sign: CONSOLIDATION_TEAM_CHARTER.md
4. Schedule: Monday 9:00 AM kickoff
5. Run: python scripts/consolidation/health_check_complete.py

**Then you're ready to execute.**
