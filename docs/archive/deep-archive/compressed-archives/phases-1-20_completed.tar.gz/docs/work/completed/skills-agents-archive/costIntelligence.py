"""Cost intelligence skill for agents.
Advanced cost analysis and impact forecasting for director routing decisions.
Used by director agent to understand cost implications before routing tasks.
"""

from dataclasses import dataclass
from typing import Any, Dict, List, Optional


@dataclass
class CostImpact:
    """Cost impact analysis result"""

    estimated_cost: float
    confidence: float  # 0-1
    cost_drivers: List[str]
    optimization_opportunity: Optional[str]
    budget_impact: str  # minimal, moderate, significant, critical
    recommendation: str


class CostIntelligenceSkill:
    """Analyze cost implications of tasks and routing decisions."""

    def __init__(self, cost_tracker=None, dashboard_registry=None):
        """Initialize cost intelligence skill.
        Args:
           cost_tracker: CostTracker for historical spending analysis
           dashboard_registry: DashboardRegistry for cost metrics and trends
        """
        self.cost_tracker = cost_tracker
        self.dashboard_registry = dashboard_registry

    def forecastCostImpact(
        self,
        task_description: str,
        estimated_complexity: str,
        team_id: str,
        agent_id: str,
    ) -> CostImpact:
        """Forecast cost impact of executing a task.
        Args:
           task_description: Description of task to execute
           estimated_complexity: low, medium, high, critical
           team_id: Team that would execute task
           agent_id: Agent that would execute task
        Returns:
           CostImpact with estimated cost and recommendation
        """
        # Estimate cost based on complexity and historical data
        complexity_multipliers = {
            "low": 0.5,
            "medium": 1.0,
            "high": 2.5,
            "critical": 5.0,
        }

        multiplier = complexity_multipliers.get(estimated_complexity, 1.0)

        # Base cost varies by team (research is cheaper, engineering more expensive)
        team_base_costs = {
            "engineering": 50.0,
            "research": 30.0,
            "operations": 40.0,
            "security": 60.0,
            "architecture": 70.0,
        }

        base_cost = team_base_costs.get(team_id, 45.0)
        estimated_cost = base_cost * multiplier

        # Identify cost drivers
        cost_drivers = self._identifyCostDrivers(task_description, estimated_complexity, team_id)

        # Determine budget impact
        budget_impact = self._calculateBudgetImpact(estimated_cost)

        # Find optimization opportunity
        optimization = self._findOptimizationOpportunity(task_description, estimated_complexity)

        # Generate recommendation
        recommendation = self._generateCostRecommendation(
            estimated_cost, budget_impact, optimization
        )

        return CostImpact(
            estimated_cost=estimated_cost,
            confidence=0.7 + (0.2 if optimization else 0),
            cost_drivers=cost_drivers,
            optimization_opportunity=optimization,
            budget_impact=budget_impact,
            recommendation=recommendation,
        )

    def identifyOptimizationOpportunities(
        self,
        agent_id: str,
        recent_tasks: List[Dict[str, Any]],
        lookback_days: int = 30,
    ) -> Dict[str, Any]:
        """Identify cost optimization opportunities for an agent.
        Args:
           agent_id: Agent to analyze
           recent_tasks: List of recent task executions
           lookback_days: Days to analyze
        Returns:
           Dict with opportunities, savings potential, and priority
        """
        if not recent_tasks:
            return {
                "opportunities": [],
                "total_savings_potential": 0,
                "priority": "none",
            }

        # Calculate cost statistics
        costs = [t.get("cost", 0) for t in recent_tasks]
        if not costs:
            return {
                "opportunities": [],
                "total_savings_potential": 0,
                "priority": "none",
            }

        avg_cost = sum(costs) / len(costs)
        max(costs)

        opportunities = []

        # Check for expensive outliers
        expensive_tasks = [t for t in recent_tasks if t.get("cost", 0) > avg_cost * 2]
        if expensive_tasks:
            opportunities.append(
                {
                    "type": "expensive_outliers",
                    "count": len(expensive_tasks),
                    "potential_savings": max(
                        0,
                        sum(t.get("cost", 0) for t in expensive_tasks)
                        - avg_cost * len(expensive_tasks),
                    ),
                    "recommendation": "Optimize expensive task patterns or use cheaper models",
                }
            )

        # Check for inefficient task patterns
        low_efficiency_tasks = [
            t
            for t in recent_tasks
            if t.get("output_tokens", 0) > 0
            and t.get("cost", 0) / max(1, t.get("output_tokens", 1)) > avg_cost / 100
        ]
        if low_efficiency_tasks:
            opportunities.append(
                {
                    "type": "low_efficiency",
                    "count": len(low_efficiency_tasks),
                    "potential_savings": sum(t.get("cost", 0) for t in low_efficiency_tasks) * 0.2,
                    "recommendation": "Review prompt engineering to reduce token usage",
                }
            )

        # Check for repetitive work
        task_descriptions = [t.get("description", "") for t in recent_tasks]
        unique_descriptions = len(set(task_descriptions))
        if unique_descriptions < len(task_descriptions) * 0.5:
            opportunities.append(
                {
                    "type": "repetitive_work",
                    "count": len(task_descriptions) - unique_descriptions,
                    "potential_savings": avg_cost
                    * (len(task_descriptions) - unique_descriptions)
                    * 0.3,
                    "recommendation": "Cache or batch similar tasks",
                }
            )

        total_savings = sum(o.get("potential_savings", 0) for o in opportunities)
        priority = (
            "high"
            if total_savings > avg_cost * 10
            else "medium" if total_savings > avg_cost * 5 else "low"
        )

        return {
            "opportunities": opportunities,
            "total_savings_potential": total_savings,
            "priority": priority,
            "agent_avg_cost": avg_cost,
        }

    def predictBudgetRisk(
        self,
        team_id: str,
        current_spend: float,
        monthly_budget: float,
        days_elapsed: int,
        planned_tasks: Optional[List[Dict[str, Any]]] = None,
    ) -> Dict[str, Any]:
        """Predict budget risk based on planned tasks.
        Args:
           team_id: Team identifier
           current_spend: Current month spending
           monthly_budget: Monthly budget limit
           days_elapsed: Days elapsed in month
           planned_tasks: Upcoming tasks with estimated costs
        Returns:
           Risk assessment with probability of overspend
        """
        days_remaining = 30 - days_elapsed
        if days_remaining <= 0:
            days_remaining = 1

        # Project current trajectory
        daily_rate = current_spend / days_elapsed if days_elapsed > 0 else 0
        projected_baseline = current_spend + (daily_rate * days_remaining)

        # Add planned task costs
        planned_cost_total = 0
        if planned_tasks:
            planned_cost_total = sum(t.get("estimated_cost", 0) for t in planned_tasks)

        projected_total = projected_baseline + planned_cost_total
        remaining_budget = monthly_budget - current_spend - planned_cost_total

        # Calculate risk probability
        if projected_total > monthly_budget:
            overspend_amount = projected_total - monthly_budget
            overspend_percentage = (overspend_amount / monthly_budget) * 100
            risk_probability = min(0.99, 0.5 + (overspend_percentage / 100))
            risk_level = "critical" if overspend_percentage > 10 else "high"
        else:
            buffer_percentage = (remaining_budget / monthly_budget) * 100
            risk_probability = max(0.01, 0.3 - (buffer_percentage / 100))
            risk_level = "low" if buffer_percentage > 20 else "medium"

        return {
            "risk_level": risk_level,
            "risk_probability": risk_probability,
            "projected_total_spend": projected_total,
            "monthly_budget": monthly_budget,
            "overspend_amount": max(0, projected_total - monthly_budget),
            "remaining_buffer": max(0, remaining_budget),
            "recommendation": self._generateRiskRecommendation(risk_level, remaining_budget),
        }

    def _identifyCostDrivers(
        self,
        task_description: str,
        complexity: str,
        team_id: str,
    ) -> List[str]:
        """Identify factors driving task cost.
        Returns:
           List of cost drivers
        """
        drivers = []

        if complexity == "critical":
            drivers.append("High complexity (critical tier)")
        elif complexity == "high":
            drivers.append("High complexity (high tier)")

        if team_id in ["engineering", "architecture", "security"]:
            drivers.append("Specialized team (higher rate)")

        if len(task_description) > 500:
            drivers.append("Complex task description")

        if any(
            keyword in task_description.lower() for keyword in ["design", "architecture", "system"]
        ):
            drivers.append("Architectural work")

        if not drivers:
            drivers.append("Standard complexity")

        return drivers

    def _calculateBudgetImpact(self, estimated_cost: float) -> str:
        """Calculate budget impact level.
        Returns:
           Impact level
        """
        if estimated_cost > 500:
            return "critical"
        elif estimated_cost > 200:
            return "significant"
        elif estimated_cost > 50:
            return "moderate"
        else:
            return "minimal"

    def _findOptimizationOpportunity(
        self,
        task_description: str,
        complexity: str,
    ) -> Optional[str]:
        """Find optimization opportunity for task.
        Returns:
           Optimization suggestion or None
        """
        if complexity == "critical":
            return "Consider breaking into smaller subtasks to reduce complexity"

        if len(task_description) > 1000:
            return "Simplify task description to reduce token usage"

        if "analysis" in task_description.lower() and complexity == "high":
            return "Use cheaper model (haiku) for initial analysis phase"

        return None

    def _generateCostRecommendation(
        self,
        estimated_cost: float,
        budget_impact: str,
        optimization: Optional[str],
    ) -> str:
        """Generate cost-based recommendation.
        Returns:
           Recommendation string
        """
        if budget_impact == "critical":
            return "PROCEED WITH CAUTION: High cost. Consider optimization before routing."

        if optimization:
            return f"Recommended optimization: {optimization}. Would reduce cost significantly."

        if budget_impact == "significant":
            return "Cost is significant. Ensure task justifies expense."

        return "Cost is reasonable. Proceed with routing."

    def _generateRiskRecommendation(
        self,
        risk_level: str,
        remaining_buffer: float,
    ) -> str:
        """Generate risk mitigation recommendation.
        Returns:
           Recommendation string
        """
        if risk_level == "critical":
            return (
                "URGENT: High probability of budget overspend. Pause non-critical work immediately."
            )

        if risk_level == "high":
            return f"WARNING: Budget risk high. Only ${remaining_buffer:.2f} buffer remaining. Prioritize critical work only."

        if risk_level == "medium":
            return f"CAUTION: ${remaining_buffer:.2f} remaining. Monitor costs closely and optimize where possible."

        return (
            f"Budget healthy. ${remaining_buffer:.2f} buffer available. Proceed with planned work."
        )


def costIntelligence(
    cost_tracker=None,
    dashboard_registry=None,
) -> CostIntelligenceSkill:
    """Factory function for dependency injection.
    Usage in any agent:
       from skills.agents.costIntelligence import costIntelligence
       skill = costIntelligence(cost_tracker, dashboard_registry)
       impact = skill.forecastCostImpact(task, complexity, team, agent)
    """
    return CostIntelligenceSkill(
        cost_tracker=cost_tracker,
        dashboard_registry=dashboard_registry,
    )
