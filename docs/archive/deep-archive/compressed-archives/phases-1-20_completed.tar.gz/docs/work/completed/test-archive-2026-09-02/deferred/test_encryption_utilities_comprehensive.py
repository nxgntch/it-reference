"""Comprehensive encryption and utilities test suite.

Phase 4.16 Consolidation:
- test_encryption.py
- test_batching.py
- test_deduplication_helpers_coverage.py

All encryption and utility tests consolidated.
"""

"""Tests for encryption module."""

import pytest

from tests.utilities.assertionHelpers import (
    assertConditionMet,
    assertListLength,
    assertMetricValue,
)

pytestmark = pytest.mark.heavy

from app.core.encryption import (
    EncryptionManager,
    KeyRotationManager,
    decryptCostData,
    decryptSessionData,
    encryptCostData,
    encryptSessionData,
)

class TestEncryptionManager:
    """Test encryption manager."""

    def setup_method(self):
        """Set up test fixtures."""
        self.manager = EncryptionManager("test-key-for-testing")

    def testEncryptDecryptString(self):
        """Test encrypting and decrypting strings."""
        plaintext = "sensitive-data-12345"
        encrypted = self.manager.encrypt(plaintext)

        assert encrypted != plaintext
        assert len(encrypted) > len(plaintext)

        decrypted = self.manager.decrypt(encrypted)
        assert decrypted == plaintext

    def testEncryptDecryptCost(self):
        """Test encrypting and decrypting cost values."""
        cost = 123.45
        encrypted = self.manager.encrypt(f"{cost:.2f}")

        decrypted = float(self.manager.decrypt(encrypted))
        assert decrypted == cost

    def testEncryptEmptyString(self):
        """Test encrypting empty string."""
        plaintext = ""
        encrypted = self.manager.encrypt(plaintext)

        decrypted = self.manager.decrypt(encrypted)
        assert decrypted == plaintext

    def testEncryptLongString(self):
        """Test encrypting long string."""
        plaintext = "x" * 10000
        encrypted = self.manager.encrypt(plaintext)

        decrypted = self.manager.decrypt(encrypted)
        assert decrypted == plaintext

    def testDecryptInvalidCiphertext(self):
        """Test decrypting invalid ciphertext."""
        with pytest.raises(Exception):
            self.manager.decrypt("invalid-base64-!!!!")

    def testEncryptDataDict(self):
        """Test encrypting dictionary fields."""
        data = {
            "username": "alice",
            "cost": "100.50",
            "apiKey": "sk-abc123",
            "public": "visible",
        }

        encrypted = self.manager.encryptDataDict(data, ["cost", "apiKey"])

        assert encrypted["username"] == "alice"  # Not encrypted
        assert encrypted["public"] == "visible"  # Not encrypted
        assert encrypted["cost"] != "100.50"  # Encrypted
        assert encrypted["apiKey"] != "sk-abc123"  # Encrypted

        # Decrypt
        decrypted = self.manager.decryptDataDict(encrypted, ["cost", "apiKey"])
        assert decrypted["cost"] == "100.50"
        assert decrypted["apiKey"] == "sk-abc123"

    def testEncryptDataDictWithNone(self):
        """Test encrypting dictionary with None values."""
        data = {
            "cost": None,
            "name": "test",
        }

        encrypted = self.manager.encryptDataDict(data, ["cost", "name"])
        assert encrypted["cost"] is None  # Not encrypted
        assert encrypted["name"] != "test"  # Encrypted

    def testConsistentEncryption(self):
        """Test that same plaintext produces different ciphertexts."""
        plaintext = "same-data"

        encrypted1 = self.manager.encrypt(plaintext)
        encrypted2 = self.manager.encrypt(plaintext)

        # Different ciphertexts (due to Fernet timestamp)
        assert encrypted1 != encrypted2

        # Both decrypt to same plaintext
        assert self.manager.decrypt(encrypted1) == plaintext
        assert self.manager.decrypt(encrypted2) == plaintext

    def testDifferentKeysProduceDifferentCiphers(self):
        """Test that different keys produce different encrypted data."""
        manager1 = EncryptionManager("key1")
        manager2 = EncryptionManager("key2")

        plaintext = "sensitive"

        encrypted1 = manager1.encrypt(plaintext)
        encrypted2 = manager2.encrypt(plaintext)

        assert encrypted1 != encrypted2
        assert manager1.decrypt(encrypted1) == plaintext

        # Cannot decrypt with wrong key
        with pytest.raises(Exception):
            manager2.decrypt(encrypted1)

class TestKeyRotationManager:
    """Test key rotation manager."""

    def setup_method(self):
        """Set up test fixtures."""
        import tempfile

        self.tempDir = tempfile.mkdtemp()
        self.rotationManager = KeyRotationManager(self.tempDir)

    def teardown_method(self):
        """Clean up test fixtures."""
        import shutil

        shutil.rmtree(self.tempDir, ignore_errors=True)

    def testRotateKey(self):
        """Test key rotation."""
        record = self.rotationManager.rotateKey("new-key", "scheduled")

        assert record["status"] == "active"
        assert record["reason"] == "scheduled"
        assert "timestamp" in record
        assert "newKeyHash" in record
        assert len(record["newKeyHash"]) == 16

    def testRotationHistory(self):
        """Test getting rotation history."""
        self.rotationManager.rotateKey("key1", "scheduled")
        self.rotationManager.rotateKey("key2", "compromise")
        self.rotationManager.rotateKey("key3", "quarterly")

        history = self.rotationManager.getRotationHistory()

        assert len(history) == 3
        assert history[0]["reason"] == "quarterly"  # Most recent first
        assert history[1]["reason"] == "compromise"
        assert history[2]["reason"] == "scheduled"

    def testRotationRecordNotIncludesKey(self):
        """Test that rotation record doesn't store actual key."""
        self.rotationManager.rotateKey("super-secret-key-12345", "test")

        history = self.rotationManager.getRotationHistory()
        record = history[0]

        # Key hash is only 16 chars (first 16 of sha256)
        assert "super-secret-key" not in str(record)
        assert len(record["newKeyHash"]) == 16

class TestGlobalEncryptionFunctions:
    """Test global encryption functions."""

    def testEncryptDecryptCostData(self):
        """Test cost encryption functions."""
        cost = 456.78

        encrypted = encryptCostData(cost)
        decrypted = decryptCostData(encrypted)

        assert decrypted == cost

    def testEncryptZeroCost(self):
        """Test encrypting zero cost."""
        cost = 0.0

        encrypted = encryptCostData(cost)
        decrypted = decryptCostData(encrypted)

        assert decrypted == cost

    def testEncryptLargeCost(self):
        """Test encrypting large cost."""
        cost = 999999.99

        encrypted = encryptCostData(cost)
        decrypted = decryptCostData(encrypted)

        assert abs(decrypted - cost) < 0.01  # Allow float rounding

    def testDecryptInvalidCost(self):
        """Test decrypting invalid cost."""
        decrypted = decryptCostData("invalid-ciphertext")

        assert decrypted == 0.0

class TestSessionEncryption:
    """Test session data encryption."""

    def testEncryptSessionData(self):
        """Test encrypting session data."""
        session = {
            "sessionId": "sess-123",
            "userId": "user-456",
            "apiKey": "sk-abc123xyz",
            "teamId": "team-789",
            "credentials": '{"username": "alice"}',
            "publicData": "visible",
            "timestamp": 1234567890,
        }

        encrypted = encryptSessionData(session)

        # Sensitive fields encrypted
        assert encrypted["userId"] != "user-456"
        assert encrypted["apiKey"] != "sk-abc123xyz"
        assert encrypted["teamId"] != "team-789"
        assert encrypted["credentials"] != '{"username": "alice"}'

        # Public fields not encrypted
        assert encrypted["sessionId"] == "sess-123"
        assert encrypted["publicData"] == "visible"
        assert encrypted["timestamp"] == 1234567890

    def testDecryptSessionData(self):
        """Test decrypting session data."""
        original = {
            "userId": "user-123",
            "apiKey": "sk-secret-key",
            "teamId": "team-abc",
            "sessionId": "sess-xyz",
        }

        encrypted = encryptSessionData(original)
        decrypted = decryptSessionData(encrypted)

        assert decrypted["userId"] == "user-123"
        assert decrypted["apiKey"] == "sk-secret-key"
        assert decrypted["teamId"] == "team-abc"
        assert decrypted["sessionId"] == "sess-xyz"

    def testSessionEncryptionWithNullFields(self):
        """Test session encryption with None fields."""
        session = {
            "userId": "user-123",
            "apiKey": None,
            "teamId": "team-456",
            "credentials": None,
        }

        encrypted = encryptSessionData(session)

        # None values not encrypted
        assert encrypted["apiKey"] is None
        assert encrypted["credentials"] is None
        assert encrypted["userId"] != "user-123"

    def testSAMLAssertionEncryption(self):
        """Test SAML assertion encryption."""
        session = {
            "samlAssertion": "<saml:Assertion>complex-xml-data</saml:Assertion>",
            "sessionId": "sess-123",
        }

        encrypted = encryptSessionData(session)

        assert encrypted["samlAssertion"] != "<saml:Assertion>complex-xml-data</saml:Assertion>"
        assert encrypted["sessionId"] == "sess-123"

        decrypted = decryptSessionData(encrypted)
        assert decrypted["samlAssertion"] == "<saml:Assertion>complex-xml-data</saml:Assertion>"

@pytest.mark.security
class TestEncryptionSecurity:
    """Security-focused encryption tests."""

    def testNoPlaintextInEncrypted(self):
        """Test that plaintext doesn't appear in ciphertext."""
        manager = EncryptionManager("test-key")
        plaintext = "api-key-abc123xyz"

        encrypted = manager.encrypt(plaintext)

        assert plaintext not in encrypted
        assert "api-key" not in encrypted
        assert "abc123" not in encrypted

    def testKeyDerivationConsistency(self):
        """Test that same key always produces same cipher."""
        key = "my-stable-key"
        manager1 = EncryptionManager(key)
        manager2 = EncryptionManager(key)

        plaintext = "test-data"

        encrypted1 = manager1.encrypt(plaintext)
        encrypted2 = manager2.encrypt(plaintext)

        # Different due to Fernet timestamp, but both decrypt correctly
        assert manager1.decrypt(encrypted1) == plaintext
        assert manager2.decrypt(encrypted2) == plaintext
        assert manager1.decrypt(encrypted2) == plaintext  # Can decrypt other's

    def testNoKeyMaterialInEncrypted(self):
        """Test that key material isn't present in encrypted data."""
        key = "super-secret-encryption-key-12345"
        manager = EncryptionManager(key)

        plaintext = "data"
        encrypted = manager.encrypt(plaintext)

        assert key not in encrypted
        assert "secret" not in encrypted.lower()

    def testSessionDataNoLeakage(self):
        """Test that session data encryption prevents leakage."""
        session = {
            "userId": "user-sensitive-data-12345",
            "apiKey": "sk-production-key-xyz",
            "teamId": "team-confidential",
        }

        encrypted = encryptSessionData(session)

        # Verify no plaintext appears
        for value in encrypted.values():
            if isinstance(value, str):
                assert "user-sensitive" not in value
                assert "production-key" not in value
                assert "confidential" not in value
"""Tests for batch processing, optimization, and query batching.

Consolidated from:
- testBatchProcessor.py (batch task management and processing)
- testBatchSizeOptimizer.py (batch size optimization and query batching)
"""

import asyncio
from unittest.mock import AsyncMock, patch

import pytest

from app.core.batchExecution import BatchExecutionMixin
from app.core.batchFormationCache import (
    BatchFormationCache,
    CachedFormation,
    getFormationCache,
)
from app.core.batchProcessor import (
    Batch,
    BatchProcessor,
    BatchTask,
    getProcessor,
)
from app.core.batchSizeOptimizer import BatchSizeOptimizer, getOptimizer
from app.core.batchStats import BatchStatsMixin

try:
    from app.core.singletonFactory import getBatcher
    from app.db.queryBatcher import QueryBatcher

    HAS_QUERY_BATCHER = True
except ImportError:
    HAS_QUERY_BATCHER = False

# ============================================================================
# SECTION 1: BATCH PROCESSING TESTS
# ============================================================================

class TestBatchTask:
    """Test BatchTask creation and hashing."""

    def testCreateBatchTask(self):
        """Test creating a batch task."""
        task = BatchTask(
            taskId="task_1",
            agentId="architect",
            description="Design a system",
            complexity="high",
            estimatedCost=0.05,
            model="claude-opus-5",
        )

        assert task.taskId == "task_1"
        assert task.agentId == "architect"
        assert task.complexity == "high"
        assert task.model == "claude-opus-5"

    def testBatchTaskHash(self):
        """Test batch task hashing for similarity."""
        task1 = BatchTask(
            taskId="task_1",
            agentId="architect",
            description="Design a system",
            complexity="high",
            estimatedCost=0.05,
            model="claude-opus-5",
        )

        task2 = BatchTask(
            taskId="task_2",
            agentId="architect",
            description="Design another system",
            complexity="high",
            estimatedCost=0.04,
            model="claude-opus-5",
        )

        # Same agent/complexity/model = same hash
        assert task1.hash() == task2.hash()

    def testBatchTaskHashDifference(self):
        """Test that different agents produce different hashes."""
        task1 = BatchTask(
            taskId="task_1",
            agentId="architect",
            description="Design",
            complexity="high",
            estimatedCost=0.05,
            model="claude-opus-5",
        )

        task2 = BatchTask(
            taskId="task_2",
            agentId="engineer",
            description="Design",
            complexity="high",
            estimatedCost=0.05,
            model="claude-opus-5",
        )

        # Different agent = different hash
        assert task1.hash() != task2.hash()

class TestBatch:
    """Test Batch creation and management."""

    def testCreateEmptyBatch(self):
        """Test creating an empty batch."""
        batch = Batch(batchId="batch_1")
        assert len(batch.tasks) == 0
        assert batch.status == "pending"

    def testAddTaskToBatch(self):
        """Test adding tasks to a batch."""
        batch = Batch(batchId="batch_1")
        task = BatchTask(
            taskId="task_1",
            agentId="architect",
            description="Design",
            complexity="high",
            estimatedCost=0.05,
            model="claude-opus-5",
        )

        success = batch.addTask(task)
        assert success is True
        assert len(batch.tasks) == 1
        assert batch.agentId == "architect"
        assert batch.complexity == "high"

    def testAddIncompatibleTaskToBatch(self):
        """Test adding incompatible task to batch."""
        batch = Batch(batchId="batch_1")
        task1 = BatchTask(
            taskId="task_1",
            agentId="architect",
            description="Design",
            complexity="high",
            estimatedCost=0.05,
            model="claude-opus-5",
        )

        task2 = BatchTask(
            taskId="task_2",
            agentId="engineer",  # Different agent
            description="Code",
            complexity="high",
            estimatedCost=0.02,
            model="claude-haiku-4.5",
        )

        batch.addTask(task1)
        success = batch.addTask(task2)

        assert success is False  # Should not add
        assert len(batch.tasks) == 1  # Still only 1 task

    def testBatchCostCalculation(self):
        """Test batch cost calculations."""
        batch = Batch(batchId="batch_1")

        tasks = [
            BatchTask(
                taskId=f"task_{i}",
                agentId="architect",
                description="Design",
                complexity="high",
                estimatedCost=0.05,
                model="claude-opus-5",
            )
            for i in range(3)
        ]

        for task in tasks:
            batch.addTask(task)

        assert batch.getTotalCost() == pytest.approx(0.15, rel=1e-9)
        assert len(batch.tasks) == 3

    def testBatchSavingsCalculation(self):
        """Test batch savings estimation."""
        batch = Batch(batchId="batch_1")

        # Add 3 tasks
        for i in range(3):
            task = BatchTask(
                taskId=f"task_{i}",
                agentId="architect",
                description="Design",
                complexity="high",
                estimatedCost=0.05,
                model="claude-opus-5",
            )
            batch.addTask(task)

        # Savings should be (3-1) * 5% = 10%
        savingsPercent = batch.getSavingsPercentage()
        assert savingsPercent == 0.10
        assert batch.getEstimatedSavings() == pytest.approx(0.015, rel=1e-3)

    def testBatchMetrics(self):
        """Test batch metrics generation."""
        batch = Batch(batchId="batch_1")

        tasks = [
            BatchTask(
                taskId=f"task_{i}",
                agentId="architect",
                description="Design",
                complexity="high",
                estimatedCost=0.05,
                model="claude-opus-5",
            )
            for i in range(3)
        ]

        for task in tasks:
            batch.addTask(task)

        metrics = batch.getMetrics()

        assert metrics["batchId"] == "batch_1"
        assert metrics["taskCount"] == 3
        assert metrics["agentId"] == "architect"
        assert metrics["totalEstimatedCost"] == 0.15
        assert metrics["savingsPercentage"] == 10.0
        assert metrics["status"] == "pending"

class TestBatchProcessor:
    """Test BatchProcessor functionality."""

    def testCreateBatchProcessor(self):
        """Test processor initialization."""
        processor = BatchProcessor()
        assert processor.MAX_BATCH_SIZE == 50
        assert len(processor.queueManager.pendingBatches) == 0
        assert processor.getCounter("batches_created") == 0

    def testCreateBatchTask(self):
        """Test creating batch task with router."""
        processor = BatchProcessor()

        task = processor.createBatchTask(
            taskId="task_1",
            agentId="architect",
            description="Design a system",
        )

        assert task.taskId == "task_1"
        assert task.agentId == "architect"
        assert task.model is not None  # Should be routed to a model
        assert task.estimatedCost > 0

    def testAddTaskToBatch(self):
        """Test adding task to batch."""
        processor = BatchProcessor()

        task = processor.createBatchTask(
            taskId="task_1",
            agentId="architect",
            description="Design a system",
        )

        batchId, isNew = processor.addTaskToBatch(task)

        assert isNew is True  # First task creates new batch
        assert batchId in [b.batchId for b in processor.queueManager.pendingBatches.values()]
        assert processor._batchStats["batchesCreated"] == 1

    def testAddMultipleTasksToBatch(self):
        """Test adding multiple compatible tasks to same batch."""
        processor = BatchProcessor()

        tasks = [
            processor.createBatchTask(
                taskId=f"task_{i}",
                agentId="architect",
                description="Design a system",
            )
            for i in range(3)
        ]

        batchIds = []
        for task in tasks:
            batchId, _isNew = processor.addTaskToBatch(task)
            batchIds.append(batchId)

        # All 3 should go to same batch
        assert len(set(batchIds)) == 1  # All same batch ID
        assert processor._batchStats["batchesCreated"] == 1

    def testBatchProcessing(self):
        """Test processing a batch."""
        processor = BatchProcessor()

        # Create and add 3 tasks
        for i in range(3):
            task = processor.createBatchTask(
                taskId=f"task_{i}",
                agentId="architect",
                description="Design a system",
            )
            processor.addTaskToBatch(task)

        # Get batch ID
        batch = next(iter(processor.queueManager.pendingBatches.values()))
        batchId = batch.batchId

        # Process batch
        result = processor.processBatch(batchId)

        assert result["status"] == "completed"
        assert result["batchId"] == batchId
        assert result["metrics"]["taskCount"] == 3
        assert result["metrics"]["savingsPercentage"] > 0

    def testSuggestBatching(self):
        """Test batching suggestions for task list."""
        processor = BatchProcessor()

        # Create 5 tasks
        tasks = [
            processor.createBatchTask(
                taskId=f"task_{i}",
                agentId="architect",
                description="Design a system",
            )
            for i in range(5)
        ]

        suggestions = processor.suggestBatching(tasks)

        assert len(suggestions) > 0
        assert sum(len(b.tasks) for b in suggestions) == 5

    def testProcessorStatistics(self):
        """Test processor statistics tracking."""
        processor = BatchProcessor()

        # Create and process a batch
        for i in range(3):
            task = processor.createBatchTask(
                taskId=f"task_{i}",
                agentId="architect",
                description="Design a system",
            )
            processor.addTaskToBatch(task)

        batch = next(iter(processor.queueManager.pendingBatches.values()))
        processor.processBatch(batch.batchId)

        stats = processor.getStatistics()

        assert stats["batchesCreated"] >= 1
        assert stats["totalItems"] >= 3
        assert stats["estimatedTotalSavings"] >= 0
        assert stats["averageSavingsPercentage"] >= 0

    def testGetPendingBatches(self):
        """Test retrieving pending batches."""
        processor = BatchProcessor()

        # Create 2 batches
        task1 = processor.createBatchTask(
            taskId="task_1",
            agentId="architect",
            description="Design a system",
        )
        processor.addTaskToBatch(task1)

        task2 = processor.createBatchTask(
            taskId="task_2",
            agentId="engineer",
            description="Write code",
        )
        processor.addTaskToBatch(task2)

        pending = processor.getPendingBatches()

        assert len(pending) >= 1
        for batch in pending:
            assert "batchId" in batch
            assert "taskCount" in batch
            assert "totalEstimatedCost" in batch

class TestBatchOptimization:
    """Test batch optimization benefits."""

    def testCostSavingsPerBatchSize(self):
        """Test that larger batches have better savings."""
        processor = BatchProcessor()

        # Create batches of different sizes
        for batchSize in [1, 5, 10, 50]:
            processor.reset()

            for i in range(batchSize):
                task = processor.createBatchTask(
                    taskId=f"task_{i}",
                    agentId="architect",
                    description="Design a system",
                )
                processor.addTaskToBatch(task)

            batch = next(iter(processor.queueManager.pendingBatches.values()))
            savings = batch.getSavingsPercentage()

            # Larger batch = more savings (but capped at 15%)
            assert savings >= 0

    def testBatchSingleton(self):
        """Test batch processor singleton."""
        proc1 = getProcessor()
        proc2 = getProcessor()

        assert proc1 is proc2

@pytest.mark.asyncio
async def testIntegrationBatchWithOrchestrator():
    """Test batch processing integration with orchestrator."""
    from app.core.orchestrator import Orchestrator

    orchestrator = Orchestrator()

    # Create batch tasks
    taskIds = []
    for i in range(3):
        batchId = orchestrator.createBatchTask(
            taskId=f"task_{i}",
            agentId="architect",
            description="Design a system",
        )
        taskIds.append(batchId)

    # All should go to same batch
    assert len(set(taskIds)) == 1

    # Get stats
    stats = orchestrator.getBatchProcessorStats()
    assert stats["totalItems"] >= 3

@pytest.fixture
def asyncProcessor():
    """Create test batch processor for async tests."""
    return BatchProcessor(configPath=None)

@pytest.mark.asyncio
async def testAddTaskToBatchAsync(asyncProcessor):
    """Test adding task to batch asynchronously."""
    task = BatchTask(
        taskId="task1",
        agentId="architect",
        description="Design a system",
        complexity="high",
        estimatedCost=0.5,
        model="claude-opus-5",
    )

    batchId, isNew = await asyncProcessor.addTaskToBatchAsync(task)

    assert batchId is not None
    assert isNew is True
    assert task.taskId == "task1"

@pytest.mark.asyncio
async def testProcessBatchAsync(asyncProcessor):
    """Test processing batch asynchronously."""
    # Add tasks to batch first
    for i in range(3):
        task = BatchTask(
            taskId=f"task{i}",
            agentId="architect",
            description="Design",
            complexity="high",
            estimatedCost=0.5,
            model="claude-opus-5",
        )
        batchId, _ = asyncProcessor.addTaskToBatch(task)

    # Process batch asynchronously
    result = await asyncProcessor.processBatchAsync(batchId)

    assert result["status"] == "completed"
    assert result["batchId"] == batchId
    assert result["metrics"]["taskCount"] == 3

@pytest.mark.asyncio
async def testProcessMultipleBatchesConcurrently(asyncProcessor):
    """Test processing multiple batches concurrently."""
    # Create multiple batches
    batchIds = []
    for batchNum in range(3):
        for taskNum in range(2):
            task = BatchTask(
                taskId=f"batch{batchNum}_task{taskNum}",
                agentId="architect",
                description="Design",
                complexity="high",
                estimatedCost=0.5,
                model="claude-opus-5",
            )
            batchId, isNew = asyncProcessor.addTaskToBatch(task)
            if isNew:
                batchIds.append(batchId)

    # Process all batches concurrently
    startTime = asyncio.get_event_loop().time()
    results = await asyncProcessor.processBatchesAsync(batchIds)
    duration = asyncio.get_event_loop().time() - startTime

    assert len(results) == len(batchIds)
    assert all(r["status"] == "completed" for r in results)
    # Concurrent should be faster than sequential
    assert duration < 0.5  # Should complete quickly

@pytest.mark.asyncio
async def testAsyncTaskQueueIntegration(asyncProcessor):
    """Test async task queue is available for future use."""
    # Verify the queue exists and is awaitable
    assert hasattr(asyncProcessor, "asyncTaskQueue")
    assert isinstance(asyncProcessor.asyncTaskQueue, asyncio.Queue)

@pytest.mark.asyncio
async def testConcurrentBatchProcessingPerformance():
    """Benchmark concurrent batch processing performance."""
    processor = BatchProcessor(configPath=None)

    # Create many tasks in separate batches
    batchIds = []
    for i in range(10):
        task = BatchTask(
            taskId=f"task{i}",
            agentId="architect",
            description="Design",
            complexity="high",
            estimatedCost=0.5,
            model="claude-opus-5",
        )
        batchId, isNew = processor.addTaskToBatch(task)
        if isNew:
            batchIds.append(batchId)

    # Sequential processing simulation (baseline)
    sequentialStart = asyncio.get_event_loop().time()
    for batchId in batchIds:
        processor.processBatch(batchId)
    sequentialDuration = asyncio.get_event_loop().time() - sequentialStart

    # Concurrent processing
    processor.reset()  # Reset for fair comparison
    batchIds = []
    for i in range(10):
        task = BatchTask(
            taskId=f"task{i}",
            agentId="architect",
            description="Design",
            complexity="high",
            estimatedCost=0.5,
            model="claude-opus-5",
        )
        batchId, isNew = processor.addTaskToBatch(task)
        if isNew:
            batchIds.append(batchId)

    concurrentStart = asyncio.get_event_loop().time()
    results = await processor.processBatchesAsync(batchIds)
    concurrentDuration = asyncio.get_event_loop().time() - concurrentStart

    # Concurrent should be significantly faster for many batches
    assert len(results) == len(batchIds)
    assert concurrentDuration < sequentialDuration or concurrentDuration < 0.1

# ============================================================================
# SECTION 2: BATCH SIZE OPTIMIZATION AND QUERY BATCHING TESTS
# ============================================================================

class TestBatchSizeOptimizer:
    """Test suite for BatchSizeOptimizer."""

    def setup_method(self):
        """Set up fresh optimizer for each test."""
        self.optimizer = BatchSizeOptimizer()

    def testCalculateOptimalSizeSmallWorkload(self):
        """Test batch size calculation for small workload (<10 tasks)."""
        minSize, maxSize = self.optimizer.calculateOptimalSize(5)
        assert minSize == 2
        assert maxSize == 3

    def testCalculateOptimalSizeMediumWorkload(self):
        """Test batch size calculation for medium workload (10-50 tasks)."""
        minSize, maxSize = self.optimizer.calculateOptimalSize(25)
        assert minSize == 5
        assert maxSize == 8

    def testCalculateOptimalSizeLargeWorkload(self):
        """Test batch size calculation for large workload (>50 tasks)."""
        minSize, maxSize = self.optimizer.calculateOptimalSize(100)
        assert minSize == 10
        assert maxSize == 15

    def testCalculateOptimalSizeEdgeCases(self):
        """Test batch size calculation at boundary conditions."""
        # Boundary: small -> medium
        assert self.optimizer.calculateOptimalSize(9) == (2, 3)
        assert self.optimizer.calculateOptimalSize(10) == (5, 8)

        # Boundary: medium -> large
        assert self.optimizer.calculateOptimalSize(49) == (5, 8)
        assert self.optimizer.calculateOptimalSize(50) == (10, 15)

    def testCalculateOptimalSizeWithHighEfficacy(self):
        """Test that high efficacy allows larger batch sizes."""
        taskMetrics = {"efficacy": 4.5}
        minSize, maxSize = self.optimizer.calculateOptimalSize(25, taskMetrics)
        # Should have increased maxSize slightly
        assert minSize == 5
        assert maxSize > 8

    def testCalculateOptimalSizeWithLowEfficacy(self):
        """Test that low efficacy reduces batch sizes."""
        taskMetrics = {"efficacy": 1.5}
        minSize, maxSize = self.optimizer.calculateOptimalSize(25, taskMetrics)
        # Should have decreased minSize
        assert minSize < 5
        assert maxSize == 8

    def testEvaluateBatchFormattingHighRoi(self):
        """Test ROI calculation for effective batching (ROI > 1.0)."""
        roi = self.optimizer.evaluateBatchFormatting(
            batchSize=5, formationCost=2.5, executionBenefit=15.0
        )
        assert roi == pytest.approx(6.0)
        stats = self.optimizer.getStats()
        assert stats["batchesEvaluated"] == 1
        assert stats["roiGreaterThanOne"] == 1

    def testEvaluateBatchFormattingLowRoi(self):
        """Test ROI calculation for ineffective batching (ROI < 1.0)."""
        roi = self.optimizer.evaluateBatchFormatting(
            batchSize=2, formationCost=10.0, executionBenefit=8.0
        )
        assert roi == pytest.approx(0.8)
        stats = self.optimizer.getStats()
        assert stats["batchesEvaluated"] == 1
        assert stats["roiGreaterThanOne"] == 0

    def testEvaluateBatchFormattingZeroCost(self):
        """Test ROI with zero formation cost (edge case)."""
        roi = self.optimizer.evaluateBatchFormatting(
            batchSize=5, formationCost=0.0, executionBenefit=15.0
        )
        assert roi == 0.0

    def testEvaluateBatchFormattingTracksHistory(self):
        """Test that batch evaluation is tracked in history."""
        self.optimizer.evaluateBatchFormatting(5, 2.5, 15.0)  # ROI = 6.0
        self.optimizer.evaluateBatchFormatting(3, 1.5, 5.0)  # ROI = 3.33
        self.optimizer.evaluateBatchFormatting(8, 3.0, 20.0)  # ROI = 6.67

        assert len(self.optimizer.history) == 3
        stats = self.optimizer.getStats()
        assert stats["batchesEvaluated"] == 3
        assert stats["roiGreaterThanOne"] == 3  # All three have ROI > 1.0

    def testEvaluateBatchFormattingAverageRoi(self):
        """Test average ROI calculation across multiple batches."""
        self.optimizer.evaluateBatchFormatting(5, 2.5, 15.0)  # ROI = 6.0
        self.optimizer.evaluateBatchFormatting(3, 2.0, 10.0)  # ROI = 5.0

        # Average ROI = (15.0 + 10.0) / (2.5 + 2.0) = 25.0 / 4.5 ≈ 5.56
        stats = self.optimizer.getStats()
        assert stats["averageRoi"] == pytest.approx(5.56, rel=0.1)

    def testHistoryMaxSize(self):
        """Test that history is capped at 1000 entries."""
        # Add 1100 entries
        for _i in range(1100):
            self.optimizer.evaluateBatchFormatting(5, 2.0, 10.0)

        # History should be trimmed to last 1000
        assert len(self.optimizer.history) == 1000

    def testGetOptimalSizeHistoryEmpty(self):
        """Test getting history when no batches evaluated."""
        result = self.optimizer.getOptimalSizeHistory()
        assert result["history"] == []
        assert "No batch data yet" in result["recommendations"]

    def testGetOptimalSizeHistoryWithData(self):
        """Test getting history with batch data."""
        self.optimizer.evaluateBatchFormatting(5, 2.5, 15.0)
        self.optimizer.evaluateBatchFormatting(8, 3.0, 20.0)

        result = self.optimizer.getOptimalSizeHistory()
        assert len(result["history"]) == 2
        assert result["stats"]["totalBatches"] == 2
        assert result["stats"]["effectivePercentage"] == 100.0

    def testRecommendationsLowEffectiveRate(self):
        """Test recommendations when effective rate is low."""
        # Create low-ROI batches (< 50% effective)
        for _ in range(6):
            self.optimizer.evaluateBatchFormatting(2, 10.0, 8.0)  # ROI = 0.8
        for _ in range(4):
            self.optimizer.evaluateBatchFormatting(5, 2.0, 5.0)  # ROI = 2.5

        result = self.optimizer.getOptimalSizeHistory()
        assert "Low effective batch rate" in result["recommendations"]

    def testRecommendationsHighEffectiveRate(self):
        """Test recommendations when effective rate is high."""
        # Create high-ROI batches (> 90% effective = 19/20)
        for _i in range(19):
            self.optimizer.evaluateBatchFormatting(5, 2.0, 10.0)  # ROI = 5.0
        self.optimizer.evaluateBatchFormatting(2, 10.0, 8.0)  # ROI = 0.8 (only 1 low-ROI)

        result = self.optimizer.getOptimalSizeHistory()
        assert "High effective batch rate" in result["recommendations"]
        assert "larger batch sizes" in result["recommendations"]

    def testRecommendationsExcellentRoi(self):
        """Test recommendations when ROI is excellent (> 5.0)."""
        for _ in range(5):
            self.optimizer.evaluateBatchFormatting(5, 1.0, 7.0)  # ROI = 7.0

        result = self.optimizer.getOptimalSizeHistory()
        assert "Excellent ROI" in result["recommendations"]

    def testRecommendationsLowRoi(self):
        """Test recommendations when ROI is low (< 2.0)."""
        for _ in range(5):
            self.optimizer.evaluateBatchFormatting(2, 5.0, 8.0)  # ROI = 1.6

        result = self.optimizer.getOptimalSizeHistory()
        assert "Low ROI" in result["recommendations"]

    def testReset(self):
        """Test resetting optimizer state."""
        self.optimizer.evaluateBatchFormatting(5, 2.5, 15.0)
        self.optimizer.evaluateBatchFormatting(3, 2.0, 10.0)

        assert len(self.optimizer.history) == 2
        stats = self.optimizer.getStats()
        assert stats["batchesEvaluated"] == 2

        self.optimizer.reset()

        assert len(self.optimizer.history) == 0
        stats = self.optimizer.getStats()
        assert stats["batchesEvaluated"] == 0
        assert stats["averageRoi"] == 0.0

    def testGetStats(self):
        """Test getting current statistics."""
        self.optimizer.evaluateBatchFormatting(5, 2.5, 15.0)
        self.optimizer.evaluateBatchFormatting(3, 2.0, 10.0)

        stats = self.optimizer.getStats()
        assert stats["batchesEvaluated"] == 2
        assert stats["roiGreaterThanOne"] == 2
        assert stats["historyLength"] == 2

    def testSingletonPattern(self):
        """Test that getOptimizer returns same instance."""
        opt1 = getOptimizer()
        opt2 = getOptimizer()
        assert opt1 is opt2

    def testSingletonPersistsData(self):
        """Test that singleton persists data across calls."""
        opt1 = getOptimizer()
        opt1.evaluateBatchFormatting(5, 2.5, 15.0)

        opt2 = getOptimizer()
        assert len(opt2.history) == 1

    def testMultipleBatchEvaluations(self):
        """Test evaluating multiple batches with varying characteristics."""
        batches = [
            (2, 1.0, 3.0),  # ROI = 3.0
            (5, 2.5, 15.0),  # ROI = 6.0
            (8, 3.0, 20.0),  # ROI = 6.67
            (10, 5.0, 15.0),  # ROI = 3.0
            (3, 2.0, 8.0),  # ROI = 4.0
        ]

        for batchSize, formationCost, executionBenefit in batches:
            self.optimizer.evaluateBatchFormatting(batchSize, formationCost, executionBenefit)

        stats = self.optimizer.getStats()
        assert stats["batchesEvaluated"] == 5
        assert stats["roiGreaterThanOne"] == 5
        # Average ROI = (3 + 6 + 6.67 + 3 + 4) / (1 + 2.5 + 3 + 5 + 2) = 22.67 / 13.5 ≈ 1.68
        assert stats["averageRoi"] > 1.0

    def testCategorizeWorkload(self):
        """Test internal workload categorization."""
        assert self.optimizer._categorizeWorkload(5) == "small"
        assert self.optimizer._categorizeWorkload(10) == "medium"
        assert self.optimizer._categorizeWorkload(50) == "large"
        assert self.optimizer._categorizeWorkload(100) == "large"

pytestmark = pytest.mark.skipif(not HAS_QUERY_BATCHER, reason="QueryBatcher not available")

@pytest.fixture
def batcher():
    """Create test query batcher."""
    return QueryBatcher(maxBatchSize=3)

@pytest.fixture
def mockSession():
    """Create mock async database session."""
    return AsyncMock()

@pytest.mark.asyncio
async def testExecuteBatchedOperations(batcher, mockSession):
    """Test executing multiple operations in single session."""

    async def op1(session):
        await asyncio.sleep(0.01)
        return "result1"

    async def op2(session):
        await asyncio.sleep(0.01)
        return "result2"

    async def op3(session):
        await asyncio.sleep(0.01)
        return "result3"

    batchResults = await batcher.executeBatch([op1, op2, op3], mockSession)

    assert len(batchResults) == 3
    assert batchResults == ["result1", "result2", "result3"]
    stats = batcher.getStats()
    assert stats["batches_executed"] == 1
    assert stats["operations_batched"] == 3
    assert stats["pool_connections_saved"] == 2  # 3 ops - 1 connection

@pytest.mark.asyncio
async def testPendingBatchManagement(batcher):
    """Test adding to and executing pending batches."""

    async def getCosts(session):
        return {"cost": 100}

    async def getTeams(session):
        return {"teams": ["eng", "ops"]}

    # Add operations to pending batch
    batcher.addToPendingBatch(getCosts, "queries")
    batcher.addToPendingBatch(getTeams, "queries")

    # Check pending count
    assert batcher.getPendingBatchCount() == 2

    # Verify not yet executed
    stats = batcher.getStats()
    assert stats["batches_executed"] == 0

    # Execute pending batch
    mockSession = AsyncMock()
    results = await batcher.executePendingBatch("queries", mockSession)

    # Verify execution
    assert len(results) == 2
    stats = batcher.getStats()
    assert stats["batches_executed"] == 1

@pytest.mark.asyncio
async def testBatchTriggerOnMaxSize(batcher):
    """Test batch execution triggers at max size."""

    async def operation(session):
        return "ok"

    # Add operations up to max size
    shouldExecute1 = batcher.addToPendingBatch(operation, "test")
    assert shouldExecute1 is False

    shouldExecute2 = batcher.addToPendingBatch(operation, "test")
    assert shouldExecute2 is False

    # This one should trigger (reaches max size of 3)
    shouldExecute3 = batcher.addToPendingBatch(operation, "test")
    assert shouldExecute3 is True

@pytest.mark.asyncio
async def testFlushAllPendingBatches(batcher):
    """Test flushing all pending batches at once."""

    async def op(session):
        return "result"

    # Add to multiple batch groups
    batcher.addToPendingBatch(op, "group1")
    batcher.addToPendingBatch(op, "group2")
    batcher.addToPendingBatch(op, "group3")

    mockSession = AsyncMock()
    results = await batcher.flushAll(mockSession)

    assert len(results) == 3
    assert all(g in results for g in ["group1", "group2", "group3"])
    assert batcher.getPendingBatchCount() == 0

@pytest.mark.asyncio
async def testConnectionPoolSavings(batcher):
    """Test calculation of connection pool savings."""

    async def operation(session):
        return "ok"

    # Create batches with 5 operations each
    mockSession = AsyncMock()
    operations = [operation for _ in range(5)]

    await batcher.executeBatch(operations, mockSession)

    stats = batcher.getStatistics()

    # 5 operations = 5 connections without batching, 1 with batching
    # Savings = 4 connections
    assert stats["pool_connections_saved"] == 4
    assert stats["operations_batched"] == 5
    assert stats["average_operations_per_batch"] == 5.0

@pytest.mark.asyncio
async def testErrorHandlingInBatch(batcher):
    """Test batch continues on operation error."""

    async def goodOp(session):
        return "success"

    async def badOp(session):
        raise ValueError("Operation failed")

    mockSession = AsyncMock()
    results = await batcher.executeBatch([goodOp, badOp, goodOp], mockSession)

    # Should have 3 results: good, None (error), good
    assert len(results) == 3
    assert results[0] == "success"
    assert results[1] is None  # Error caught
    assert results[2] == "success"

@pytest.mark.asyncio
async def testExecuteWithConnectionManagement(batcher):
    """Test automatic session management."""

    async def operation(session):
        # Verify session is provided
        assert session is not None
        return "ok"

    mockSession = AsyncMock()

    # Create async context manager class
    class SessionContext:
        async def __aenter__(self):
            return mockSession

        async def __aexit__(self, *args):
            pass

    def getSession():
        # Return mock session as context manager (not async)
        return SessionContext()

    results = await batcher.executeWithConnection([operation], getSession)

    assert len(results) == 1
    assert results[0] == "ok"

def testBatcherSingleton():
    """Test batcher singleton pattern."""
    batcher1 = getBatcher()
    batcher2 = getBatcher()

    assert batcher1 is batcher2

@pytest.mark.asyncio
async def testBatcherReset(batcher):
    """Test batcher state reset."""

    async def op(session):
        return "ok"

    mockSession = AsyncMock()

    # Execute batch
    await batcher.executeBatch([op, op, op], mockSession)

    stats = batcher.getStats()
    assert stats["batches_executed"] == 1
    assert stats["operations_batched"] == 3

    # Reset
    batcher.reset()

    stats = batcher.getStats()
    assert stats["batches_executed"] == 0
    assert stats["operations_batched"] == 0
    assert batcher.getPendingBatchCount() == 0

@pytest.mark.asyncio
async def testPoolEfficiencyMetrics(batcher):
    """Test pool efficiency statistics."""

    async def op(session):
        return "ok"

    mockSession = AsyncMock()

    # Execute 2 batches of 4 operations each
    await batcher.executeBatch([op, op, op, op], mockSession)
    await batcher.executeBatch([op, op, op, op], mockSession)

    stats = batcher.getStatistics()

    # 8 operations in 2 batches = 6 connections saved (8 - 2)
    assert stats["operations_batched"] == 8
    assert stats["batches_executed"] == 2
    assert stats["pool_connections_saved"] == 6
    assert stats["savings_percent"] == 75.0  # 6 saved out of 8 total
    assert stats["average_operations_per_batch"] == 4.0

# ============================================================================
# PHASE 6: TIER 3 PARAMETRIZATION - BATCHING
# ============================================================================

class TestBatchingParametrized:
    """Parametrized batching tests (Tier 3 pattern)."""

    @pytest.mark.parametrize(
        "batchId,operationCount,isValid",
        [
            ("batch-001", 1, True),
            ("batch-002", 2, True),
            ("batch-003", 4, True),
            ("batch-004", 8, True),
        ],
        ids=["single", "2op", "4op", "8op"],
    )
    def testBatchCreationVariations(self, batchId, operationCount, isValid):
        """Test batch creation with various configurations (parametrized)."""
        batch = Batch(batchId=batchId)
        assert batch.batchId == batchId
        assert isValid

    @pytest.mark.parametrize(
        "complexity,expectedModel,estimatedCost",
        [
            ("simple", "claude-haiku-4.5", 0.01),
            ("medium", "claude-sonnet-5", 0.05),
            ("high", "claude-opus-5", 0.15),
            ("critical", "claude-opus-5", 0.25),
        ],
        ids=["simple", "medium", "high", "critical"],
    )
    def testTaskComplexityRouting(self, complexity, expectedModel, estimatedCost):
        """Test task routing by complexity (parametrized)."""
        task = BatchTask(
            taskId="task-001",
            agentId="test",
            description="test task",
            complexity=complexity,
            estimatedCost=estimatedCost,
            model=expectedModel,
        )
        assert task.complexity == complexity
        assert task.model == expectedModel
        assert task.estimatedCost == estimatedCost

    @pytest.mark.asyncio
    @pytest.mark.parametrize(
        "opCount,poolSize,savingsPercent",
        [
            (2, 2, 0.0),
            (4, 2, 50.0),
            (8, 2, 75.0),
            (10, 2, 80.0),
        ],
        ids=["no-save", "50pct", "75pct", "80pct"],
    )
    async def testBatchingEfficiency(self, opCount, poolSize, savingsPercent):
        """Test batching efficiency calculations (parametrized)."""
        # Simulate batching: opCount operations with poolSize connections
        # Savings = (opCount - poolSize) / opCount * 100
        if opCount > poolSize:
            actual_savings = (opCount - poolSize) / opCount * 100
            assert abs(actual_savings - savingsPercent) < 0.1
        else:
            assert savingsPercent == 0.0

    @pytest.mark.parametrize(
        "optimizerId,agentId,complexity",
        [
            ("opt-001", "architect", "high"),
            ("opt-002", "engineer", "medium"),
            ("opt-003", "researcher", "high"),
            ("opt-004", "manager", "low"),
        ],
        ids=["opt1", "opt2", "opt3", "opt4"],
    )
    def testBatchSizeOptimization(self, optimizerId, agentId, complexity):
        """Test batch size optimization (parametrized)."""
        BatchSizeOptimizer()
        # Verify optimizer works with different agent types and complexities
        assert optimizerId
        assert agentId in ["architect", "engineer", "researcher", "manager"]
        assert complexity in ["low", "medium", "high"]

@pytest.mark.skipif(not HAS_QUERY_BATCHER, reason="QueryBatcher not available")
class TestQueryBatcherEdgeCases:
    """Test QueryBatcher edge cases for missing coverage."""

    @pytest.mark.asyncio
    async def testExecuteBatchWithEmptyOperations(self):
        """Test executeBatch with empty operations list."""
        batcher = QueryBatcher()
        mockSession = AsyncMock()

        # ACT
        results = await batcher.executeBatch([], mockSession)

        # ASSERT
        assert results == []
        assert batcher.getCounter("batches_executed") == 0

    @pytest.mark.asyncio
    async def testExecuteWithConnectionAndEmptyOperations(self):
        """Test executeWithConnection with empty operations list."""
        batcher = QueryBatcher()

        async def mockGetSession():
            mock = AsyncMock()
            mock.__aenter__.return_value = AsyncMock()
            mock.__aexit__.return_value = None
            return mock

        # ACT
        results = await batcher.executeWithConnection([], mockGetSession)

        # ASSERT
        assert results == []

    @pytest.mark.asyncio
    async def testExecutePendingBatchWithEmptyBatch(self):
        """Test executePendingBatch with no pending operations."""
        batcher = QueryBatcher()
        mockSession = AsyncMock()

        # ACT
        results = await batcher.executePendingBatch("nonexistent-key", mockSession)

        # ASSERT
        assert results == []

    def testGetBatchKeyWithCallableWithoutName(self):
        """Test _getBatchKey with callable that has no __name__ attribute."""
        batcher = QueryBatcher()

        # Create a callable without __name__
        class CallableObject:
            async def __call__(self, session):
                pass

        operation = CallableObject()

        # ACT
        key = batcher._getBatchKey(operation)

        # ASSERT - should fallback to str(operation)
        assert key is not None
        assert isinstance(key, str)

    def testGetBatchKeyWithRegularFunction(self):
        """Test _getBatchKey with regular function."""
        batcher = QueryBatcher()

        async def myOperation(session):
            pass

        # ACT
        key = batcher._getBatchKey(myOperation)

        # ASSERT
        assert key == "myOperation"

# ============================================================================
# SECTION 3: BATCH PROCESSOR GAP COVERAGE (Consolidated from gap file)
# ============================================================================

class TestBatchSavingsEdgeCases:
    """Test edge cases in batch savings calculations."""

    def testSavingsPercentageWithNoTasks(self):
        """Test getSavingsPercentage with empty batch (line 108)."""
        batch = Batch(batchId="batch-1")
        result = batch.getSavingsPercentage()
        assert result == 0.0

    def testSavingsPercentageWithMultipleTasks(self):
        """Test getSavingsPercentage calculation."""
        batch = Batch(batchId="batch-1")
        for i in range(3):
            task = BatchTask(
                taskId=f"task-{i}",
                agentId="agent-1",
                description=f"Task {i}",
                estimatedCost=10.0,
                complexity="medium",
                model="claude-sonnet-5",
            )
            batch.addTask(task)
        # 3 tasks give (3-1) * 5% = 10%
        result = batch.getSavingsPercentage()
        assert result == 0.10

class TestProcessBatchesPipelined:
    """Test processBatchesPipelined method (lines 496-540)."""

    def testProcessBatchesPipelinedEmptyTasks(self):
        """Test with empty task list (line 496-497)."""
        processor = BatchProcessor()
        result = processor.processBatchesPipelined([])

        assert result["status"] == "empty"
        assert result["tasks_processed"] == 0
        assert result["batches_processed"] == 0

    def testProcessBatchesPipelinedWithTasks(self):
        """Test processBatchesPipelined with actual tasks."""
        processor = BatchProcessor()
        tasks = []
        for i in range(3):
            task = BatchTask(
                taskId=f"task-{i}",
                agentId=f"agent-{i}",
                description=f"Task {i}",
                estimatedCost=10.0 + i,
                complexity="medium",
                model="claude-sonnet-5",
            )
            tasks.append(task)

        result = processor.processBatchesPipelined(tasks)

        assert result["status"] == "completed"
        assert result["tasks_processed"] == 3
        assert result["batches_processed"] >= 1
        assert "successful" in result
        assert "skipped" in result

class TestBatchProcessorAsyncMethods:
    """Test async batch processor methods."""

    @pytest.mark.asyncio
    async def testAddTaskToBatchAsync(self):
        """Test async task addition."""
        processor = BatchProcessor()
        task = BatchTask(
            taskId="task-1",
            agentId="agent-1",
            description="Test",
            estimatedCost=10.0,
            complexity="medium",
            model="claude-sonnet-5",
        )

        result = await processor.addTaskToBatchAsync(task)
        assert result is not None

    @pytest.mark.asyncio
    async def testProcessBatchAsync(self):
        """Test async batch processing."""
        processor = BatchProcessor()

        # Create batch
        batch = Batch(batchId="batch-1")
        batch.addTask(
            BatchTask(
                taskId="task-1",
                agentId="agent-1",
                description="Test",
                estimatedCost=10.0,
                complexity="medium",
                model="claude-sonnet-5",
            )
        )
        processor.queueManager.pendingBatches["batch-1"] = batch

        # Process async
        result = await processor.processBatchAsync("batch-1")
        assert result is not None

    @pytest.mark.asyncio
    async def testProcessBatchesAsync(self):
        """Test async processing of multiple batches."""
        processor = BatchProcessor()

        # Create batches
        for i in range(2):
            batch = Batch(batchId=f"batch-{i}")
            batch.addTask(
                BatchTask(
                    taskId=f"task-{i}",
                    agentId="agent-1",
                    description=f"Test {i}",
                    estimatedCost=10.0,
                    complexity="medium",
                    model="claude-sonnet-5",
                )
            )
            processor.queueManager.pendingBatches[f"batch-{i}"] = batch

        result = await processor.processBatchesAsync(["batch-0", "batch-1"])
        assert result is not None
        assert isinstance(result, list)

class TestBatchProcessorUtilities:
    """Test batch processor utility methods."""

    def testShutdown(self):
        """Test shutdown method (lines 605-607)."""
        processor = BatchProcessor()
        # Should not raise
        processor.shutdown()

    def testGetOptimizationMetrics(self):
        """Test getOptimizationMetrics (line 615)."""
        processor = BatchProcessor()

        # Add some tasks
        tasks = []
        for i in range(2):
            task = BatchTask(
                taskId=f"task-{i}",
                agentId="agent-1",
                description=f"Task {i}",
                estimatedCost=10.0,
                complexity="medium",
                model="claude-sonnet-5",
            )
            tasks.append(task)

        processor.processBatchesPipelined(tasks)

        metrics = processor.getOptimizationMetrics()
        assert isinstance(metrics, dict)

    def testBatchProcessorReset(self):
        """Test reset clears pending batches."""
        processor = BatchProcessor()

        batch = Batch(batchId="batch-1")
        batch.addTask(
            BatchTask(
                taskId="task-1",
                agentId="agent-1",
                description="Test",
                estimatedCost=10.0,
                complexity="medium",
                model="claude-sonnet-5",
            )
        )
        processor.queueManager.pendingBatches["batch-1"] = batch

        assert len(processor.queueManager.pendingBatches) > 0
        processor.reset()
        assert len(processor.queueManager.pendingBatches) == 0

    def testGetStatistics(self):
        """Test getStatistics returns processor stats."""
        processor = BatchProcessor()
        stats = processor.getStatistics()
        assert isinstance(stats, dict)

# ============================================================================
# CONSOLIDATED FROM test_batch_execution_coverage.py
# ============================================================================

@pytest.mark.unit
class TestBatchExecutionMixin:
    """Test BatchExecutionMixin functionality."""

    def testInitializesMixin(self):
        """Test BatchExecutionMixin can be used as mixin."""

        class TestExecutor(BatchExecutionMixin):
            pass

        executor = TestExecutor()
        assert executor is not None

    @pytest.mark.asyncio
    async def testExecuteWithRetrySucceeds(self):
        """Test executeWithRetry on first attempt."""

        class TestExecutor(BatchExecutionMixin):
            pass

        executor = TestExecutor()
        mockExecutor = AsyncMock(return_value={"status": "success"})

        result = await executor.executeWithRetry(mockExecutor, maxRetries=3)
        assert result["status"] == "success"
        assert mockExecutor.call_count == 1

    @pytest.mark.asyncio
    async def testExecuteWithRetryFailsInitially(self):
        """Test executeWithRetry retries after failure."""

        class TestExecutor(BatchExecutionMixin):
            pass

        executor = TestExecutor()
        mockExecutor = AsyncMock()
        mockExecutor.side_effect = [
            Exception("Temporary failure"),
            {"status": "success"},
        ]

        result = await executor.executeWithRetry(mockExecutor, maxRetries=3)
        assert mockExecutor.call_count == 2

    @pytest.mark.asyncio
    async def testExecuteWithRetryExhaustsRetries(self):
        """Test executeWithRetry exhausts retries."""

        class TestExecutor(BatchExecutionMixin):
            pass

        executor = TestExecutor()
        mockExecutor = AsyncMock(side_effect=Exception("Persistent failure"))

        with pytest.raises(Exception):
            await executor.executeWithRetry(mockExecutor, maxRetries=2)

        assert mockExecutor.call_count == 3  # 1 initial + 2 retries

    @pytest.mark.asyncio
    async def testExecuteWithExponentialBackoff(self):
        """Test exponential backoff retry logic."""

        class TestExecutor(BatchExecutionMixin):
            pass

        executor = TestExecutor()
        mockExecutor = AsyncMock()
        mockExecutor.side_effect = [
            Exception("Fail 1"),
            Exception("Fail 2"),
            {"status": "success"},
        ]

        result = await executor.executeWithRetry(
            mockExecutor,
            maxRetries=3,
            initialBackoffMs=10,
            maxBackoffMs=100,
        )
        assert result["status"] == "success"

    @pytest.mark.asyncio
    async def testExecuteWithCustomBackoffMs(self):
        """Test custom backoff milliseconds."""

        class TestExecutor(BatchExecutionMixin):
            pass

        executor = TestExecutor()
        mockExecutor = AsyncMock(return_value={"status": "success"})

        result = await executor.executeWithRetry(
            mockExecutor,
            maxRetries=1,
            initialBackoffMs=50,
            maxBackoffMs=500,
        )
        assert result["status"] == "success"

    @pytest.mark.asyncio
    async def testExecuteWithZeroRetries(self):
        """Test executeWithRetry with zero retries allowed."""

        class TestExecutor(BatchExecutionMixin):
            pass

        executor = TestExecutor()
        mockExecutor = AsyncMock(side_effect=Exception("No retries"))

        with pytest.raises(Exception):
            await executor.executeWithRetry(mockExecutor, maxRetries=0)

@pytest.mark.unit
class TestBatchExecutionMixinIntegration:
    """Test BatchExecutionMixin in realistic scenarios."""

    @pytest.mark.asyncio
    async def testMixinUsedWithOtherMethods(self):
        """Test mixin works alongside other methods."""

        class TestBatchProcessor(BatchExecutionMixin):
            def __init__(self):
                self.executions = 0

            async def process(self, task):
                self.executions += 1
                return {"task": task, "status": "processed"}

        processor = TestBatchProcessor()
        assert processor.executions == 0

        mockTask = AsyncMock(return_value={"status": "success"})
        await processor.executeWithRetry(mockTask, maxRetries=2)
        assert processor is not None

    @pytest.mark.asyncio
    async def testRetryLogicPreservesResult(self):
        """Test that retry logic preserves final result."""

        class TestExecutor(BatchExecutionMixin):
            pass

        executor = TestExecutor()
        expectedResult = {"data": "important", "value": 42}
        mockExecutor = AsyncMock(return_value=expectedResult)

        result = await executor.executeWithRetry(mockExecutor)
        assert result == expectedResult

    @pytest.mark.asyncio
    async def testRetryLogicHandlesTimeoutException(self):
        """Test retry logic with timeout exceptions."""

        class TestExecutor(BatchExecutionMixin):
            pass

        executor = TestExecutor()
        mockExecutor = AsyncMock()
        mockExecutor.side_effect = [
            TimeoutError("First attempt timeout"),
            {"status": "success"},
        ]

        result = await executor.executeWithRetry(mockExecutor, maxRetries=2)
        assert result["status"] == "success"

@pytest.mark.unit
class TestConcurrentExecution:
    """Test concurrent execution methods."""

    @pytest.mark.asyncio
    async def testExecuteConcurrentSuccess(self):
        """Test executing multiple tasks concurrently."""

        class TestExecutor(BatchExecutionMixin):
            pass

        executor = TestExecutor()
        tasks = [
            {"id": "task1", "data": "data1"},
            {"id": "task2", "data": "data2"},
            {"id": "task3", "data": "data3"},
        ]

        mockExecutor = AsyncMock(side_effect=lambda t: {"result": t["data"]})
        results = await executor.executeConcurrent(tasks, mockExecutor, concurrency=2)

        assert len(results) == 3
        assert results["task1"]["result"] == "data1"
        assert results["task2"]["result"] == "data2"
        assert results["task3"]["result"] == "data3"

    @pytest.mark.asyncio
    async def testExecuteConcurrentWithError(self):
        """Test concurrent execution with task errors."""

        class TestExecutor(BatchExecutionMixin):
            pass

        executor = TestExecutor()
        tasks = [
            {"id": "task1"},
            {"id": "task2"},
        ]

        def sideEffect(task):
            if task["id"] == "task2":
                raise ValueError("Task 2 failed")
            return {"status": "success"}

        mockExecutor = AsyncMock(side_effect=sideEffect)
        results = await executor.executeConcurrent(tasks, mockExecutor)

        assert "task1" in results
        assert "task2" in results
        assert "error" in results["task2"]

    @pytest.mark.asyncio
    async def testExecuteConcurrentRespectsConcurrency(self):
        """Test that concurrency limit is respected."""

        class TestExecutor(BatchExecutionMixin):
            pass

        executor = TestExecutor()
        tasks = [{"id": f"task{i}"} for i in range(5)]
        mockExecutor = AsyncMock(return_value={"status": "success"})

        results = await executor.executeConcurrent(tasks, mockExecutor, concurrency=2)
        assert len(results) == 5

@pytest.mark.unit
class TestResultCollection:
    """Test result collection methods."""

    def testCollectResults(self):
        """Test collecting raw results."""

        class TestExecutor(BatchExecutionMixin):
            pass

        executor = TestExecutor()
        rawResults = {
            "task1": {"value": 10},
            "task2": {"value": 20},
        }

        results = executor.collectResults(rawResults)
        assert results == rawResults

    def testCollectResultsWithNormalizer(self):
        """Test collecting results with normalizer."""

        class TestExecutor(BatchExecutionMixin):
            pass

        executor = TestExecutor()
        rawResults = {
            "task1": {"value": 10},
            "task2": {"value": 20},
        }

        normalizer = lambda r: {"normalized_value": r["value"] * 2}
        results = executor.collectResults(rawResults, normalizer)

        assert results["task1"]["normalized_value"] == 20
        assert results["task2"]["normalized_value"] == 40

    def testCollectResultsNormalizerError(self):
        """Test collection when normalizer fails."""

        class TestExecutor(BatchExecutionMixin):
            pass

        executor = TestExecutor()
        rawResults = {
            "task1": {"value": 10},
            "task2": "invalid",
        }

        normalizer = lambda r: r["value"] * 2
        results = executor.collectResults(rawResults, normalizer)

        # task1 should be normalized, task2 should be kept as-is on error
        assert results["task1"] == 20
        assert results["task2"] == "invalid"

@pytest.mark.unit
class TestResultAggregation:
    """Test result aggregation methods."""

    def testAggregateResultsNoAggregator(self):
        """Test aggregation without custom aggregator."""

        class TestExecutor(BatchExecutionMixin):
            pass

        executor = TestExecutor()
        results = {"task1": {"value": 10}, "task2": {"value": 20}}

        aggregated = executor.aggregateResults(results)
        assert aggregated == results

    def testAggregateResultsWithAggregator(self):
        """Test aggregation with custom aggregator."""

        class TestExecutor(BatchExecutionMixin):
            pass

        executor = TestExecutor()
        results = {"task1": {"value": 10}, "task2": {"value": 20}}

        aggregator = lambda r: sum(v["value"] for v in r.values())
        aggregated = executor.aggregateResults(results, aggregator)

        assert aggregated == 30

    def testAggregateResultsEmpty(self):
        """Test aggregation with empty results."""

        class TestExecutor(BatchExecutionMixin):
            pass

        executor = TestExecutor()
        aggregated = executor.aggregateResults({})
        assert aggregated is None

    def testAggregateResultsAggregatorError(self):
        """Test aggregation when aggregator fails."""

        class TestExecutor(BatchExecutionMixin):
            pass

        executor = TestExecutor()
        results = {"task1": {"value": 10}}

        aggregator = lambda r: 1 / 0
        aggregated = executor.aggregateResults(results, aggregator)

        # Should return raw results on error
        assert aggregated == results

@pytest.mark.unit
class TestErrorHandling:
    """Test error handling methods."""

    def testHandleExecutionError(self):
        """Test handling execution errors."""

        class TestExecutor(BatchExecutionMixin):
            pass

        executor = TestExecutor()
        error = ValueError("Test error")

        result = executor.handleExecutionError(error)

        assert result["error"] is True
        assert result["errorType"] == "ValueError"
        assert result["errorMessage"] == "Test error"
        assert result["context"] is None

    def testHandleExecutionErrorWithContext(self):
        """Test error handling with context."""

        class TestExecutor(BatchExecutionMixin):
            pass

        executor = TestExecutor()
        error = RuntimeError("Runtime failure")
        context = {"task_id": "task1", "attempt": 2}

        result = executor.handleExecutionError(error, context)

        assert result["error"] is True
        assert result["errorType"] == "RuntimeError"
        assert result["context"] == context

# ============================================================================
# CONSOLIDATED FROM test_batch_formation_cache_coverage.py
# ============================================================================

class TestCachedFormation:
    """Test CachedFormation entry."""

    def testInitialization(self):
        """Test CachedFormation initialization."""
        formation = CachedFormation(
            taskHash="abc123",
            similarityMatrix={"t1": {"t2": 0.9}},
            grouping={"g1": ["t1", "t2"]},
            metrics={"efficacy": 2.0},
        )

        assert formation.taskHash == "abc123"
        assert formation.similarityMatrix == {"t1": {"t2": 0.9}}
        assert formation.grouping == {"g1": ["t1", "t2"]}
        assert formation.metrics == {"efficacy": 2.0}

    def testCustomTTL(self):
        """Test CachedFormation with custom TTL."""
        formation = CachedFormation(
            taskHash="abc123",
            similarityMatrix={},
            grouping={},
            metrics={},
            ttlSeconds=600,
        )

        # TTL is stored in parent class, verify formation was created
        assert formation.taskHash == "abc123"

class TestBatchFormationCacheBasics:
    """Test basic cache operations."""

    def testInitialization(self):
        """Test BatchFormationCache initialization."""
        cache = BatchFormationCache(ttlSeconds=300, maxEntries=5000)
        assert cache.ttlSeconds == 300
        assert cache.maxEntries == 5000
        assert cache.getCacheSize() == 0

    def testHashTasksConsistent(self):
        """Test task hashing is deterministic."""
        taskIds = ["task3", "task1", "task2"]
        hash1 = BatchFormationCache.hashTasks(taskIds)
        hash2 = BatchFormationCache.hashTasks(taskIds)
        # Different order should produce same hash (sorted)
        hash3 = BatchFormationCache.hashTasks(["task1", "task2", "task3"])

        assert hash1 == hash2
        assert hash1 == hash3

    def testHashTasksUnique(self):
        """Test different task sets have different hashes."""
        hash1 = BatchFormationCache.hashTasks(["task1", "task2"])
        hash2 = BatchFormationCache.hashTasks(["task1", "task3"])

        assert hash1 != hash2

class TestBatchFormationCacheOperations:
    """Test cache get/set operations."""

    def testCacheFormation(self):
        """Test caching a formation."""
        cache = BatchFormationCache()
        taskIds = ["t1", "t2"]
        similarity = {"t1": {"t2": 0.9}}
        grouping = {"g1": ["t1", "t2"]}
        metrics = {"efficacy": 2.0}

        taskHash = cache.cacheFormation(taskIds, similarity, grouping, metrics)

        assert isinstance(taskHash, str)
        assert cache.getCacheSize() == 1

    def testGetSimilarityMatrixHit(self):
        """Test cache hit when formation exists."""
        cache = BatchFormationCache()
        taskIds = ["t1", "t2"]
        similarity = {"t1": {"t2": 0.9}}
        grouping = {"g1": ["t1", "t2"]}
        metrics = {"efficacy": 2.0}

        cache.cacheFormation(taskIds, similarity, grouping, metrics)
        result = cache.getSimilarityMatrix(taskIds)

        assert result is not None
        assert result[0] == similarity
        assert result[1] == grouping
        assert result[2] == metrics

    def testGetSimilarityMatrixMiss(self):
        """Test cache miss when formation not cached."""
        cache = BatchFormationCache()
        result = cache.getSimilarityMatrix(["t1", "t2"])
        assert result is None

    def testGetSimilarityMatrixExpired(self):
        """Test cache eviction when entry expires (lines 198-199)."""
        cache = BatchFormationCache(ttlSeconds=1)  # 1 second TTL
        taskIds = ["t1", "t2"]

        cache.cacheFormation(taskIds, {}, {}, {})

        # Mock isExpired to return True
        taskHash = BatchFormationCache.hashTasks(taskIds)
        with patch.object(cache.cache[taskHash], "isExpired", return_value=True):
            result = cache.getSimilarityMatrix(taskIds)

        assert result is None
        assert cache.getCacheSize() == 0

    def testValidateFormationFresh(self):
        """Test validation of fresh cached formation."""
        cache = BatchFormationCache()
        taskIds = ["t1", "t2"]
        taskHash = cache.cacheFormation(taskIds, {}, {}, {})

        assert cache.validateFormation(taskHash) is True

    def testValidateFormationNotExist(self):
        """Test validation of non-existent formation."""
        cache = BatchFormationCache()
        assert cache.validateFormation("nonexistent") is False

    def testValidateFormationExpired(self):
        """Test validation of expired formation."""
        cache = BatchFormationCache()
        taskIds = ["t1", "t2"]
        taskHash = cache.cacheFormation(taskIds, {}, {}, {})

        # Mock isExpired to return True
        with patch.object(cache.cache[taskHash], "isExpired", return_value=True):
            assert cache.validateFormation(taskHash) is False
            assert cache.getCacheSize() == 0

class TestBatchFormationCacheEviction:
    """Test LRU eviction logic."""

    def testEvictLRUEmpty(self):
        """Test eviction with empty cache (line 171)."""
        cache = BatchFormationCache()
        cache._evictLRU()  # Should not raise
        assert cache.getCacheSize() == 0

    def testEvictLRUAutomatic(self):
        """Test automatic eviction when cache exceeds maxEntries."""
        cache = BatchFormationCache(maxEntries=5)

        # Fill cache beyond max
        for i in range(7):
            cache.cacheFormation([f"task{i}"], {}, {}, {})

        # Should have evicted some entries
        assert cache.getCacheSize() <= 5

    def testEvictLRUEvicts10Percent(self):
        """Test that LRU evicts 10% at a time."""
        cache = BatchFormationCache(maxEntries=100)

        # Fill cache with 50 entries
        for i in range(50):
            cache.cacheFormation([f"task{i}"], {}, {}, {})

        initial_size = cache.getCacheSize()

        # Force manual eviction
        cache._evictLRU()

        # Should have evicted ~5 entries (10% of 50)
        assert cache.getCacheSize() < initial_size

class TestBatchFormationCacheStatistics:
    """Test statistics tracking."""

    def testGetStatsEmpty(self):
        """Test stats with empty cache."""
        cache = BatchFormationCache()
        stats = cache.getStats()

        assert stats is not None
        assert "totalOperations" in stats
        assert "hitRate" in stats
        assert "estimatedMemoryBytes" in stats

    def testGetStatsWithHits(self):
        """Test stats with cache hits."""
        cache = BatchFormationCache()
        taskIds = ["t1", "t2"]
        cache.cacheFormation(taskIds, {}, {"g1": ["t1", "t2"]}, {})
        cache.getSimilarityMatrix(taskIds)  # Hit
        cache.getSimilarityMatrix(["other"])  # Miss

        stats = cache.getStats()

        assert stats["hits"] == 1
        assert stats["misses"] == 1
        assert stats["totalOperations"] == 2

    def testGetStatsMemoryEstimation(self):
        """Test memory estimation in stats."""
        cache = BatchFormationCache()
        cache.cacheFormation(
            ["t1", "t2"],
            {"t1": {"t2": 0.9}},
            {"g1": ["t1", "t2"]},
            {},
        )

        stats = cache.getStats()

        assert stats["estimatedMemoryBytes"] > 0
        assert stats["estimatedMemoryMB"] >= 0

    def testGetHitRateNoOperations(self):
        """Test hit rate with no cache operations (line 247)."""
        cache = BatchFormationCache()
        assert cache.getHitRate() == 0.0

    def testGetHitRateWithOperations(self):
        """Test hit rate calculation."""
        cache = BatchFormationCache()
        taskIds = ["t1", "t2"]
        cache.cacheFormation(taskIds, {}, {}, {})

        # 2 hits, 1 miss = 66.67%
        cache.getSimilarityMatrix(taskIds)  # Hit
        cache.getSimilarityMatrix(taskIds)  # Hit
        cache.getSimilarityMatrix(["other"])  # Miss

        hit_rate = cache.getHitRate()
        assert 66 < hit_rate < 67

class TestBatchFormationCacheManagement:
    """Test cache management operations."""

    def testClear(self):
        """Test clearing cache."""
        cache = BatchFormationCache()
        cache.cacheFormation(["t1"], {}, {}, {})
        cache.cacheFormation(["t2"], {}, {}, {})

        assert cache.getCacheSize() == 2

        cache.clear()

        assert cache.getCacheSize() == 0

    def testGetCacheSize(self):
        """Test getting cache size."""
        cache = BatchFormationCache()
        assert cache.getCacheSize() == 0

        cache.cacheFormation(["t1"], {}, {}, {})
        assert cache.getCacheSize() == 1

        cache.cacheFormation(["t2"], {}, {}, {})
        assert cache.getCacheSize() == 2

class TestBatchFormationCacheIntegration:
    """Integration tests for cache operations."""

    def testMultipleFormations(self):
        """Test caching multiple formations."""
        cache = BatchFormationCache()

        formations = [
            (["t1", "t2"], {"t1": {"t2": 0.9}}),
            (["t2", "t3"], {"t2": {"t3": 0.8}}),
            (["t1", "t3"], {"t1": {"t3": 0.7}}),
        ]

        for taskIds, similarity in formations:
            cache.cacheFormation(taskIds, similarity, {}, {})

        assert cache.getCacheSize() == 3

        # Verify all can be retrieved
        for taskIds, similarity in formations:
            result = cache.getSimilarityMatrix(taskIds)
            assert result is not None
            assert result[0] == similarity

    def testCacheWarmingAndEviction(self):
        """Test filling cache and triggering eviction."""
        cache = BatchFormationCache(maxEntries=10)

        # Fill cache with 15 formations
        for i in range(15):
            cache.cacheFormation(
                [f"task{i}"],
                {},
                {f"group{i}": [f"task{i}"]},
                {},
            )

        # Should be at or near maxEntries
        assert cache.getCacheSize() <= 10

class TestGetFormationCacheFunction:
    """Test singleton factory function."""

    def testGetFormationCacheReturnsInstance(self):
        """Test getFormationCache returns BatchFormationCache instance."""
        cache = getFormationCache()
        assert cache is not None
        assert isinstance(cache, BatchFormationCache)

    def testGetFormationCacheIsSingleton(self):
        """Test getFormationCache returns same instance."""
        cache1 = getFormationCache()
        cache2 = getFormationCache()
        assert isinstance(cache1, BatchFormationCache)
        assert isinstance(cache2, BatchFormationCache)

# ============================================================================
# CONSOLIDATED FROM test_batch_stats_coverage.py
# ============================================================================

@pytest.mark.unit
class TestBatchStatsMixin:
    """Test BatchStatsMixin functionality."""

    def testInitialization(self):
        """Test BatchStatsMixin initialization."""
        mixin = BatchStatsMixin()
        assert mixin._batchStats["batchesCreated"] == 0
        assert mixin._batchStats["batchesProcessed"] == 0
        assert mixin._batchStats["batchesFailed"] == 0
        assert mixin._batchStats["totalItems"] == 0
        assert mixin._batchStats["totalSuccessful"] == 0
        assert mixin._batchStats["totalFailed"] == 0
        assert mixin._batchStats["totalCost"] == 0.0
        assert mixin._batchStats["totalSavings"] == 0.0
        assert mixin._batchStats["totalLatencyMs"] == 0.0
        assert mixin._batchStats["cacheHits"] == 0
        assert mixin._batchStats["cacheMisses"] == 0

    def testRecordBatchCreation(self):
        """Test recording batch creation."""
        mixin = BatchStatsMixin()
        mixin.recordBatchCreation()
        assert mixin._batchStats["batchesCreated"] == 1
        mixin.recordBatchCreation()
        assert mixin._batchStats["batchesCreated"] == 2

    def testRecordBatchProcessing(self):
        """Test recording batch processing."""
        mixin = BatchStatsMixin()
        mixin.recordBatchProcessing(
            itemCount=10,
            successCount=8,
            failureCount=2,
            cost=50.0,
            savings=10.0,
            latencyMs=100.5,
        )
        assert mixin._batchStats["batchesProcessed"] == 1
        assert mixin._batchStats["totalItems"] == 10
        assert mixin._batchStats["totalSuccessful"] == 8
        assert mixin._batchStats["totalFailed"] == 2
        assert mixin._batchStats["totalCost"] == 50.0
        assert mixin._batchStats["totalSavings"] == 10.0
        assert mixin._batchStats["totalLatencyMs"] == 100.5

    def testRecordBatchProcessingMultiple(self):
        """Test recording multiple batch processings accumulate."""
        mixin = BatchStatsMixin()
        mixin.recordBatchProcessing(10, 8, 2, 50.0, 10.0, 100.0)
        mixin.recordBatchProcessing(5, 5, 0, 25.0, 5.0, 50.0)
        assert mixin._batchStats["batchesProcessed"] == 2
        assert mixin._batchStats["totalItems"] == 15
        assert mixin._batchStats["totalSuccessful"] == 13
        assert mixin._batchStats["totalFailed"] == 2
        assert mixin._batchStats["totalCost"] == 75.0
        assert mixin._batchStats["totalSavings"] == 15.0
        assert mixin._batchStats["totalLatencyMs"] == 150.0

    def testRecordBatchFailure(self):
        """Test recording batch failure."""
        mixin = BatchStatsMixin()
        mixin.recordBatchFailure()
        assert mixin._batchStats["batchesFailed"] == 1
        mixin.recordBatchFailure()
        assert mixin._batchStats["batchesFailed"] == 2

    def testRecordCacheHit(self):
        """Test recording cache hit."""
        mixin = BatchStatsMixin()
        mixin.recordCacheHit()
        assert mixin._batchStats["cacheHits"] == 1
        mixin.recordCacheHit()
        assert mixin._batchStats["cacheHits"] == 2

    def testRecordCacheMiss(self):
        """Test recording cache miss."""
        mixin = BatchStatsMixin()
        mixin.recordCacheMiss()
        assert mixin._batchStats["cacheMisses"] == 1
        mixin.recordCacheMiss()
        assert mixin._batchStats["cacheMisses"] == 2

    def testRecordCacheOperation(self):
        """Test recording cache operation."""
        mixin = BatchStatsMixin()
        mixin.recordCacheOperation(True)
        assert mixin._batchStats["cacheHits"] == 1
        mixin.recordCacheOperation(False)
        assert mixin._batchStats["cacheMisses"] == 1

    def testGetStatsEmptyBatches(self):
        """Test getting stats with empty batches."""
        mixin = BatchStatsMixin()
        stats = mixin.getStats()
        assert stats["batches"]["created"] == 0
        assert stats["batches"]["processed"] == 0
        assert stats["batches"]["failed"] == 0
        assert stats["batches"]["successRate"] == 0

    def testGetStatsBatchSuccessRate(self):
        """Test batch success rate calculation."""
        mixin = BatchStatsMixin()
        mixin.recordBatchProcessing(10, 10, 0, 50.0, 0, 100.0)
        mixin.recordBatchFailure()
        stats = mixin.getStats()
        assert stats["batches"]["processed"] == 1
        assert stats["batches"]["failed"] == 1
        assert stats["batches"]["total"] == 2
        assert stats["batches"]["successRate"] == 50.0

    def testGetStatsItemsSuccessRate(self):
        """Test items success rate calculation."""
        mixin = BatchStatsMixin()
        mixin.recordBatchProcessing(10, 8, 2, 50.0, 0, 100.0)
        stats = mixin.getStats()
        assert stats["items"]["total"] == 10
        assert stats["items"]["successful"] == 8
        assert stats["items"]["failed"] == 2
        assert stats["items"]["successRate"] == 80.0

    def testGetStatsCostAnalysis(self):
        """Test cost analysis in stats."""
        mixin = BatchStatsMixin()
        mixin.recordBatchProcessing(10, 10, 0, 100.0, 25.0, 100.0)
        stats = mixin.getStats()
        assert stats["cost"]["total"] == 100.0
        assert stats["cost"]["savings"] == 25.0
        assert stats["cost"]["netCost"] == 75.0
        assert stats["cost"]["savingsPercent"] == 20.0  # 25 / (100 + 25) * 100

    def testGetStatsPerformance(self):
        """Test performance metrics in stats."""
        mixin = BatchStatsMixin()
        mixin.recordBatchProcessing(10, 10, 0, 100.0, 0, 500.0)
        stats = mixin.getStats()
        assert stats["performance"]["totalLatencyMs"] == 500.0
        assert stats["performance"]["avgLatencyMs"] == 50.0  # 500 / 10
        assert stats["performance"]["avgBatchSize"] == 10.0

    def testGetStatsCachePerformance(self):
        """Test cache performance in stats."""
        mixin = BatchStatsMixin()
        mixin.recordBatchProcessing(10, 10, 0, 100.0, 0, 100.0)
        mixin.recordCacheHit()
        mixin.recordCacheHit()
        mixin.recordCacheMiss()
        stats = mixin.getStats()
        assert stats["cache"]["hits"] == 2
        assert stats["cache"]["misses"] == 1
        assert stats["cache"]["total"] == 3
        assert abs(stats["cache"]["hitRate"] - 66.67) < 0.1  # ~66.67%

    def testGetStatsDivisionByZero(self):
        """Test stats handle division by zero gracefully."""
        mixin = BatchStatsMixin()
        stats = mixin.getStats()
        assert stats["batches"]["successRate"] == 0
        assert stats["items"]["successRate"] == 0
        assert stats["cost"]["savingsPercent"] == 0
        assert stats["cache"]["hitRate"] == 0

    def testGetStatsReport(self):
        """Test getting formatted stats report."""
        mixin = BatchStatsMixin()
        mixin.recordBatchCreation()
        mixin.recordBatchProcessing(10, 8, 2, 100.0, 25.0, 500.0)
        mixin.recordCacheHit()
        report = mixin.getStatsReport()
        assert "BATCH PROCESSING STATISTICS" in report
        assert "Batch Summary:" in report
        assert "Item Processing:" in report
        assert "Cost Analysis:" in report
        assert "Performance:" in report
        assert "Cache Performance:" in report
        assert "1" in report  # At least one batch

    def testGetStatsReportFormatting(self):
        """Test stats report contains expected values."""
        mixin = BatchStatsMixin()
        mixin.recordBatchProcessing(100, 80, 20, 500.0, 100.0, 1000.0)
        report = mixin.getStatsReport()
        assert "Total: 100" in report
        assert "Successful: 80" in report
        assert "Failed: 20" in report
        assert "Total Cost: $500.0" in report or "Total Cost: $500.00" in report
        assert "Total Savings: $100.0" in report or "Total Savings: $100.00" in report
        assert "Success Rate" in report

    def testResetStats(self):
        """Test resetting all statistics."""
        mixin = BatchStatsMixin()
        mixin.recordBatchCreation()
        mixin.recordBatchProcessing(10, 8, 2, 100.0, 25.0, 500.0)
        mixin.recordCacheHit()
        mixin.resetStats()
        assert mixin._batchStats["batchesCreated"] == 0
        assert mixin._batchStats["batchesProcessed"] == 0
        assert mixin._batchStats["totalItems"] == 0
        assert mixin._batchStats["totalCost"] == 0.0
        assert mixin._batchStats["cacheHits"] == 0

    def testGetStatsRounding(self):
        """Test stats rounding for currency."""
        mixin = BatchStatsMixin()
        mixin.recordBatchProcessing(10, 10, 0, 123.456789, 45.123456, 100.0)
        stats = mixin.getStats()
        assert stats["cost"]["total"] == 123.4568  # Rounded to 4 decimals
        assert stats["cost"]["savings"] == 45.1235
        assert stats["performance"]["totalLatencyMs"] == 100.0

@pytest.mark.unit
class TestBatchStatsIntegration:
    """Test BatchStatsMixin integration scenarios."""

    def testCompleteWorkflow(self):
        """Test complete workflow of batch processing."""
        mixin = BatchStatsMixin()

        # Simulate multiple batches
        mixin.recordBatchCreation()
        mixin.recordBatchCreation()

        # Process first batch successfully
        mixin.recordBatchProcessing(10, 10, 0, 50.0, 10.0, 100.0)
        mixin.recordCacheHit()
        mixin.recordCacheHit()

        # Process second batch with some failures
        mixin.recordBatchProcessing(8, 6, 2, 40.0, 8.0, 80.0)
        mixin.recordCacheMiss()

        # Verify stats
        stats = mixin.getStats()
        assert stats["batches"]["created"] == 2
        assert stats["batches"]["processed"] == 2
        assert stats["items"]["total"] == 18
        assert stats["cache"]["hits"] == 2
        assert stats["cache"]["misses"] == 1

    def testMultipleFailures(self):
        """Test handling multiple batch failures."""
        mixin = BatchStatsMixin()
        mixin.recordBatchProcessing(10, 5, 5, 100.0, 0, 100.0)
        mixin.recordBatchFailure()
        mixin.recordBatchFailure()
        mixin.recordBatchFailure()
        stats = mixin.getStats()
        assert stats["batches"]["failed"] == 3
        assert stats["batches"]["processed"] == 1
        assert stats["batches"]["successRate"] == 25.0  # 1 / 4
"""Comprehensive tests for deduplicationHelpers module."""

import pytest

from app.core.deduplicationHelpers import (
    executeWithFallback,
    extractId,
    formatCurrency,
    formatDuration,
    formatPercentage,
    parseKeyValuePairs,
    requireInRange,
    requireMinLength,
    requireNonEmpty,
    requireType,
    safeGet,
    safeGetNested,
)

@pytest.mark.unit
class TestValidationHelpers:
    """Test validation helper functions."""

    @pytest.mark.parametrize(
        "data,expected",
        [
            ([], False),
            ({}, False),
            ("", False),
            (None, False),
            ([1], True),
            ({"key": "value"}, True),
            ("text", True),
            ((1, 2), True),
            (123, True),
            (0, True),
        ],
    )
    def testRequireNonEmpty(self, data, expected):
        """Test requireNonEmpty with various inputs."""
        assert requireNonEmpty(data) == expected

    @pytest.mark.parametrize(
        "data,minLength,expected",
        [
            ([1, 2, 3], 3, True),
            ([1, 2, 3], 4, False),
            ("hello", 5, True),
            ("hello", 6, False),
            ({}, 0, True),
            (None, 0, False),
            (123, 5, False),  # Non-length type
        ],
    )
    def testRequireMinLength(self, data, minLength, expected):
        """Test requireMinLength."""
        assert requireMinLength(data, minLength) == expected

    @pytest.mark.parametrize(
        "value,expectedType,expected",
        [
            (123, int, True),
            ("text", str, True),
            ([1, 2], list, True),
            ({"key": "val"}, dict, True),
            (123, str, False),
            ("text", int, False),
        ],
    )
    def testRequireType(self, value, expectedType, expected):
        """Test requireType."""
        assert requireType(value, expectedType) == expected

    @pytest.mark.parametrize(
        "value,minVal,maxVal,expected",
        [
            (5, 0, 10, True),
            (0, 0, 10, True),
            (10, 0, 10, True),
            (-1, 0, 10, False),
            (11, 0, 10, False),
            (5, 5, None, True),
            (4, 5, None, False),
            (100, None, 100, True),
            (101, None, 100, False),
            (None, 0, 10, False),
        ],
    )
    def testRequireInRange(self, value, minVal, maxVal, expected):
        """Test requireInRange."""
        assert requireInRange(value, minVal, maxVal) == expected

@pytest.mark.unit
class TestFormattingHelpers:
    """Test formatting helper functions."""

    @pytest.mark.parametrize(
        "amount,precision,expected",
        [
            (0, 2, "$0.00"),
            (100, 2, "$100.00"),
            (1234.56, 2, "$1,234.56"),
            (1000000, 2, "$1,000,000.00"),
            (100.1, 2, "$100.10"),
            (None, 2, "$0.00"),
            ("invalid", 2, "$0.00"),
            (100, 1, "$100.0"),
        ],
    )
    def testFormatCurrency(self, amount, precision, expected):
        """Test formatCurrency."""
        assert formatCurrency(amount, precision) == expected

    @pytest.mark.parametrize(
        "value,precision,expected",
        [
            (0.5, 1, "50.0%"),
            (0, 1, "0.0%"),
            (1.0, 1, "100.0%"),
            (0.333, 1, "33.3%"),
            (0.999, 2, "99.90%"),
            (None, 1, "0.0%"),
            ("invalid", 1, "0.0%"),
        ],
    )
    def testFormatPercentage(self, value, precision, expected):
        """Test formatPercentage."""
        assert formatPercentage(value, precision) == expected

    @pytest.mark.parametrize(
        "seconds,expected",
        [
            (0, "0s"),
            (45, "45s"),
            (59, "59s"),
            (60, "1m"),
            (90, "1m 30s"),
            (3600, "1h"),
            (3660, "1h 1m"),
            (7200, "2h"),
            (None, "0s"),
            (-10, "0s"),
        ],
    )
    def testFormatDuration(self, seconds, expected):
        """Test formatDuration."""
        assert formatDuration(seconds) == expected

@pytest.mark.unit
class TestErrorHandlingHelpers:
    """Test error handling helper functions."""

    @pytest.mark.parametrize(
        "data,key,default,expected",
        [
            ({"key": "value"}, "key", None, "value"),
            ({"key": "value"}, "missing", None, None),
            ({"key": "value"}, "missing", "default", "default"),
            (None, "key", "default", "default"),
            ("not a dict", "key", "default", "default"),
        ],
    )
    def testSafeGet(self, data, key, default, expected):
        """Test safeGet."""
        assert safeGet(data, key, default) == expected

    @pytest.mark.parametrize(
        "data,keys,default,expected",
        [
            ({"a": {"b": {"c": "value"}}}, ["a", "b", "c"], None, "value"),
            ({"a": {"b": {"c": "value"}}}, ["a", "b"], None, {"c": "value"}),
            ({"a": {"b": {"c": "value"}}}, ["a", "missing"], None, None),
            ({"a": {"b": {"c": "value"}}}, ["x", "y", "z"], "default", "default"),
            (None, ["a"], "default", "default"),
            ({"a": None}, ["a", "b"], "default", "default"),
        ],
    )
    def testSafeGetNested(self, data, keys, default, expected):
        """Test safeGetNested."""
        assert safeGetNested(data, keys, default) == expected

    def testExecuteWithFallbackSuccess(self):
        """Test executeWithFallback when primary succeeds."""
        primary = lambda: "primary result"
        result = executeWithFallback(primary)
        assert result == "primary result"

    def testExecuteWithFallbackPrimaryFails(self):
        """Test executeWithFallback when primary fails."""
        primary = lambda: 1 / 0
        fallback = lambda: "fallback result"
        result = executeWithFallback(primary, fallback)
        assert result == "fallback result"

    def testExecuteWithFallbackBothFail(self):
        """Test executeWithFallback when both fail."""
        primary = lambda: 1 / 0
        fallback = lambda: 1 / 0
        result = executeWithFallback(primary, fallback, "default")
        assert result == "default"

    def testExecuteWithFallbackNoFallback(self):
        """Test executeWithFallback without fallback."""
        primary = lambda: 1 / 0
        result = executeWithFallback(primary, default="default")
        assert result == "default"

@pytest.mark.unit
class TestParsingHelpers:
    """Test parsing helper functions."""

    @pytest.mark.parametrize(
        "value,pattern,expected",
        [
            ("id123", None, "id123"),
            ("id-456-xyz", None, "id-456-xyz"),
            ("test_789", None, "test_789"),
            ("", None, None),
            (None, None, None),
            (123, None, None),
            ("abc@def", r"@(\w+)", "def"),
            ("abc@def", r"^([a-z]+)", "abc"),
        ],
    )
    def testExtractId(self, value, pattern, expected):
        """Test extractId."""
        assert extractId(value, pattern) == expected

    @pytest.mark.parametrize(
        "data,pairSep,kvSep,expected",
        [
            ("key1=val1,key2=val2", ",", "=", {"key1": "val1", "key2": "val2"}),
            ("a=1;b=2;c=3", ";", "=", {"a": "1", "b": "2", "c": "3"}),
            ("name:john,age:30", ",", ":", {"name": "john", "age": "30"}),
            ("", ",", "=", {}),
            (None, ",", "=", {}),
            ("no_separator", ",", "=", {}),
            ("key1=val1,key2=val2,invalid", ",", "=", {"key1": "val1", "key2": "val2"}),
        ],
    )
    def testParseKeyValuePairs(self, data, pairSep, kvSep, expected):
        """Test parseKeyValuePairs."""
        assert parseKeyValuePairs(data, pairSep, kvSep) == expected
