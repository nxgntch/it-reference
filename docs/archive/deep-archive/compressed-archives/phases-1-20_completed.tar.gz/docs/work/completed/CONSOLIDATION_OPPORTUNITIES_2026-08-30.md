# Skills Consolidation & Improvement Opportunities

**Analysis Date**: 2026-08-30  
**Current State**: 28 active runtime skills + archived stubs  
**Coverage**: 100% documentation standardization complete

---

## Executive Summary

**Status**: ✅ Good consolidation state achieved (Phase 2, 2026-08-30)
- 46% reduction via stub archival (48→28 skills)
- Zero circular dependencies
- 100% SKILL.md coverage
- Clear dependency chains established

**Remaining Opportunities**: 4 quick wins + 2 strategic consolidations

---

## Quick Wins (Immediate Actions, 1-2 days each)

### 1. **Test Coverage for All Skills** (HIGH IMPACT)
**Current State**: Not all skills have unit/integration tests  
**Opportunity**: Add test coverage for skills without it

**Impact**:
- Catch bugs earlier in skill development
- Enable refactoring with confidence
- Improve code quality

**Action**:
```bash
# Find skills without tests
find skills -maxdepth 1 -type d ! -name 'archived-stubs' ! -name '__*' | while read skill; do
  if [ ! -d "$skill/tests" ]; then
    echo "Missing tests: $skill"
  fi
done
```

**Effort**: ~2-3 hours (batch 5-6 skills)  
**Impact**: Medium-high (quality + maintainability)

---

### 2. **Add Usage Examples to 20 Skills** (MEDIUM EFFORT)
**Current State**: Only 8/28 skills have Usage section  
**Opportunity**: Add practical code examples to remaining 20 skills

**Skills without Usage**:
- Analytics: analyticsEngine, anomalyDetector
- Cost: costForecasting, costAwareLlmPipeline  
- Performance: intelligentOptimizer, forecastingEngine, rootCauseAnalyzer
- Geographic: geoRouterExtended, regionFailoverManager, dataLocalityOptimizer
- Runtime: cacheManager, metricsCollector, healthCheck, performanceTracing
- Governance: quotaEnforcer, tenantAudit, tenantRouter
- Documentation: reportGenerator
- Code: codeGeneration, codeReview

**Action**: Update SKILL.md with `## Usage` section containing:
```markdown
## Usage

### Example 1: Basic invocation
\`\`\`python
skill = SkillName()
result = skill.execute(inputParam)
\`\`\`

### Example 2: With configuration
\`\`\`python
config = {...}
result = skill.execute(input, config)
\`\`\`
```

**Effort**: ~1-2 hours (standard template per skill)  
**Impact**: Medium (discoverability + usability)

---

### 3. **Add Related Skills Cross-References** (LOW EFFORT)
**Current State**: 0/28 skills have Related Skills section  
**Opportunity**: Cross-link dependent/related skills for discovery

**Benefits**:
- Help developers understand skill relationships
- Enable better routing decisions by agents
- Improve IDE skill discovery

**Action**: Add to each SKILL.md:
```markdown
## Related Skills

- **Upstream**: List skills that feed output into this skill
- **Downstream**: List skills that typically consume this skill's output
- **Alternative**: Similar skills that solve related problems
```

**Auto-linkable Pairs**:
- costForecasting ↔ costAwareLlmPipeline
- anomalyDetector ↔ rootCauseAnalyzer
- geoRouterExtended ↔ regionFailoverManager
- codeGeneration ↔ codeReview

**Effort**: ~1 hour (data-driven, mostly copy-paste)  
**Impact**: Low-medium (UX + discoverability)

---

### 4. **Add Error Handling Sections** (MEDIUM EFFORT)
**Current State**: 0/28 skills have Error Handling documentation  
**Opportunity**: Document common error scenarios and recovery strategies

**Action**: Add to SKILL.md:
```markdown
## Error Handling

### Common Errors

| Error | Cause | Recovery |
|-------|-------|----------|
| InvalidInputError | Missing required parameter | Provide all required inputs |
| TimeoutError | Operation exceeded timeout | Increase timeout or simplify input |
| ExternalServiceError | Dependency unavailable | Retry with exponential backoff |
```

**Effort**: ~2-3 hours (per-skill basis, batched)  
**Impact**: Medium (debugging + reliability documentation)

---

## Strategic Consolidations (1-3 week efforts)

### 5. **Unify Analytics Layer** (STRATEGIC)
**Current Skills**:
- `analyticsEngine` — Aggregates metrics and trends
- `anomalyDetector` — Detects statistical anomalies
- `rootCauseAnalyzer` — Analyzes root causes of anomalies (Phase 19)
- `metricsCollector` — Collects raw metrics

**Current State**: Separate skills with sequential flow:
```
metricsCollector → analyticsEngine → anomalyDetector → rootCauseAnalyzer
```

**Opportunity**: Consider unified "analytics pipeline" skill
- Single entry point for analysis workflows
- Consistent error handling across pipeline
- Shared configuration (thresholds, sensitivity)
- Potential 20-30% code reduction via shared utilities

**Tradeoff**:
- ❌ Less granular control (can't use anomalyDetector in isolation)
- ✅ Simpler routing for agents
- ✅ Easier to maintain consistent behavior
- ✅ Better integrated testing

**Recommendation**: LOW PRIORITY
- Current separation allows flexibility
- Only consolidate if agents frequently call all 4 together
- Monitor for 2-3 weeks; consolidate if 80%+ of calls use full chain

---

### 6. **Geo-Distribution Skill Bundle** (STRATEGIC)
**Current Skills**:
- `geoRouterExtended` — Multi-region routing logic
- `regionFailoverManager` — Failover coordination
- `dataLocalityOptimizer` — Data locality and replication

**Current State**: Separate but tightly coupled (Phase 19 Week 1)

**Opportunity**: Create `geoDistributionManager` that:
- Unified configuration for regions, latencies, capacities
- Single decision point for region selection
- Automatic failover coordination
- Data locality optimization as internal strategy

**Tradeoff**:
- ❌ Less testable in isolation
- ✅ Cleaner API for routing agents
- ✅ Guaranteed consistency (all three scale together)
- ✅ Easier cost modeling (single cost tier)

**Recommendation**: MEDIUM PRIORITY
- Good consolidation candidate if Phase 19 validation shows high coupling
- Wait for 2-3 weeks of operational data
- If failover ≥5% triggered, consolidate for faster decision-making

---

## Deprecation Candidates (Review in 4 weeks)

**No immediate deprecation candidates**, but monitor:

| Skill | Concern | Monitor |
|-------|---------|---------|
| `reportGenerator` | Low usage potential | Agent invocation rate (if <5/week, consider archiving) |
| `tenantAudit` | Narrow use case | Enterprise feature adoption (if not used, archive for Phase 21) |
| `tenantRouter` | Overlaps with routing | Check if agents use both; if never together, merge into routing |

---

## Testing Roadmap

### Phase 1: Coverage Gaps (Immediate)
```
Goal: 80% test coverage across all 28 skills
Action: Identify skills without tests, add unit test stubs
Effort: 2-3 days
```

### Phase 2: Integration Tests (Week 1)
```
Goal: Test skill chains (particularly analytics and geo pipelines)
Action: Add integration tests for dependent skills
Effort: 1 week
```

### Phase 3: Performance Baselines (Week 2)
```
Goal: Establish latency/throughput baselines
Action: Add pytest-benchmark tests for critical skills
Effort: 3-4 days
```

---

## Implementation Priority Matrix

| Opportunity | Effort | Impact | Priority | Timeline |
|---|---|---|---|---|
| Add test coverage | 2-3h | High | 🔴 HIGH | Now |
| Add usage examples | 1-2h | Medium | 🟡 MEDIUM | This week |
| Error handling docs | 2-3h | Medium | 🟡 MEDIUM | This week |
| Related skills links | 1h | Low | 🟢 LOW | Next week |
| Analytics unification | 1-2w | Medium | 🟡 MEDIUM | Monitor 2-3w |
| Geo-distribution bundle | 1-2w | Medium | 🟡 MEDIUM | Monitor 2-3w |

---

## Metrics to Track

**Before Consolidation**:
- ✅ 28 active skills (Phase 2 baseline)
- ✅ 0 circular dependencies
- ✅ 100% SKILL.md coverage
- ❌ ~60% skills with tests
- ❌ ~29% skills with usage examples
- ❌ 0% skills with error handling docs

**After (Quick Wins)**:
- Goal: 100% skills with tests + usage examples + error handling
- Timeline: 1-2 weeks (batched work)
- Token Savings: ~5-10% in agent decision-making (fewer skill choices to reason about)

---

## Action Items

### Immediate (This Week)
- [ ] Run test coverage audit script
- [ ] Create test templates for missing tests
- [ ] Add usage examples to 5 highest-impact skills
- [ ] Document error handling for critical skills (cost, routing)

### Short-term (Next 2-3 weeks)
- [ ] Complete usage examples for all 20 skills
- [ ] Add related skills cross-references (10-15 pairs)
- [ ] Monitor analytics pipeline coupling (decide on unification)
- [ ] Monitor geo-distribution usage (decide on bundling)

### Medium-term (Month 2)
- [ ] Consolidate if >= 80% calls use full analytics chain
- [ ] Consolidate if geo failover triggered >= 5% of time
- [ ] Deprecate if coverage < 1% (e.g., unused reporting skills)

---

## Rollback Plan

If consolidation causes issues:

**For Unified Skills**: Keep originals in `archived-stubs/`, restore with:
```bash
mv skills/archived-stubs/skillName skills/skillName
# Edit config/skills.yaml to re-register
```

**For Combined Skills**: Already have all code; can split back out.

---

## Questions?

- **"Which consolidation should I do first?"** → Start with test coverage (highest impact, lowest risk)
- **"Should we consolidate analytics now?"** → Monitor first; consolidate if all 4 always called together
- **"Will consolidation break existing agents?"** → No; only affects internal implementation, not API contract

---

**Next Review**: 2026-09-15 (2-week checkpoint)  
**Owner**: Engineering Team  
**Related Docs**: CONSOLIDATION_NOTES.md, DEPENDENCIES.md, SKILL_STANDARDIZATION.md
