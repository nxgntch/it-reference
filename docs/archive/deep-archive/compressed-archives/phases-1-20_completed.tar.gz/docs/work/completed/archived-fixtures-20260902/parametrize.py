"""Parametrized fixtures for data-driven testing."""

import pytest


@pytest.fixture(
    params=["claude-opus-5", "claude-sonnet-5", "claude-haiku-4.5"],
    ids=["opus", "sonnet", "haiku"],
    scope="module",
)
def modelVariant(request):
    """Parametrized Claude model variant for testing (module-scoped)."""
    return request.param


@pytest.fixture(params=["high", "standard", "quick"], ids=["high", "std", "quick"], scope="module")
def costTier(request):
    """Parametrized cost tier for testing (module-scoped)."""
    return request.param


@pytest.fixture(params=[100, 500, 1000, 5000], ids=["100", "500", "1k", "5k"], scope="module")
def budgetAmount(request):
    """Parametrized budget amount for testing (module-scoped)."""
    return request.param


@pytest.fixture(
    params=["engineering", "research", "operations"], ids=["eng", "res", "ops"], scope="module"
)
def teamId(request):
    """Parametrized team ID for testing (module-scoped)."""
    return request.param


@pytest.fixture(params=[True, False], ids=["enabled", "disabled"], scope="module")
def featureFlag(request):
    """Parametrized feature flag for testing (module-scoped)."""
    return request.param
