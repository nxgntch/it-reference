"""Sample configuration and mock data fixtures."""

import pytest


@pytest.fixture(scope="module")
def sampleAgentConfig():
    """Sample agent configuration for testing (immutable, reusable)."""
    return {
        "id": "testAgent",
        "name": "Test Agent",
        "model": "claude-sonnet-5",
        "description": "Test agent for unit tests",
        "capabilities": ["test capability"],
        "costTier": "standard",
    }


@pytest.fixture(scope="module")
def sampleSkillConfig():
    """Sample skill configuration for testing (immutable, reusable)."""
    return {
        "id": "testSkill",
        "name": "Test Skill",
        "agent": "testAgent",
        "description": "Test skill for unit tests",
        "capabilities": ["test capability"],
        "costTier": "standard",
        "inputDescription": "Test input",
        "outputDescription": "Test output",
    }


@pytest.fixture(scope="module")
def mockSkillsData():
    """Mock skills data for testing (immutable, reusable)."""
    return {
        "skills": [
            {
                "id": "task-intake",
                "agent": "director",
                "team": "ceo",
                "name": "Task Intake",
                "category": "core",
            },
            {
                "id": "code-generation",
                "agent": "architect",
                "team": "engineering",
                "name": "Code Generation",
                "category": "core",
            },
            {
                "id": "code-review",
                "agent": "architect",
                "team": "engineering",
                "name": "Code Review",
                "category": "core",
            },
            {
                "id": "research-synthesis",
                "agent": "researcher",
                "team": "research",
                "name": "Research Synthesis",
                "category": "research",
            },
        ],
        "categories": [
            {"id": "core", "name": "Core Skills"},
            {"id": "research", "name": "Research Skills"},
        ],
    }


@pytest.fixture
def mockAgentsData():
    """Mock agents data for testing - reusable across agent-related tests."""
    return {
        "agents": [
            {
                "id": "director",
                "name": "Director",
                "model": "claude-opus-5",
                "team": "ceo",
            },
            {
                "id": "architect",
                "name": "Architect",
                "model": "claude-sonnet-5",
                "team": "engineering",
            },
            {
                "id": "researcher",
                "name": "Researcher",
                "model": "claude-haiku-4.5",
                "team": "research",
            },
        ]
    }


@pytest.fixture
def agentLoaderFixture():
    """Reset global agent loader before each test (singleton cleanup)."""
    import scripts.utils.lazy_load_agents

    originalLoader = scripts.utils.lazy_load_agents._agentLoader
    scripts.utils.lazy_load_agents._agentLoader = None
    yield
    scripts.utils.lazy_load_agents._agentLoader = originalLoader
