"""Temporary directories, stdout capture, and YAML config file fixtures."""

import sys
import tempfile
from io import StringIO
from pathlib import Path

import pytest


@pytest.fixture
def tmpLogsDir():
    """Temporary directory for logs."""
    with tempfile.TemporaryDirectory() as tmpDir:
        yield Path(tmpDir)


@pytest.fixture
def capturedOutput():
    """Capture stdout for testing."""
    old_stdout = sys.stdout
    sys.stdout = StringIO()
    yield sys.stdout
    sys.stdout = old_stdout


@pytest.fixture
def tmpDocsDir():
    """Temporary directory for docs testing."""
    with tempfile.TemporaryDirectory() as tmpDir:
        yield Path(tmpDir)


@pytest.fixture
def tmpConfigDir(tmp_path):
    """Temporary directory for config files during testing."""
    config_dir = tmp_path / "config"
    config_dir.mkdir()
    return config_dir


@pytest.fixture
def tmpDocsOutput(tmp_path):
    """Temporary directory for docs output during testing."""
    docs_dir = tmp_path / "docs"
    docs_dir.mkdir()
    return docs_dir


@pytest.fixture
def validYamlConfig(tmpConfigDir):
    """Valid YAML config file for testing."""
    config_file = tmpConfigDir / "test_config.yaml"
    config_file.write_text("""
agents:
   - id: test-agent
  - id: test-agent
   name: Test Agent
   model: claude-sonnet-5
   team: engineering
   capabilities: []
""")
    return config_file


@pytest.fixture
def invalidYamlConfig(tmpConfigDir):
    """Malformed YAML file for error handling validation."""
    invalid_file = tmpConfigDir / "invalid.yaml"
    invalid_file.write_text("""
agents:
   - id: test-agent
  - id: test-agent
   name: Test Agent
   model: claude-sonnet-5
   team: engineering
   capabilities: [  # Unclosed bracket
""")
    return invalid_file


@pytest.fixture
def emptyConfig(tmpConfigDir):
    """Empty configuration for edge case testing."""
    config_file = tmpConfigDir / "empty.yaml"
    config_file.write_text("agents: []\nskills: []")
    return config_file


@pytest.fixture
def tmpValidationDir(tmp_path):
    """Temporary directory for validation test files."""
    return tmp_path


@pytest.fixture
def tmpSyncDir(tmp_path):
    """Temporary directory for safe file operations."""
    return tmp_path
