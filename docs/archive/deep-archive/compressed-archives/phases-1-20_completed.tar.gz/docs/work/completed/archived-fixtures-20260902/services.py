"""Analyzer, optimizer, and cache service fixtures."""

import pytest


@pytest.fixture
def mockCache():
    """Create fresh response cache for each test."""
    try:
        from app.core.responseCache import ResponseCache

        return ResponseCache(maxSize=100)
    except ImportError:
        return {}


@pytest.fixture
def taskComplexityAnalyzer():
    """Create TaskComplexityAnalyzer instance."""
    try:
        from app.core.modelRouter import TaskComplexityAnalyzer

        return TaskComplexityAnalyzer()
    except ImportError:
        pytest.skip("TaskComplexityAnalyzer not available")


@pytest.fixture
def performanceTrendAnalyzer():
    """Create PerformanceTrendAnalyzerSkill instance."""
    try:
        from app.analytics.performanceTrendAnalyzer import PerformanceTrendAnalyzerSkill

        return PerformanceTrendAnalyzerSkill()
    except ImportError:
        pytest.skip("PerformanceTrendAnalyzerSkill not available")


@pytest.fixture
def hookOptimizer():
    """Create HookOptimizer instance."""
    try:
        from scripts.hooks.hookOptimizer import HookOptimizer

        return HookOptimizer()
    except ImportError:
        pytest.skip("HookOptimizer not available")


@pytest.fixture
def tokenOptimizer():
    """Create TokenOptimizer instance."""
    try:
        from scripts.tokenOptimizer import TokenOptimizer

        return TokenOptimizer()
    except ImportError:
        pytest.skip("TokenOptimizer not available")


@pytest.fixture(autouse=True)
def clearResponseCache():
    """Clear response cache before each test to prevent cross-test pollution."""
    try:
        from app.core.singletonFactory import getCache

        cache = getCache()
        cache.flush()
    except ImportError:
        pass
    yield
    try:
        from app.core.singletonFactory import getCache

        cache = getCache()
        cache.flush()
    except ImportError:
        pass
