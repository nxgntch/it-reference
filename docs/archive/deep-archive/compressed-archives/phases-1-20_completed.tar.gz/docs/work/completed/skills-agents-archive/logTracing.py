"""Log tracing skill for all agents
Emit structured logs with request IDs for full distributed tracing.
Connect agent actions to audit trail for compliance and debugging.
"""

import uuid
from datetime import datetime
from typing import Any, Dict, Optional


class LogTracingSkill:
    """Emit structured logs with request tracing for audit trails"""

    def __init__(self, log_aggregator):
        """Initialize log tracing with aggregator
        Args:
           log_aggregator: LogAggregator instance
        """
        self.aggregator = log_aggregator
        self.current_request_id = None

    def startRequestTrace(self, agent_id: str, task_type: str) -> str:
        """Start a new request trace for agent work
        Args:
           agent_id: ID of agent performing work
           task_type: Type of task (routing, optimization, analysis, etc.)
        Returns:
           Request ID to use for all logs in this trace
        """
        self.current_request_id = f"req-{uuid.uuid4().hex[:12]}"
        self.aggregator.log(
            level="info",
            source="system",
            message="Agent work started",
            service=agent_id,
            request_id=self.current_request_id,
            metadata={
                "task_type": task_type,
                "agent_id": agent_id,
                "trace_start": datetime.utcnow().isoformat(),
            },
        )
        return self.current_request_id

    def logDecision(
        self,
        decision: str,
        reason: str,
        agent_id: str,
        impact: Optional[Dict[str, Any]] = None,
        request_id: Optional[str] = None,
    ) -> None:
        """Log an agent decision with full context
        Args:
           decision: Decision made (e.g., "route_to_engineering", "delay_work")
           reason: Reasoning behind decision
           agent_id: Agent making decision
           impact: Impact of decision (cost, latency, etc.)
           request_id: Request ID for tracing (uses current if not provided)
        """
        req_id = request_id or self.current_request_id

        self.aggregator.log(
            level="info",
            source="system",
            message=f"Decision: {decision}",
            service=agent_id,
            request_id=req_id,
            metadata={
                "decision": decision,
                "reason": reason,
                "impact": impact or {},
                "timestamp": datetime.utcnow().isoformat(),
            },
        )

    def logRoutingDecision(
        self,
        target_team: str,
        reasoning: str,
        alternative_routes: Optional[list] = None,
        request_id: Optional[str] = None,
    ) -> None:
        """Log director's task routing decision
        Args:
           target_team: Team task routed to
           reasoning: Why this team was chosen
           alternative_routes: Teams considered but not chosen
           request_id: Request ID for tracing
        """
        req_id = request_id or self.current_request_id

        self.aggregator.log(
            level="info",
            source="system",
            message=f"Task routed to {target_team}",
            service="director",
            request_id=req_id,
            metadata={
                "target_team": target_team,
                "reasoning": reasoning,
                "alternatives": alternative_routes or [],
                "routing_timestamp": datetime.utcnow().isoformat(),
            },
        )

    def logHealthCheck(
        self,
        service_name: str,
        status: str,
        agent_id: str,
        request_id: Optional[str] = None,
    ) -> None:
        """Log health check result
        Args:
           service_name: Service checked
           status: Health status
           agent_id: Agent performing check
           request_id: Request ID for tracing
        """
        req_id = request_id or self.current_request_id

        level = "warning" if status in ["degraded", "critical"] else "info"

        self.aggregator.log(
            level=level,
            source="health",
            message=f"Health check: {service_name} is {status}",
            service=agent_id,
            request_id=req_id,
            metadata={
                "service": service_name,
                "status": status,
                "check_timestamp": datetime.utcnow().isoformat(),
            },
        )

    def logCostDecision(
        self,
        decision: str,
        current_spend: float,
        monthly_budget: float,
        agent_id: str,
        request_id: Optional[str] = None,
    ) -> None:
        """Log cost-related decision
        Args:
           decision: Cost decision (proceed, delay, warn)
           current_spend: Current month's spend
           monthly_budget: Monthly budget limit
           agent_id: Agent making decision
           request_id: Request ID for tracing
        """
        req_id = request_id or self.current_request_id
        percent_used = (current_spend / monthly_budget * 100) if monthly_budget > 0 else 0

        level = "warning" if percent_used > 80 else "info"

        self.aggregator.log(
            level=level,
            source="cost",
            message=f"Cost decision: {decision} ({percent_used:.1f}% of budget used)",
            service=agent_id,
            request_id=req_id,
            metadata={
                "decision": decision,
                "current_spend": current_spend,
                "monthly_budget": monthly_budget,
                "percent_used": percent_used,
                "decision_timestamp": datetime.utcnow().isoformat(),
            },
        )

    def logTaskCompletion(
        self,
        task_type: str,
        status: str,
        agent_id: str,
        metrics: Optional[Dict[str, Any]] = None,
        request_id: Optional[str] = None,
    ) -> None:
        """Log task completion with metrics
        Args:
           task_type: Type of task completed
           status: Completion status (success, partial, failed)
           agent_id: Agent that completed task
           metrics: Performance metrics (duration, cost, etc.)
           request_id: Request ID for tracing
        """
        req_id = request_id or self.current_request_id

        level = "error" if status == "failed" else "info"

        self.aggregator.log(
            level=level,
            source="system",
            message=f"Task completed: {task_type} - {status}",
            service=agent_id,
            request_id=req_id,
            metadata={
                "task_type": task_type,
                "status": status,
                "metrics": metrics or {},
                "completion_timestamp": datetime.utcnow().isoformat(),
            },
        )

    def getRequestTrace(self, request_id: str) -> Dict[str, Any]:
        """Retrieve all logs for a request trace
        Args:
           request_id: Request ID to trace
        Returns:
           All logs associated with this request in chronological order
        """
        logs = self.aggregator.get_logs_for_request(request_id)
        return {
            "request_id": request_id,
            "log_count": len(logs),
            "trace": [
                {
                    "timestamp": log.timestamp.isoformat(),
                    "level": log.level.value,
                    "source": log.source.value,
                    "service": log.service,
                    "message": log.message,
                    "metadata": log.metadata,
                }
                for log in logs
            ],
        }


def logTracing(log_aggregator) -> LogTracingSkill:
    """Factory function for dependency injection
    Usage in any agent:
       from skills.agents.logTracing import logTracing
       tracing = logTracing(log_aggregator)
       req_id = tracing.startRequestTrace("director", "task_routing")
       tracing.logDecision("route_to_engineering", "CPU-intensive work", "director", request_id=req_id)
       # ... later ...
       trace = tracing.getRequestTrace(req_id)  # Full audit trail
    """
    return LogTracingSkill(log_aggregator)
