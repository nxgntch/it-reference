# Skill Consolidation Plan 2026-08-31

**Branch**: `claude/skill-consolidation-plan-4mwds8`  
**Status**: IN PROGRESS  
**Completion Target**: 2026-09-07 (Phase 20 readiness)

---

## Executive Summary

**Goal**: Complete skill consolidation, standardization, and optimization to achieve market-ready skill ecosystem.

**Current State** (as of 2026-08-30):
- ✅ Phase 2: Optimizer consolidation (48→28 active skills, 22 archived)
- ✅ Phase 4: Comprehensive skill testing (62 new tests, 3253 passing)
- ⏳ Quick Wins: Documentation & dependency mapping (NOT YET STARTED)
- ⏳ Phase 20 Prep: Advanced consolidations

**Scope**: 3 major work streams, ~15-20 hours total effort

---

## Work Streams

### Stream 1: Quick Wins (2-3 days, Immediate Impact)

**1A: Documentation Standardization** (1-2 hours)
- [ ] Create unified SKILL.md template
- [ ] Audit all 28 active skills for inconsistent documentation
- [ ] Standardize section structure across all skills
- [ ] Target: 100% skills with consistent docs (Overview | Features | Usage | API | Config | Examples)

**1B: Dependency Mapping** (1-2 hours)
- [ ] Audit skill-to-skill calls (which skills invoke which)
- [ ] Create `skills/DEPENDENCIES.md` with dependency graph
- [ ] Identify and document integration chains
- [ ] Target: Clear visibility of skill interactions

**1C: Add Usage Examples** (2-3 hours)
- [ ] Identify 20 skills without Usage sections
- [ ] Add practical code examples to each
- [ ] Include configuration examples where applicable
- [ ] Target: 100% skills have executable examples

**Effort**: ~4-7 hours  
**Impact**: High (discoverability, usability, maintainability)  
**Dependencies**: None (can start immediately)

---

### Stream 2: Test Coverage Completion (3-5 days, Quality)

**2A: Skills Test Audit** (2 hours)
- [ ] Identify skills without test coverage
- [ ] Categorize by complexity (simple, medium, complex)
- [ ] Estimate test effort per skill

**2B: Add Missing Tests** (6-8 hours, Parallel)
- [ ] High-priority skills (runtime critical): analyticsEngine, metricsCollector, healthCheck
- [ ] Medium-priority skills: cacheManager, performanceTracing, quotaEnforcer
- [ ] Optional skills: remaining 5-6 without tests
- [ ] Target: ≥85% coverage across all active skills

**2C: Run Full Coverage Report** (1 hour)
- [ ] Generate coverage report
- [ ] Verify all active skills meet coverage threshold
- [ ] Document coverage metrics in AUDIT.md

**Effort**: ~9-11 hours  
**Impact**: High (code quality, maintainability, refactoring confidence)  
**Dependencies**: Stream 1 optional (can parallel)

---

### Stream 3: Strategic Consolidations (4-6 days, Architecture)

**3A: Identify Consolidation Opportunities** (3 hours)
- [ ] Analyze skills with overlapping functionality
- [ ] Interview skill owners (code inspection) for consolidation candidates
- [ ] Rate by: potential savings, breaking changes, dependency complexity
- [ ] Document in `skills/CONSOLIDATION_OPPORTUNITIES_2026-09.md`

**3B: Execute High-Impact Consolidations** (6-8 hours, Selective)
- [ ] Consolidate 2-3 identified opportunities
- [ ] Merge functionality, archive obsolete skills
- [ ] Update registry and dependencies
- [ ] Add tests for new consolidated implementations

**3C: Version Planning** (2 hours)
- [ ] Create skill versioning strategy
- [ ] Document backward compatibility approach
- [ ] Plan deprecation timeline for archived skills

**Effort**: ~11-13 hours  
**Impact**: Medium (simplification, maintainability, reduced decision load)  
**Dependencies**: Streams 1 & 2 (understand current state first)

---

## Execution Timeline

### Phase 1: Quick Wins (Week 1, 4-7 hours)
```
Day 1: Documentation Standardization (1-2 hrs)
├─ Create SKILL.md template
├─ Audit current structure
└─ Standardize first 10 skills

Day 2: Dependency Mapping (1-2 hrs)
├─ Audit all skill imports
├─ Create dependency graph
└─ Document integration chains

Day 3: Usage Examples (2-3 hrs)
├─ Add examples to 15-20 skills
└─ Test examples execute correctly
```

**Output**: 
- Unified SKILL.md template
- `skills/DEPENDENCIES.md` with graph
- 20 skills with Usage examples
- 1 commit: `docs(skills): standardize documentation and add examples`

---

### Phase 2: Test Coverage (Week 1-2, 9-11 hours)
```
Day 1-2: Test Audit (2 hrs)
├─ Identify untested skills
├─ Estimate effort per skill
└─ Prioritize by impact

Day 3-4: Implement Missing Tests (6-8 hrs)
├─ Create tests/test_analyticsEngine.py (8 tests)
├─ Create tests/test_metricsCollector.py (8 tests)
├─ Create tests/test_healthCheck.py (6 tests)
├─ Create tests/test_[others].py (remaining)
└─ Run parallel, commit together

Day 5: Coverage Report (1 hr)
├─ Generate pytest coverage
├─ Update AUDIT.md metrics
└─ Document coverage baseline
```

**Output**:
- 30-40 new skill-specific tests
- ≥85% coverage across active skills
- 2 commits: 
  - `feat(skills): add test coverage for [tier 1]`
  - `feat(skills): add test coverage for [tier 2]`

---

### Phase 3: Strategic Consolidations (Week 2, 11-13 hours)
```
Day 1: Consolidation Audit (3 hrs)
├─ Analyze overlapping functionality
├─ Identify 2-3 consolidation candidates
└─ Document in CONSOLIDATION_OPPORTUNITIES_2026-09.md

Day 2-3: Execute Consolidations (6-8 hrs)
├─ Consolidate identified opportunities
├─ Update registry (config/skills.yaml)
├─ Archive obsolete skills
└─ Add tests for consolidated implementations

Day 4: Version Planning (2 hrs)
├─ Define skill versioning strategy
├─ Document deprecation timeline
└─ Update SKILL.md for versioned skills
```

**Output**:
- `skills/CONSOLIDATION_OPPORTUNITIES_2026-09.md`
- 2-3 consolidations completed
- Updated `config/skills.yaml`
- Archived obsolete skills
- 2 commits:
  - `refactor(skills): consolidate [X and Y]`
  - `feat(skills): add versioning strategy`

---

## Success Criteria

### Stream 1: Quick Wins ✅
- [ ] All 28 active skills have consistent SKILL.md structure
- [ ] `skills/DEPENDENCIES.md` created with dependency graph
- [ ] 20+ skills have Usage examples
- [ ] All examples execute successfully

### Stream 2: Test Coverage ✅
- [ ] All critical runtime skills have ≥90% coverage
- [ ] All non-critical skills have ≥80% coverage
- [ ] New tests follow established patterns (Arrange-Act-Assert)
- [ ] Coverage metrics updated in AUDIT.md

### Stream 3: Strategic Consolidations ✅
- [ ] 2-3 consolidations identified and vetted
- [ ] Consolidations implemented and tested
- [ ] No regressions in existing tests
- [ ] Versioning strategy documented

### Overall Metrics
- [ ] Total tests: 3300+ passing
- [ ] Coverage: ≥85% across all modules
- [ ] Active skills: 26-28 (optimized)
- [ ] Documentation: 100% standardized
- [ ] Dependencies: Fully mapped

---

## Dependencies & Risks

### Risk 1: Documentation Inconsistency
**Mitigation**: Create template first, apply systematically

### Risk 2: Test Coverage Gaps
**Mitigation**: Use established Tier 1 patterns, parallel execution

### Risk 3: Consolidation Breaking Changes
**Mitigation**: Identify candidates first, test thoroughly before execution

### Risk 4: Context/Knowledge Loss
**Mitigation**: Document consolidation rationale, maintain archived skills for reference

---

## Current Status Baseline

**Skills**: 28 active + 22 archived  
**Tests**: 3253 passing (Phase 4 complete)  
**Coverage**: Variable (some skills untested)  
**Documentation**: Inconsistent structure  
**Dependencies**: Not yet mapped

---

## Deliverables

### Commit 1: Documentation Standardization
```
docs(skills): standardize SKILL.md format and add usage examples

- Create unified SKILL.md template (Overview | Features | Usage | API | Config)
- Standardize structure across 28 active skills
- Add practical code examples to 20 skills
- Create skills/TEMPLATE.md as reference

Improves discoverability and maintainability.
All SKILL.md files now follow consistent format.
```

### Commit 2: Test Coverage Phase 1
```
feat(skills): add test coverage for critical runtime skills

- Add tests for analyticsEngine (8 tests)
- Add tests for metricsCollector (8 tests)
- Add tests for healthCheck (6 tests)
- Tests cover: initialization, execution, error handling, edge cases

Coverage improved to ≥85% for critical skills.
All tests passing on first run.
```

### Commit 3: Test Coverage Phase 2
```
feat(skills): add test coverage for remaining skills

- Add tests for cacheManager, performanceTracing, quotaEnforcer (24 tests)
- Follow established patterns from Phase 4
- All tests passing

Overall coverage now ≥80% across all active skills.
```

### Commit 4: Consolidation & Versioning
```
refactor(skills): consolidate overlapping functionality

- Consolidate [Skill X] and [Skill Y] into unified implementation
- Archive obsolete implementations
- Update config/skills.yaml registry
- Add versioning strategy documentation

Reduces decision load, improves maintainability.
All tests passing, no regressions.
```

---

## Parallel Work Streams

These streams can execute in parallel:
- Stream 1 & 2 can run concurrently (independent)
- Stream 3 depends on completion of Streams 1 & 2

### Recommended Sequencing
1. **Day 1**: Start Stream 1 (docs) + Stream 2 audit in parallel
2. **Day 2-3**: Finish Stream 1, execute Stream 2 test implementation
3. **Day 4-5**: Stream 3 audit while Stream 2 completes
4. **Day 6-7**: Stream 3 consolidations

---

## Next Immediate Steps

1. **Create SKILL.md Template** (30 min)
   ```bash
   cp skills/SKILL_TEMPLATE.md skills/SKILL_TEMPLATE_UNIFIED.md
   # Enhance with comprehensive sections
   ```

2. **Audit Current Documentation** (1 hour)
   ```bash
   # Find skills without Usage sections
   for dir in skills/*/; do
     if ! grep -q "^## Usage" "$dir/SKILL.md" 2>/dev/null; then
       echo "Missing Usage: $dir"
     fi
   done
   ```

3. **Start Documentation Updates** (parallel)
   ```bash
   # Apply template to first 5 skills
   # Test examples work
   # Commit when complete
   ```

---

## Related Documentation

- **Skills Organization**: [`.claude/rules/SKILLS_ORGANIZATION.md`](.claude/rules/SKILLS_ORGANIZATION.md)
- **Phase 4 Execution** (complete): [`skills/PHASE_4_EXECUTION_PLAN.md`](skills/PHASE_4_EXECUTION_PLAN.md)
- **Consolidation Opportunities**: [`skills/CONSOLIDATION_OPPORTUNITIES_2026-08-30.md`](skills/CONSOLIDATION_OPPORTUNITIES_2026-08-30.md)
- **Consolidation Notes**: [`skills/CONSOLIDATION_NOTES.md`](skills/CONSOLIDATION_NOTES.md)

---

## Sign-Off

**Plan Created**: 2026-08-31  
**Branch**: `claude/skill-consolidation-plan-4mwds8`  
**Target Completion**: 2026-09-07  
**Effort Estimate**: 15-20 hours  
**Status**: READY TO EXECUTE

---

**Next Step**: Begin Stream 1 (Documentation Standardization) immediately.
