"""Test suite for Phase 5 sync script transformations.

Validates:
- ScriptError integration across all sync scripts
- DryRunContext functionality
- Subprocess timeout protection
- Git command viability checks
- Proper exception handling and exit codes
"""

import logging
import pytest
import sys
from pathlib import Path
from unittest.mock import patch, MagicMock
from scripts.utils.scriptError import (
    ScriptError,
    ValidationError,
    DependencyError,
    TimeoutError as ScriptTimeoutError,
    FileNotFoundError as ScriptFileNotFoundError,
)
from scripts.utils.sync_helpers import (
    run_git_command,
    run_subprocess,
    check_viability,
    verify_git_repo,
    verify_remote_reachable,
)
from scripts.utils.dryRunSupport import (
    DryRunContext,
    add_dry_run_argument,
    add_verbose_argument,
)


class TestSyncHelpers:
    """Test sync_helpers module."""

    def testRunGitCommandSuccess(self):
        """Test successful git command execution."""
        output, returncode = run_git_command(
            ["git", "--version"],
            timeout=30
        )
        assert returncode == 0
        assert "git version" in output

    def testRunGitCommandTimeout(self):
        """Test git command timeout."""
        with pytest.raises(ScriptTimeoutError):
            run_git_command(
                ["sleep", "10"],
                timeout=1
            )

    def testRunGitCommandNotFound(self):
        """Test git command with invalid working directory."""
        with pytest.raises(ScriptFileNotFoundError):
            run_git_command(
                ["git", "status"],
                cwd="/nonexistent/path",
                timeout=5
            )

    def testRunSubprocessSuccess(self):
        """Test successful subprocess execution."""
        output, returncode = run_subprocess(
            ["python", "--version"],
            timeout=10
        )
        assert returncode == 0 or returncode == 1  # Some versions return 1

    def testRunSubprocessTimeout(self):
        """Test subprocess timeout."""
        with pytest.raises(ScriptTimeoutError):
            run_subprocess(
                ["sleep", "10"],
                timeout=1
            )

    def testCheckViabilityMissingCommand(self):
        """Test check_viability with missing command."""
        with pytest.raises(DependencyError):
            check_viability(required_commands=["nonexistent_command_xyz"])

    def testCheckViabilityMissingFile(self):
        """Test check_viability with missing file."""
        with pytest.raises(ScriptFileNotFoundError):
            check_viability(required_files=["/nonexistent/file.txt"])

    def testCheckViabilitySuccess(self):
        """Test check_viability with available tools."""
        result = check_viability(required_commands=["python"])
        assert result is True

    def testVerifyGitRepo(self):
        """Test verify_git_repo with current directory."""
        result = verify_git_repo(".")
        assert result is True

    def testVerifyGitRepoInvalid(self):
        """Test verify_git_repo with non-repo directory."""
        with pytest.raises(DependencyError):
            verify_git_repo("/tmp")

    @patch("subprocess.run")
    def testVerifyRemoteReachable(self, mockRun):
        """Test verify_remote_reachable with mocked git."""
        mockRun.return_value = MagicMock(returncode=0, stdout="", stderr="")
        result = verify_remote_reachable(".", remote="origin", timeout=30)
        assert result is True


class TestDryRunContext:
    """Test DryRunContext class."""

    def testDryRunWriteFile(self, tmp_path):
        """Test dry-run write_file operation."""
        ctx = DryRunContext(dry_run=True)
        testFile = tmp_path / "test.txt"

        ctx.write_file(str(testFile), "test content")

        assert not testFile.exists()  # Dry-run should not create file
        assert len(ctx.operations) == 1
        assert ctx.operations[0]["type"] == "write"

    def testWriteFileActual(self, tmp_path):
        """Test actual write_file operation."""
        ctx = DryRunContext(dry_run=False)
        testFile = tmp_path / "test.txt"

        ctx.write_file(str(testFile), "test content")

        assert testFile.exists()
        assert testFile.read_text() == "test content"

    def testDryRunRemoveFile(self, tmp_path):
        """Test dry-run remove_file operation."""
        testFile = tmp_path / "test.txt"
        testFile.write_text("content")

        ctx = DryRunContext(dry_run=True)
        ctx.remove_file(str(testFile))

        assert testFile.exists()  # Dry-run should not delete
        assert len(ctx.operations) == 1

    def testRemoveFileActual(self, tmp_path):
        """Test actual remove_file operation."""
        testFile = tmp_path / "test.txt"
        testFile.write_text("content")

        ctx = DryRunContext(dry_run=False)
        ctx.remove_file(str(testFile))

        assert not testFile.exists()

    def testDryRunMkdir(self, tmp_path):
        """Test dry-run mkdir operation."""
        ctx = DryRunContext(dry_run=True)
        testDir = tmp_path / "newdir"

        ctx.mkdir(str(testDir))

        assert not testDir.exists()  # Dry-run should not create
        assert len(ctx.operations) == 1

    def testMkdirActual(self, tmp_path):
        """Test actual mkdir operation."""
        ctx = DryRunContext(dry_run=False)
        testDir = tmp_path / "newdir"

        ctx.mkdir(str(testDir))

        assert testDir.exists()
        assert testDir.is_dir()

    def testReportSummaryEmpty(self, caplog):
        """Test report_summary with no operations."""
        ctx = DryRunContext(dry_run=False)
        with caplog.at_level(logging.INFO):
            ctx.report_summary()

        assert "No operations" in caplog.text

    def testReportSummary(self, tmp_path, caplog):
        """Test report_summary with operations."""
        ctx = DryRunContext(dry_run=False)
        testFile = tmp_path / "test.txt"

        ctx.write_file(str(testFile), "content")
        ctx.mkdir(str(tmp_path / "newdir"))

        with caplog.at_level(logging.INFO):
            ctx.report_summary()

        assert "Total operations" in caplog.text or "EXECUTED" in caplog.text


class TestArgumentParsing:
    """Test argument parsing utilities."""

    @patch("sys.argv", ["script.py"])
    def testAddDryRunArgument(self):
        """Test add_dry_run_argument helper."""
        import argparse
        parser = argparse.ArgumentParser()
        add_dry_run_argument(parser)
        args = parser.parse_args()
        assert hasattr(args, "dry_run")
        assert args.dry_run is False

    @patch("sys.argv", ["script.py", "--dry-run"])
    def testAddDryRunArgumentSet(self):
        """Test add_dry_run_argument with flag."""
        import argparse
        parser = argparse.ArgumentParser()
        add_dry_run_argument(parser)
        args = parser.parse_args()
        assert args.dry_run is True

    @patch("sys.argv", ["script.py"])
    def testAddVerboseArgument(self):
        """Test add_verbose_argument helper."""
        import argparse
        parser = argparse.ArgumentParser()
        add_verbose_argument(parser)
        args = parser.parse_args()
        assert hasattr(args, "verbose")
        assert args.verbose is False

    @patch("sys.argv", ["script.py", "-v"])
    def testAddVerboseArgumentSet(self):
        """Test add_verbose_argument with short flag."""
        import argparse
        parser = argparse.ArgumentParser()
        add_verbose_argument(parser)
        args = parser.parse_args()
        assert args.verbose is True


class TestScriptErrorIntegration:
    """Test ScriptError exception handling."""

    def testScriptErrorExitCodes(self):
        """Test ScriptError exit code mapping."""
        validationErr = ValidationError("test")
        assert validationErr.exit_code == 2

        depErr = DependencyError("test")
        assert depErr.exit_code == 7

        timeoutErr = ScriptTimeoutError("test")
        assert timeoutErr.exit_code == 6

    def testScriptErrorDetails(self):
        """Test ScriptError details logging."""
        err = ValidationError(
            "Configuration invalid",
            details={"file": "config.yaml", "reason": "missing key"},
        )
        assert "Configuration invalid" in str(err)


@pytest.mark.integration
class TestTier1Orchestrators:
    """Integration tests for Tier 1 orchestrators."""

    @patch("sys.argv", ["script.py", "--dry-run"])
    def testAutosyncExecutable(self):
        """Test autosync.py imports and argparse works."""
        from scripts.sync import autosync
        import argparse

        # Verify module has main function
        assert hasattr(autosync, "main")
        assert callable(autosync.main)

    @patch("sys.argv", ["script.py", "--dry-run"])
    def testFullSyncOrchestratorExecutable(self):
        """Test full_sync_orchestrator.py imports."""
        from scripts.sync.repos import full_sync_orchestrator

        assert hasattr(full_sync_orchestrator, "main")
        assert callable(full_sync_orchestrator.main)

    @patch("sys.argv", ["script.py", "--dry-run"])
    def testDailySyncExecutable(self):
        """Test daily_sync.py imports."""
        from scripts.sync.repos import daily_sync

        assert hasattr(daily_sync, "main")
        assert callable(daily_sync.main)

    @patch("sys.argv", ["script.py", "--dry-run"])
    def testDocAutosyncExecutable(self):
        """Test docs/autosync.py imports."""
        from scripts.sync.docs import autosync as docsAutosync

        assert hasattr(docsAutosync, "main")
        assert callable(docsAutosync.main)


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
