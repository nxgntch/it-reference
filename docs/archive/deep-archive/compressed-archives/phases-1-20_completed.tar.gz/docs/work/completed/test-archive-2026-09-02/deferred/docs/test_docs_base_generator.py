"""Tests for BaseDocGenerator (Phase 5.2 foundation)."""

import logging
from pathlib import Path
from tempfile import TemporaryDirectory

import pytest

from tests.utilities.assertionHelpers import (
    assertConditionMet,
    assertListLength,
    assertMetricValue,
)
from scripts.docs.base import BaseDocGenerator

pytestmark = pytest.mark.docs

pytestmark = [pytest.mark.unit, pytest.mark.docs]

class TestBaseDocGeneratorInitialization:
    """Test BaseDocGenerator initialization."""

    def testInitializesWithDefaults(self):
        """Test initialization with default parameters."""
        gen = BaseDocGenerator("test")
        assert gen.name == "test"
        assert gen.dry_run is False
        assert gen.verbose is False
        assert gen.stats["filesGenerated"] == 0

    def testInitializesWithDryRun(self):
        """Test initialization with dry_run=True."""
        gen = BaseDocGenerator("test", dry_run=True)
        assert gen.dry_run is True

    def testInitializesWithVerbose(self):
        """Test initialization with verbose=True."""
        gen = BaseDocGenerator("test", verbose=True)
        assert gen.verbose is True
        assert gen.logger.level == logging.DEBUG

class TestFileOperations:
    """Test file I/O operations."""

    def testReadsFileSuccessfully(self):
        """Test reading a file."""
        with TemporaryDirectory() as tmpDir:
            testFile = Path(tmpDir) / "test.txt"
            testFile.write_text("test content")
            gen = BaseDocGenerator("test")
            content = gen.readFile(testFile)
            assert content == "test content"

    def testReturnsNoneForMissingFile(self):
        """Test reading a missing file."""
        gen = BaseDocGenerator("test")
        content = gen.readFile(Path("nonexistent.txt"))
        assert content is None
        assert gen.stats["errors"] == 1

    def testWritesFileSuccessfully(self):
        """Test writing a file."""
        with TemporaryDirectory() as tmpDir:
            outputFile = Path(tmpDir) / "output.txt"
            gen = BaseDocGenerator("test")
            success = gen.writeFile(outputFile, "test content")
            assert success is True
            assert outputFile.exists()
            assert outputFile.read_text() == "test content"
            assert gen.stats["filesGenerated"] == 1

    def testWriteCreatesParentDirs(self):
        """Test that write creates parent directories."""
        with TemporaryDirectory() as tmpDir:
            outputFile = Path(tmpDir) / "subdir" / "output.txt"
            gen = BaseDocGenerator("test")
            success = gen.writeFile(outputFile, "content")
            assert success is True
            assert outputFile.exists()

    def testDryRunDoesntWriteFile(self):
        """Test that dry-run doesn't write files."""
        with TemporaryDirectory() as tmpDir:
            outputFile = Path(tmpDir) / "output.txt"
            gen = BaseDocGenerator("test", dry_run=True)
            success = gen.writeFile(outputFile, "content")
            assert success is True
            assert not outputFile.exists()

class TestMarkdownFormatting:
    """Test Markdown formatting utilities."""

    def testFormatsTable(self):
        """Test Markdown table formatting."""
        gen = BaseDocGenerator("test")
        headers = ["Name", "Status", "Count"]
        rows = [
            ["Task 1", "Complete", "10"],
            ["Task 2", "In Progress", "5"],
        ]
        table = gen.formatMarkdownTable(headers, rows)
        assert "| Name | Status | Count |" in table
        assert "| --- | --- | --- |" in table
        assert "| Task 1 | Complete | 10 |" in table

    def testFormatsTableEmptyRows(self):
        """Test Markdown table with no rows."""
        gen = BaseDocGenerator("test")
        headers = ["Name", "Status"]
        rows = []
        table = gen.formatMarkdownTable(headers, rows)
        assert "| Name | Status |" in table
        assert "| --- | --- |" in table

    def testFormatsList(self):
        """Test Markdown list formatting."""
        gen = BaseDocGenerator("test")
        items = ["Item 1", "Item 2", "Item 3"]
        lst = gen.formatMarkdownList(items)
        assert "- Item 1" in lst
        assert "- Item 2" in lst
        assert "- Item 3" in lst

    def testFormatsListWithIndent(self):
        """Test Markdown list with indentation."""
        gen = BaseDocGenerator("test")
        items = ["Item 1", "Item 2"]
        lst = gen.formatMarkdownList(items, indent=1)
        assert "  - Item 1" in lst
        assert "  - Item 2" in lst

class TestStatistics:
    """Test statistics tracking."""

    def testIncrementsFilesGenerated(self):
        """Test incrementing filesGenerated stat."""
        gen = BaseDocGenerator("test")
        gen.incrementStat("filesGenerated")
        assert gen.stats["filesGenerated"] == 1

    def testIncrementsWithAmount(self):
        """Test incrementing stat by custom amount."""
        gen = BaseDocGenerator("test")
        gen.incrementStat("filesGenerated", 5)
        assert gen.stats["filesGenerated"] == 5

    def testGetsSummary(self):
        """Test getting statistics summary."""
        gen = BaseDocGenerator("test")
        gen.incrementStat("filesGenerated", 3)
        summary = gen.getSummary()
        assert summary["filesGenerated"] == 3
        assert "durationSeconds" in summary
        assert "hasErrors" in summary

    def testSummaryIndicatesErrors(self):
        """Test that summary shows errors."""
        gen = BaseDocGenerator("test")
        gen.logError("test error")
        summary = gen.getSummary()
        assert summary["errors"] == 1
        assert summary["hasErrors"] is True

class TestErrorTracking:
    """Test error tracking."""

    def testLogsError(self):
        """Test logging error."""
        gen = BaseDocGenerator("test")
        gen.logError("test error")
        assert gen.stats["errors"] == 1
        assert "test error" in gen.errors

    def testGetsErrors(self):
        """Test retrieving errors."""
        gen = BaseDocGenerator("test")
        gen.logError("error 1")
        gen.logError("error 2")
        errors = gen.getErrors()
        assert len(errors) == 2
        assert "error 1" in errors

    def testHasErrors(self):
        """Test checking if errors exist."""
        gen = BaseDocGenerator("test")
        assert gen.hasErrors() is False
        gen.logError("error")
        assert gen.hasErrors() is True
