"""Plugin directory structure and file builder fixtures."""

import json

import pytest


class FileBuilder:
    """Utility class for creating common test file structures."""

    def __init__(self, basePath):
        self.basePath = basePath

    def createPluginStructure(self, withAgents=True, withSkills=True, withHooks=True):
        """Create a complete plugin directory structure."""
        if withHooks:
            hooksDir = self.basePath / "hooks"
            hooksDir.mkdir(exist_ok=True)
            (hooksDir / "hooks.json").write_text(
                json.dumps(
                    {
                        "hooks": {
                            "SessionStart": [{"hooks": [{"type": "command", "script": "init.sh"}]}]
                        }
                    }
                )
            )
        if withAgents:
            agentsDir = self.basePath / "agents"
            agentsDir.mkdir(exist_ok=True)
            (agentsDir / "README.md").write_text("# Agents")
            (agentsDir / "planner.md").write_text("""---
name: planner
model: claude-sonnet-5
description: Planning agent
---
Content here.""")

        if withSkills:
            skillsDir = self.basePath / "skills"
            skillsDir.mkdir(exist_ok=True)
            skillDir = skillsDir / "codeReview"
            skillDir.mkdir(exist_ok=True)
            (skillDir / "SKILL.md").write_text("""---
name: codeReview
description: Code review skill
---

## Description

A skill for reviewing code and providing feedback.

## Configuration

Configure with appropriate settings for your environment.

## Usage

Use this skill to review code changes.
""")
        return self.basePath

    def createAgentFile(
        self,
        filename="testAgent.md",
        name="testAgent",
        model="claude-sonnet-5",
        description="Test agent",
        effort="high",
        tools=None,
    ):
        """Create an agent markdown file with metadata."""
        if tools is None:
            tools = ["codeReview"]
        agentFile = self.basePath / filename
        agentFile.write_text(f"""---
name: {name}
model: {model}
description: {description}
effort: {effort}
tools: {tools}
---

This is a test agent.
Additional details about the agent's capabilities.
""")
        return agentFile

    def createSkillFile(
        self,
        filename="SKILL.md",
        name="testSkill",
        displayName=None,
        description="Test skill",
        category="testing",
    ):
        """Create a skill SKILL.md file with metadata."""
        if displayName is None:
            displayName = name
        skillFile = self.basePath / filename
        skillFile.write_text(f"""---
name: {name}
displayName: {displayName}
description: {description}
category: {category}
---

This is a test skill.
""")
        return skillFile

    def createMetricsFile(self):
        """Create path to metrics.jsonl file."""
        return self.basePath / "metrics.jsonl"

    def createSampleRulesFile(self):
        """Create a sample rules file."""
        rulesFile = self.basePath / "rules.md"
        rulesFile.write_text("""# Sample Rule File
## Naming Conventions
- Use camelCase for variables
- Use PascalCase for classes
- Use UPPER_SNAKE_CASE for constants

## Testing Requirements
- Minimum 85% coverage
- Follow AAA pattern
""")
        return rulesFile

    def createValidationDir(self):
        """Return path to validation directory."""
        validDir = self.basePath / "validation"
        validDir.mkdir(exist_ok=True)
        return validDir

    def createInvalidPluginStructure(
        self, withInvalidHooks=True, withInvalidAgent=True, withInvalidSkills=True
    ):
        """Create a plugin directory structure with invalid content."""
        if withInvalidHooks:
            hooksDir = self.basePath / "hooks"
            hooksDir.mkdir(exist_ok=True)
            (hooksDir / "hooks.json").write_text(json.dumps({"hooks": {"event": "invalid"}}))

        if withInvalidAgent:
            agentsDir = self.basePath / "agents"
            agentsDir.mkdir(exist_ok=True)
            (agentsDir / "badAgent.md").write_text("No frontmatter")

        if withInvalidSkills:
            skillsDir = self.basePath / "skills"
            skillsDir.mkdir(exist_ok=True)
            skillDir = skillsDir / "badSkill"
            skillDir.mkdir(exist_ok=True)
            (skillDir / "SKILL.md").write_text("No frontmatter")

        return self.basePath


@pytest.fixture
def tmpFileBuilder(tmp_path):
    """Build temporary file structures for testing."""
    return FileBuilder(tmp_path)


@pytest.fixture
def tmpPluginDir(tmpFileBuilder):
    """Temporary directory with valid plugin structure."""
    return tmpFileBuilder.createPluginStructure()


@pytest.fixture
def tmpInvalidPluginDir(tmpFileBuilder):
    """Temporary directory with invalid plugin structure (under invalid/ subpath)."""
    invalidPath = tmpFileBuilder.basePath / "invalid"
    invalidPath.mkdir(exist_ok=True)
    return FileBuilder(invalidPath).createInvalidPluginStructure()


@pytest.fixture
def validPluginStructure(tmpFileBuilder):
    """Create a valid plugin directory structure (delegates to FileBuilder)."""
    return tmpFileBuilder.createPluginStructure()


@pytest.fixture
def pluginStructure(tmpDocsDir):
    """Create a complete plugin structure for documentation-oriented tests."""
    agentsDir = tmpDocsDir / "agents"
    agentsDir.mkdir()
    (agentsDir / "README.md").write_text("# Agents")
    (agentsDir / "planner.md").write_text(
        "---\nname: planner\nmodel: claude-sonnet-5\neffort: medium\ndescription: Planning agent\n---\n# Planner Agent"
    )
    (agentsDir / "reviewer.md").write_text(
        "---\nname: reviewer\nmodel: claude-opus-5\neffort: high\ndescription: Review agent\n---\n# Reviewer Agent"
    )
    docsDir = tmpDocsDir / "docs"
    docsDir.mkdir()
    (docsDir / "README.md").write_text("# Docs\nDocumentation root.")
    (docsDir / "AGENT_ARCHITECTURE.md").write_text("# Agents\nAgent architecture.")
    (docsDir / "AGENT_INVENTORY.md").write_text("# Agents List\nAgent inventory.")
    (docsDir / "SKILL_INVENTORY.md").write_text("# Skills List\nSkill inventory.")
    skillsDir = tmpDocsDir / "skills"
    skillsDir.mkdir()
    (skillsDir / "README.md").write_text("# Skills")
    code_review = skillsDir / "codeReview"
    code_review.mkdir()
    (code_review / "SKILL.md").write_text("""---
name: codeReview
displayName: Code Review
description: Code review skill
triggers: [manual]
---
Code review skill content.""")
    security = skillsDir / "security"
    security.mkdir()
    (security / "SKILL.md").write_text("""---
name: security
displayName: Security Analysis
description: Security analysis skill
triggers: [manual, scheduled]
---
Security skill content.""")

    configDir = tmpDocsDir / "config"
    configDir.mkdir()
    (configDir / "agents.yaml").write_text("agents: []")
    (configDir / "skills.yaml").write_text("skills: []")

    return tmpDocsDir


@pytest.fixture
def metricsFile(tmpLogsDir, tmpFileBuilder):
    """Path to metrics.jsonl file."""
    return tmpFileBuilder.createMetricsFile()


@pytest.fixture
def validAgentFile(tmpDocsDir):
    """Create a valid agent file with metadata."""
    agentFile = tmpDocsDir / "testAgent.md"
    agentFile.write_text("""---
name: testAgent
model: claude-sonnet-5
description: A test agent for documentation
effort: high
tools: [codeReview, security]
---

This is a test agent that helps with code review and security analysis.
It provides comprehensive feedback on code quality.
Additional details about the agent's capabilities.
More information here.
Final line of content.
""")
    return agentFile


@pytest.fixture
def validSkillFile(tmpDocsDir):
    """Create a valid skill file with metadata."""
    skillFile = tmpDocsDir / "SKILL.md"
    skillFile.write_text("""---
name: testSkill
displayName: Test Skill
description: A test skill for documentation
triggers: [manual, scheduled]
category: testing
---

This is a test skill that demonstrates documentation generation.
It includes various metadata fields.
""")
    return skillFile


@pytest.fixture
def sampleRulesFile(tmpFileBuilder):
    """Sample .claude/rules file content for testing."""
    return tmpFileBuilder.createSampleRulesFile()
