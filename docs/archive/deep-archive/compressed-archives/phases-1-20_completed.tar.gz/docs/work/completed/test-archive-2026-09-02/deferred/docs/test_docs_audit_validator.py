"""Tests for AuditValidator (Phase 5.2)."""

from pathlib import Path
from tempfile import TemporaryDirectory

import pytest

from tests.utilities.assertionHelpers import (
    assertConditionMet,
    assertListLength,
    assertMetricValue,
)
from scripts.docs.audit_validator import AuditValidator

pytestmark = pytest.mark.docs

pytestmark = [pytest.mark.unit, pytest.mark.docs]

class TestAuditValidatorInitialization:
    """Test AuditValidator initialization."""

    def testInitializesWithDefaults(self):
        """Test initialization with default parameters."""
        validator = AuditValidator()
        assert validator.name == "audit-validator"
        assert validator.auditPath == Path("AUDIT.md")

class TestValidateStructure:
    """Test AUDIT.md structure validation."""

    def testValidatesValidStructure(self):
        """Test validating a valid AUDIT.md."""
        with TemporaryDirectory() as tmpDir:
            auditFile = Path(tmpDir) / "AUDIT.md"
            auditFile.write_text(
                "# Audit Trail\n"
                "\n"
                "## Current Status\n"
                "✅ Phase 1: Complete\n"
                "\n"
                "## Phase History\n"
                "Historical phases...\n",
                encoding="utf-8",
            )
            validator = AuditValidator(audit_path=auditFile)
            isValid, issues = validator.validateStructure()
            assert isValid is True
            assert len(issues) == 0

    def testDetectsMissingTitle(self):
        """Test detecting missing title section."""
        with TemporaryDirectory() as tmpDir:
            auditFile = Path(tmpDir) / "AUDIT.md"
            auditFile.write_text("## Current Status\n" "✅ Phase 1: Complete\n", encoding="utf-8")
            validator = AuditValidator(audit_path=auditFile)
            isValid, issues = validator.validateStructure()
            assert isValid is False
            assert len(issues) > 0

    def testHandlesMissingFile(self):
        """Test handling missing AUDIT.md."""
        validator = AuditValidator(audit_path=Path("nonexistent.md"))
        isValid, issues = validator.validateStructure()
        assert isValid is False
        assert len(issues) > 0

class TestCountPhases:
    """Test phase counting."""

    def testCountsCompletedPhases(self):
        """Test counting completed phases."""
        with TemporaryDirectory() as tmpDir:
            auditFile = Path(tmpDir) / "AUDIT.md"
            auditFile.write_text(
                "✅ **Phase 1**: Complete\n"
                "✅ **Phase 2**: Complete\n"
                "⏳ **Phase 3**: In Progress\n",
                encoding="utf-8",
            )
            validator = AuditValidator(audit_path=auditFile)
            counts = validator.countPhases()
            assert counts["completed"] == 2
            assert counts["inProgress"] == 1
            assert counts["total"] == 3

    def testCountsNotStarted(self):
        """Test counting not-started phases."""
        with TemporaryDirectory() as tmpDir:
            auditFile = Path(tmpDir) / "AUDIT.md"
            auditFile.write_text("❌ **Phase 1**: Not Started\n", encoding="utf-8")
            validator = AuditValidator(audit_path=auditFile)
            counts = validator.countPhases()
            assert counts["notStarted"] == 1

class TestValidate:
    """Test full validation."""

    def testReturnsValidationReport(self):
        """Test that validate returns a report."""
        with TemporaryDirectory() as tmpDir:
            auditFile = Path(tmpDir) / "AUDIT.md"
            auditFile.write_text(
                "# Audit Trail\n"
                "## Current Status\n"
                "✅ Phase 1: Complete\n"
                "## Phase History\n",
                encoding="utf-8",
            )
            validator = AuditValidator(audit_path=auditFile)
            report = validator.validate()
            assert "isValid" in report
            assert "issues" in report
            assert "phaseCounts" in report
            assert "statistics" in report
