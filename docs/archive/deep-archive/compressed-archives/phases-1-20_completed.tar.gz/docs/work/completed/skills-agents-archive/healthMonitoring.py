"""Health monitoring skill for director agent
Check system health before routing high-priority tasks.
Provides health status, recent degradations, and recommendations.
"""

from dataclasses import dataclass
from typing import Any, Dict, List


@dataclass
class HealthContext:
    """Current system health context"""

    overall_status: str  # healthy, degraded, critical, unknown
    healthy_services: int
    degraded_services: int
    critical_services: int
    recent_changes: List[Dict[str, Any]]
    recommendations: List[str]
    safe_to_route_priority_work: bool
    routing_impact: str  # minimal, moderate, high


class HealthMonitoringSkill:
    """Consult system health monitoring for routing decisions"""

    def __init__(self, health_monitor):
        """Initialize with HealthMonitor instance"""
        self.health_monitor = health_monitor

    def getSystemHealth(self) -> HealthContext:
        """Get current system health status
        Returns:
           HealthContext with status, service breakdown, and routing guidance
        """
        # Query health monitor
        all_services = self.health_monitor.services.values()
        healthy = sum(1 for s in all_services if s.status == "healthy")
        degraded = sum(1 for s in all_services if s.status == "degraded")
        critical = sum(1 for s in all_services if s.status == "critical")
        # Get recent status changes (last hour)
        recent_changes = self._getRecentStatusChanges(max_entries=5)
        # Determine if it's safe to route priority work
        safe_to_route = critical == 0 and degraded <= 1
        routing_impact = self._assessRoutingImpact(critical, degraded)
        # Generate recommendations
        recommendations = self._generateRecommendations(critical, degraded, recent_changes)
        overall = "healthy" if critical == 0 else ("degraded" if degraded > 0 else "critical")
        return HealthContext(
            overall_status=overall,
            healthy_services=healthy,
            degraded_services=degraded,
            critical_services=critical,
            recent_changes=recent_changes,
            recommendations=recommendations,
            safe_to_route_priority_work=safe_to_route,
            routing_impact=routing_impact,
        )

    def checkServiceHealth(self, service_name: str) -> Dict[str, Any]:
        """Check specific service health
        Args:
           service_name: Name of service to check
        Returns:
           Status, last check time, uptime percentage, recent issues
        """
        service = self.health_monitor.services.get(service_name)
        if not service:
            return {"status": "unknown", "message": f"Service {service_name} not found"}
        return {
            "service": service_name,
            "status": service.status,
            "uptime": f"{service.uptime_percentage:.1f}%",
            "last_check": service.last_check.isoformat() if service.last_check else None,
            "consecutive_failures": service.consecutive_failures,
            "recent_issues": self._getServiceIssues(service_name, max_entries=3),
        }

    def shouldDelayHighPriorityWork(self, work_type: str = "agent_invocation") -> Dict[str, Any]:
        """Determine if high-priority work should be delayed
        Args:
           work_type: Type of work (agent_invocation, deployment, data_processing)
        Returns:
           Recommendation (delay_work, proceed_with_caution, proceed_normally)
           with reasoning
        """
        health = self.getSystemHealth()
        # Critical issues always warrant delay
        if health.critical_services > 0:
            return {
                "recommendation": "delay_work",
                "reason": f"{health.critical_services} critical service(s) down",
                "estimated_recovery": self._estimateRecoveryTime(),
                "severity": "critical",
            }
        # Single degraded service: proceed with caution
        if health.degraded_services == 1:
            return {
                "recommendation": "proceed_with_caution",
                "reason": "1 service degraded, may impact performance",
                "monitoring": "Increase alert sensitivity during this work",
                "severity": "moderate",
            }
        # All healthy: proceed normally
        return {
            "recommendation": "proceed_normally",
            "reason": "All critical services healthy",
            "severity": "low",
        }

    def _getRecentStatusChanges(self, max_entries: int = 5) -> List[Dict[str, Any]]:
        """Get recent service status changes"""
        changes = []
        for service in self.health_monitor.services.values():
            if service.status_history and len(service.status_history) > 1:
                recent = service.status_history[-1]
                previous = service.status_history[-2]
                if recent["status"] != previous["status"]:
                    changes.append(
                        {
                            "service": service.name,
                            "from_status": previous["status"],
                            "to_status": recent["status"],
                            "timestamp": recent["timestamp"].isoformat(),
                        }
                    )
        # Sort by timestamp, most recent first
        changes.sort(key=lambda x: x["timestamp"], reverse=True)
        return changes[:max_entries]

    def _assessRoutingImpact(self, critical: int, degraded: int) -> str:
        """Assess how health issues impact task routing"""
        if critical > 0:
            return "high"
        if degraded > 1:
            return "high"
        if degraded == 1:
            return "moderate"
        return "minimal"

    def _generateRecommendations(
        self,
        critical: int,
        degraded: int,
        recent_changes: List[Dict[str, Any]],
    ) -> List[str]:
        """Generate routing recommendations based on health"""
        recs = []

        if critical > 0:
            recs.append(f"WAIT: {critical} critical service(s) require immediate attention")

        if degraded > 0:
            recs.append(f"CAUTION: {degraded} service(s) degraded, monitor closely")

        # Look for patterns
        if recent_changes:
            unstable = [c for c in recent_changes if c.get("from_status") != "healthy"]
            if len(unstable) >= 2:
                recs.append("PATTERN: Multiple services recently changed status—consider delay")

        if not recs:
            recs.append("✓ System healthy—proceed with normal routing")

        return recs

    def _getServiceIssues(self, service_name: str, max_entries: int = 3) -> List[str]:
        """Get recent issues for a service"""
        service = self.health_monitor.services.get(service_name)
        if not service or not hasattr(service, "issues"):
            return []
        return service.issues[-max_entries:] if service.issues else []

    def _estimateRecoveryTime(self) -> str:
        """Estimate when service will recover (heuristic)"""
        # In production, this would query escalation policies, known issues, etc.
        return "30-60 minutes (estimated based on service type)"


def healthMonitoring(health_monitor) -> HealthMonitoringSkill:
    """Factory function for dependency injection
    Usage in director agent:
       from skills.agents.healthMonitoring import healthMonitoring
       health_skill = healthMonitoring(system_health_monitor)
       context = health_skill.getSystemHealth()
       if not context.safe_to_route_priority_work:
          # delay routing high-priority tasks
    """
    return HealthMonitoringSkill(health_monitor)
