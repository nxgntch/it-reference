"""Dashboard consumer skill for all agents
Consult executive, operations, and metrics dashboards before making decisions.
Provides quick status summaries for context-aware routing and prioritization.
"""

from dataclasses import dataclass
from typing import Any, Dict


@dataclass
class DashboardSnapshot:
    """Quick snapshot of key dashboard metrics"""

    system_health: str  # healthy, degraded, critical
    active_alerts: int
    alert_severity_max: str  # info, warning, critical, emergency
    budget_status: str  # ok, warning, critical, exceeded
    budget_percent_used: float
    api_latency_p95: float  # milliseconds
    error_rate: float  # percentage
    key_metrics: Dict[str, Any]
    is_safe_for_cpu_intensive_work: bool
    is_safe_for_cost_intensive_work: bool


class DashboardConsumerSkill:
    """Query dashboards for operational context in routing decisions"""

    def __init__(self, dashboard_registry):
        """Initialize dashboard consumer skill.
        Args:
           dashboard_registry: DashboardRegistry instance managing all dashboards
        """
        self.registry = dashboard_registry

    def getExecutiveSnapshot(self) -> DashboardSnapshot:
        """Get executive dashboard snapshot for high-level context
        Returns:
           Key metrics for routing decisions
        """
        exec_dash = self.registry.get_dashboard("executive-dashboard")
        if not exec_dash:
            return self._getDefaultSnapshot()
        latest = exec_dash.get_latest_data()
        if not latest:
            return self._getDefaultSnapshot()
        # Extract key metrics
        health = latest.health.get("overall_status", "unknown")
        alerts = latest.alerts.get("critical", 0) + latest.alerts.get("warning", 0)
        budget = latest.cost.get("budget_percentage", 0.0)
        is_safe_cpu = health == "healthy" and budget < 0.85
        is_safe_cost = latest.cost.get("status") != "exceeded"
        return DashboardSnapshot(
            system_health=health,
            active_alerts=alerts,
            alert_severity_max=self._getMaxSeverity(latest.alerts),
            budget_status=latest.cost.get("status", "unknown"),
            budget_percent_used=budget,
            api_latency_p95=latest.metrics.get("latency_p95", 0.0),
            error_rate=latest.metrics.get("error_rate", 0.0),
            key_metrics=latest.metrics,
            is_safe_for_cpu_intensive_work=is_safe_cpu,
            is_safe_for_cost_intensive_work=is_safe_cost,
        )

    def getMetricsContext(self) -> Dict[str, Any]:
        """Get current metrics dashboard state
        Returns:
           Latency, throughput, error rate, and performance trends
        """
        metrics_dash = self.registry.get_dashboard("metrics-dashboard")
        if not metrics_dash:
            return {"error": "metrics dashboard not available"}
        latest = metrics_dash.get_latest_data()
        if not latest:
            return {"error": "no recent metrics data"}
        return {
            "latency": {
                "p50": latest.metrics.get("latency_p50"),
                "p95": latest.metrics.get("latency_p95"),
                "p99": latest.metrics.get("latency_p99"),
            },
            "throughput": latest.metrics.get("throughput", 0),
            "error_rate": f"{latest.metrics.get('error_rate', 0.0):.2f}%",
            "memory_usage": f"{latest.metrics.get('memory_usage', 0):.1f}%",
            "cpu_usage": f"{latest.metrics.get('cpu_usage', 0):.1f}%",
            "timestamp": latest.timestamp.isoformat(),
        }

    def getAlertsContext(self) -> Dict[str, Any]:
        """Get active alerts for decision-making
        Returns:
           Count by severity, recent alerts, escalation status
        """
        alerts_dash = self.registry.get_dashboard("alerts-dashboard")
        if not alerts_dash:
            return {"error": "alerts dashboard not available"}
        latest = alerts_dash.get_latest_data()
        if not latest:
            return {"error": "no recent alerts data"}
        return {
            "active_count": sum(latest.alerts.values()),
            "by_severity": latest.alerts,
            "has_critical": latest.alerts.get("critical", 0) > 0,
            "has_emergency": latest.alerts.get("emergency", 0) > 0,
            "timestamp": latest.timestamp.isoformat(),
        }

    def getCostContext(self) -> Dict[str, Any]:
        """Get cost and budget context
        Returns:
           Current spend, budget status, forecast, and category breakdown
        """
        cost_dash = self.registry.get_dashboard("cost-dashboard")
        if not cost_dash:
            return {"error": "cost dashboard not available"}
        latest = cost_dash.get_latest_data()
        if not latest:
            return {"error": "no recent cost data"}
        return {
            "current_spend": latest.cost.get("current_spend", 0.0),
            "monthly_budget": latest.cost.get("monthly_budget", 0.0),
            "percent_used": f"{latest.cost.get('budget_percentage', 0.0):.1f}%",
            "status": latest.cost.get("status", "unknown"),
            "forecast": latest.cost.get("monthly_forecast", "N/A"),
            "by_category": latest.cost.get("by_category", {}),
            "timestamp": latest.timestamp.isoformat(),
        }

    def getHealthContext(self) -> Dict[str, Any]:
        """Get service health status
        Returns:
           Status of each service, recent changes, uptime
        """
        health_dash = self.registry.get_dashboard("health-dashboard")
        if not health_dash:
            return {"error": "health dashboard not available"}
        latest = health_dash.get_latest_data()
        if not latest:
            return {"error": "no recent health data"}
        return {
            "overall": latest.health.get("overall_status", "unknown"),
            "services": latest.health.get("services", {}),
            "degraded_count": sum(
                1
                for s in latest.health.get("services", {}).values()
                if s.get("status") == "degraded"
            ),
            "critical_count": sum(
                1
                for s in latest.health.get("services", {}).values()
                if s.get("status") == "critical"
            ),
            "timestamp": latest.timestamp.isoformat(),
        }

    def shouldProceeedWithWork(self, work_type: str) -> Dict[str, Any]:
        """Quick decision: should we proceed with this work type?
        Args:
           work_type: "cpu_intensive", "cost_intensive", "latency_sensitive", "any"
        Returns:
           Boolean decision with reasoning and current context
        """
        snapshot = self.getExecutiveSnapshot()
        # CPU intensive work needs healthy system and low CPU
        if work_type == "cpu_intensive":
            safe = snapshot.is_safe_for_cpu_intensive_work and snapshot.api_latency_p95 < 200
            return {
                "proceed": safe,
                "reason": (
                    "System healthy, low latency"
                    if safe
                    else "System degraded or high latency—delay CPU work"
                ),
                "latency_p95": snapshot.api_latency_p95,
                "system_health": snapshot.system_health,
            }
        # Cost intensive work needs budget headroom
        if work_type == "cost_intensive":
            safe = snapshot.is_safe_for_cost_intensive_work and snapshot.budget_percent_used < 0.80
            return {
                "proceed": safe,
                "reason": (
                    "Budget headroom available"
                    if safe
                    else "Budget constraint—delay expensive work"
                ),
                "budget_used": f"{snapshot.budget_percent_used:.1f}%",
                "budget_status": snapshot.budget_status,
            }
        # Latency sensitive work needs low latency and errors
        if work_type == "latency_sensitive":
            safe = (
                snapshot.system_health == "healthy"
                and snapshot.api_latency_p95 < 100
                and snapshot.error_rate < 1.0
            )
            return {
                "proceed": safe,
                "reason": (
                    "Low latency environment"
                    if safe
                    else "High latency or errors—delay time-critical work"
                ),
                "latency_p95": snapshot.api_latency_p95,
                "error_rate": f"{snapshot.error_rate:.2f}%",
            }
        # Generic work: always safe unless critical alerts
        safe = snapshot.active_alerts < 3
        return {
            "proceed": safe,
            "reason": "Proceed normally" if safe else "Multiple critical alerts—consider delay",
            "active_alerts": snapshot.active_alerts,
        }

    def _getMaxSeverity(self, alerts: Dict[str, int]) -> str:
        """Get maximum severity level from alerts dict"""
        if alerts.get("emergency", 0) > 0:
            return "emergency"
        if alerts.get("critical", 0) > 0:
            return "critical"
        if alerts.get("warning", 0) > 0:
            return "warning"
        return "info"

    def _getDefaultSnapshot(self) -> DashboardSnapshot:
        """Return safe defaults when dashboard unavailable"""
        return DashboardSnapshot(
            system_health="unknown",
            active_alerts=0,
            alert_severity_max="unknown",
            budget_status="unknown",
            budget_percent_used=0.0,
            api_latency_p95=0.0,
            error_rate=0.0,
            key_metrics={},
            is_safe_for_cpu_intensive_work=False,
            is_safe_for_cost_intensive_work=False,
        )


def dashboardConsumer(dashboard_registry) -> DashboardConsumerSkill:
    """Factory function for dependency injection
    Usage in any agent:
       from skills.agents.dashboardConsumer import dashboardConsumer
       dashboard_skill = dashboardConsumer(registry)
       snapshot = dashboard_skill.getExecutiveSnapshot()
       if not snapshot.is_safe_for_cost_intensive_work:
          # delay expensive research tasks
    """
    return DashboardConsumerSkill(dashboard_registry)
