# Development Workflow Gates: Generic Framework

**Reusable phase-based development framework for any project, team, or workflow cycle.**

This framework is project-agnostic and can be applied to software projects of any size and domain. It provides a structured approach to phase-based development with clear gate criteria, acceptance tests, and progression rules.

---

## Table of Contents

1. [Overview & Philosophy](#overview--philosophy)
2. [Core Concepts](#core-concepts)
3. [Phase Gate Template](#phase-gate-template)
4. [Progression Model](#progression-model)
5. [Acceptance Testing Strategy](#acceptance-testing-strategy)
6. [Risk Management](#risk-management)
7. [Implementation Guide](#implementation-guide)
8. [Examples](#examples)
9. [Recursive Application](#recursive-application)

---

## Overview & Philosophy

Development phases partition work into manageable cycles with clear entry/exit gates. Each gate defines **what must be done** before progression, reducing ambiguity and preventing hidden technical debt.

### Why Phase Gates?

- **Clear progression**: Teams know exactly when a phase is complete
- **Quality enforcement**: Objective criteria, not subjective judgment
- **Fail fast**: Issues discovered early (at gates) not late (at integration)
- **Predictable pacing**: Metrics-driven completion assessment
- **Knowledge transfer**: Each gate documents what was delivered

### Core Principle

> **Binary completion**: A phase is either complete (all gates passed) or incomplete (at least one gate failed). No partial credit.

---

## Core Concepts

### 1. Phase

A **phase** is a time-bound, goal-focused cycle of development work. Phases:
- Have clear objectives (what are we building?)
- Have defined deliverables (what did we ship?)
- Have specific completion criteria (how do we know it's done?)
- Require gate approval before advancing to next phase

**Examples**:
- Software project phases: Foundation → Integration → Security → Performance → Deployment
- Feature development: Design → Implementation → Testing → Review → Merge
- Quarterly planning: Planning → Execution → Review → Retrospective

### 2. Criterion (Gate Item)

A **criterion** is one specific requirement that must be met before progressing. Each gate typically has 3-5 criteria.

**Structure of a criterion**:
- **Name**: What must be done (e.g., "Test Coverage ≥85%")
- **Acceptance Test**: How to verify completion (command or checklist)
- **Risks**: What could prevent completion
- **Mitigation**: How to address risks proactively

### 3. Acceptance Test

An **acceptance test** is a concrete, verifiable method to confirm criterion completion. It can be:
- **Automated**: Command that passes/fails (`pytest --cov=app`)
- **Checklist**: Manual verification items (✓ Code reviewed, ✓ Docs updated)
- **Metric**: Measurable outcome (Test count ≥100, Uptime ≥99%)
- **Review**: Gate keeper approval (security review passed, design approved)

### 4. Gate

A **gate** is the decision point between phases. Gates are **all-or-nothing**:
- ✅ PASS: All criteria met → Advance to next phase
- ❌ FAIL: Any criterion unmet → Address failures before advancing

---

## Phase Gate Template

Use this template for every phase in your development workflow.

### Template Structure

```markdown
## Phase X: [Phase Name]

### Purpose
[One sentence: what is the goal of this phase?]

### Objectives
[Bullet list of what should be accomplished]

### Completion Criteria

#### 1. [Criterion Name]

**Criterion**: [What must be done?]

**Acceptance Test**:
[How to verify completion — command, checklist, or metric]

**Verification Checklist**:
- [ ] Item 1
- [ ] Item 2
- [ ] Item 3

**Risks**:
- Risk 1: Description
- Risk 2: Description

**Mitigation**: How to address these risks

---

#### 2. [Next Criterion]
[Repeat pattern above]

### Gate Progression

To advance from Phase X to Phase X+1:
1. Verify all criteria met
2. Document completion evidence
3. Get approval from [gate keeper role]
4. Update project status
5. Begin Phase X+1

### If Phase X Gate Fails

1. Identify which criteria are unmet
2. Root cause analysis (why did we miss it?)
3. Create action items to address gaps
4. Re-estimate time to meet criteria
5. Retry gate after addressing failures
```

---

## Progression Model

### Linear Progression (Recommended)

```
Phase 1
   ↓ (gate assessment)
Phase 2
   ↓ (gate assessment)
Phase 3
   ↓ (gate assessment)
Phase N
```

**Rules**:
- Cannot skip phases
- Cannot regress to previous phase
- Current phase is always public and tracked
- Historical phases archived for reference

### Phase Structure Recommendations

**Typical project lifecycle** (foundation → maturity → optimization):
```
Phase 1: Foundation (core architecture)
   ↓
Phase 2: Integration (components working together)
   ↓
Phase 3: Quality (testing, security, docs)
   ↓
Phase 4: Operations (deployment, monitoring)
   ↓
Phase 5: Optimization (performance, cost, scaling)
```

**Feature delivery** (planning → shipping):
```
Phase 1: Design (spec, architecture, planning)
   ↓
Phase 2: Implementation (coding)
   ↓
Phase 3: Testing (QA, edge cases, performance)
   ↓
Phase 4: Review (code review, design approval)
   ↓
Phase 5: Deployment (shipping to users)
```

---

## Acceptance Testing Strategy

### Automated Tests (Highest Confidence)

Command-based, reproducible, no manual interpretation:

```bash
# Example: Test coverage gate
pytest tests/ --cov=app --cov-report=term-missing
# Verification: Total coverage >= 85%

# Example: Linting gate
ruff check app/ tests/
# Verification: No issues found (exit code 0)

# Example: Performance gate
python benchmark.py
# Verification: p95 latency < 500ms
```

**Pros**: Objective, reproducible, can be automated in CI/CD  
**Cons**: Must be set up in advance

### Checklist-Based Tests (Manual Verification)

Human verification items, reviewable but subjective:

```
## Code Review Complete

Verification Checklist:
- [ ] All code reviewed (peer + security)
- [ ] No hardcoded secrets
- [ ] No OWASP Top 10 violations
- [ ] Error messages generic (no leakage)
- [ ] Tests added for new code
```

**Pros**: Flexible, catches nuance that automation misses  
**Cons**: Subjective, not reproducible, requires expert judgment

### Metric-Based Tests (Quantitative)

Measurable outcomes with thresholds:

```
## Performance Baseline Established

- API endpoint latency: baseline established ✓
- Memory usage: baseline established ✓
- Throughput: baseline established ✓
- Error rates: < 0.1% ✓
```

**Pros**: Objective, trackable over time  
**Cons**: Requires instrumentation

### Gate Keeper Approval (Organizational)

Final sign-off by decision maker:

```
APPROVED: [Name], [Date]
Authority: [Role/Responsibility]
Conditions: [Any specific constraints or follow-ups]
```

**Pros**: Ensures accountability, catches edge cases  
**Cons**: Requires informed reviewers, can be bottleneck

---

## Risk Management

### Risk Assessment in Gates

For each criterion, identify risks that could prevent completion:

```
**Risks**:
- Risk A: [Specific thing that could prevent completion]
- Risk B: [Another failure mode]
- Risk C: [Less likely but critical failure]

**Mitigation**:
- For Risk A: [Proactive step to reduce likelihood]
- For Risk B: [How to detect early and recover]
- For Risk C: [Contingency plan if it occurs]
```

### Common Phase Gate Risks

| Risk | Mitigation |
|------|-----------|
| Criteria ambiguous or subjective | Write acceptance tests before phase starts |
| Hidden dependencies between criteria | Map criterion dependencies upfront |
| Criteria too strict (impossible to meet) | Test acceptance criteria with team first |
| Criteria too loose (rubber stamp) | Include specific metrics, not vague goals |
| Gate keeper unavailable | Define backup approvers |
| Scope creep during phase | Lock scope at phase start |

---

## Implementation Guide

### Step 1: Define Your Phases

Answer these questions:
1. What major cycles does your project have?
2. When do you naturally pause to assess progress?
3. What are the major milestones?

**Example mapping**:
- Software project: Foundation → Integration → Security → Performance → Deployment
- Feature: Design → Code → Test → Review → Ship
- Quarterly cycle: Planning → Execution → Review → Retrospective

### Step 2: Define Completion Criteria

For each phase, identify 3-5 criteria that mean "done":

```
Phase 1 Criteria:
1. Core APIs implemented (no mocking)
2. Unit tests ≥80% coverage
3. Security review passed
4. Documentation complete
5. Team sign-off on design
```

### Step 3: Write Acceptance Tests

For each criterion, define how to verify it:

```
Criterion: Core APIs implemented

Acceptance Test:
- Run integration tests: `pytest tests/integration/ -v`
- All tests pass (0 failures)
- Mocking disabled in code: `grep -r "mock" app/ | grep -v "test_"` returns empty
```

### Step 4: Identify Risks & Mitigations

```
Criterion: Core APIs implemented

Risks:
- API spec may change mid-phase
- Dependencies may not integrate as expected
- Performance may be unacceptable

Mitigations:
- Lock API spec at phase start (design review)
- Run integration tests weekly (early detection)
- Run performance baseline test before phase end
```

### Step 5: Execute & Track

```
Phase Status Tracking:
- Phase 1: In Progress (Criterion 1 ✓, Criterion 2 ✓, Criterion 3 ⏳, Criterion 4 ⏳, Criterion 5 ✓)
- Phase 2: Not Started
- Phase 3: Not Started
```

### Step 6: Gate Assessment

When phase approaches completion:
1. Run all acceptance tests
2. Verify all criteria met
3. Get gate keeper approval
4. Document completion date
5. Advance to next phase

---

## Examples

### Example 1: Software Foundation Phase

```markdown
## Phase 1: Foundation (Core APIs)

### Purpose
Establish core API architecture and basic orchestration.

### Completion Criteria

#### 1. Core API Endpoints Implemented

**Criterion**: All required REST endpoints functional (no mocking)

**Acceptance Test**:
```bash
pytest tests/integration/test_endpoints.py -v
# Result: All tests pass, 0 failures
```

**Verification Checklist**:
- [ ] POST /agents implemented
- [ ] POST /tasks implemented
- [ ] GET /status implemented
- [ ] DELETE /agents implemented
- [ ] Error responses tested

**Risks**:
- Endpoint specs may be incomplete
- Dependencies may not integrate smoothly

**Mitigation**:
- Lock spec at phase start
- Run weekly integration tests

---

#### 2. Test Coverage ≥80%

**Criterion**: All core modules have unit test coverage ≥80%

**Acceptance Test**:
```bash
pytest tests/unit/ --cov=app --cov-report=term-missing
# Result: Total coverage >= 80%
```

**Verification Checklist**:
- [ ] API routes covered
- [ ] Service layer covered
- [ ] Database layer covered
- [ ] Utility functions covered
- [ ] Error paths tested

**Risks**:
- Tests may be superficial (high coverage, low quality)
- Some code hard to test

**Mitigation**:
- Code review tests, not just coverage metrics
- Refactor code to be testable if needed
```

### Example 2: Feature Development Phase

```markdown
## Phase 2: Feature Implementation

### Purpose
Build the requested feature end-to-end.

### Completion Criteria

#### 1. Feature Code Complete

**Criterion**: All feature requirements implemented and tested

**Acceptance Test**:
```bash
# Acceptance test: Feature works as specified
pytest tests/test_feature.py -v
# Result: All tests pass
```

**Verification Checklist**:
- [ ] User story requirements met
- [ ] Edge cases handled
- [ ] Error messages clear
- [ ] Performance acceptable (< 500ms p95)
- [ ] No regressions in other features

**Risks**:
- Requirements ambiguous or incomplete
- Discovery of missing dependencies
- Performance issues during implementation

**Mitigation**:
- Requirement review before starting
- Proof-of-concept for critical dependencies
- Performance testing mid-phase

---

#### 2. Code Review Approved

**Criterion**: Code reviewed and approved by 2+ reviewers

**Acceptance Test**:
```bash
# Check PR status
gh pr view --json reviews,commits
# Verification: 2+ approved reviews, 0 requested changes
```

**Verification Checklist**:
- [ ] Code reviewer 1 approved
- [ ] Code reviewer 2 approved
- [ ] No "request changes" outstanding
- [ ] Security reviewed
- [ ] No hardcoded secrets
- [ ] Comments addressed

**Risks**:
- Reviewers slow to respond
- Review feedback conflicts

**Mitigation**:
- Assign reviewers early
- Keep PRs small (< 300 lines)
- Discussion thread for conflicts
```

---

## Recursive Application

Phase gates work at multiple scales:

### Organizational Level
- Q1, Q2, Q3, Q4 cycles (quarterly gates)
- Product roadmap milestones
- Release versions (v1.0, v2.0)

### Project Level
- Phase 1 Foundation, Phase 2 Integration, etc.
- Multi-month cycles with 4-6 phases

### Sprint Level
- Sprint planning, execution, review
- Weekly or bi-weekly cycles
- 3-5 user stories per sprint

### Day Level
- Daily standup (progress gate)
- Code review gate (before merge)
- Deployment gate (before production)

### Applying at Different Levels

```
Quarterly Gate (Org Level)
├─ Phase 1 Gate (Project Level, ~2-3 weeks)
│  ├─ Sprint 1 Gate (1 week)
│  ├─ Sprint 2 Gate (1 week)
│  └─ Sprint 3 Gate (1 week)
├─ Phase 2 Gate (Project Level, ~2-3 weeks)
│  ├─ Sprint 4 Gate (1 week)
│  ├─ Sprint 5 Gate (1 week)
│  └─ Sprint 6 Gate (1 week)
└─ Phase 3 Gate (Project Level, ~2-3 weeks)
   └─ ...

Daily Gate (Code Level)
├─ Feature branch ready (code complete)
├─ Tests passing (all tests green)
├─ Code review approved (2 reviewers)
└─ CI/CD passed (merge to main)
```

### Consistency Across Scales

Use the same gate template at all levels:
1. **Criterion name**: What must be done?
2. **Acceptance test**: How to verify?
3. **Risks**: What could go wrong?
4. **Mitigation**: How to prevent/recover?

This consistency makes gates predictable and scalable.

---

## Best Practices

### 1. Write Criteria Before Phase Starts
- Avoid mid-phase scope changes
- Acceptance tests give team clarity
- Risk assessment prepares mitigation

### 2. Make Tests Specific & Objective
- ✅ "Test coverage ≥85%" (measurable)
- ❌ "Good test coverage" (subjective)
- ✅ "API latency p95 < 500ms" (measurable)
- ❌ "API performant enough" (subjective)

### 3. Track Gate Status Publicly
- Phase status visible to all stakeholders
- Early warning if phase at risk
- Historical record of what was delivered

### 4. Keep Phases Time-Bound
- Phases should be 1-4 weeks (software projects)
- Longer phases = harder to assess progress
- If phase > 8 weeks, split into sub-phases

### 5. Learn from Failed Gates
- Don't lower criteria to pass (defeats the purpose)
- Analyze why criterion was unmet
- Adjust process to prevent next time
- Document learnings in retrospective

### 6. Gate Keeper Accountability
- Gate keeper approves or blocks phase advancement
- Gate keeper must review acceptance test evidence
- Multiple gate keepers for important phases
- Gate keeper cannot be pressured to approve incomplete work

---

## FAQ

**Q: What if a criterion is impossible to meet?**  
A: It should have been caught in planning. If discovered during phase, escalate to gate keeper for scope decision (modify criterion or extend phase).

**Q: Can phases overlap?**  
A: Not recommended. Overlapping phases hide dependencies and make progress tracking ambiguous. Sequential phases are clearer.

**Q: What if gate keeper is unavailable?**  
A: Define backup gate keepers in advance. Gate progression must never be delayed by single person.

**Q: How long should a phase take?**  
A: 1-4 weeks is typical. Shorter = faster feedback. Longer = harder to track. If > 8 weeks, split into sub-phases with intermediate gates.

**Q: Can we change criteria mid-phase?**  
A: No. Changing criteria mid-phase defeats the purpose. If discovery reveals issue, escalate to leadership for decision (extend phase, modify scope, etc.).

**Q: What if a criterion is subjective?**  
A: Make it more objective. Instead of "code quality good", use "tests ≥85%, linting passes, type checking passes".

---

## See Also

- **Gate Progression Example**: [phase-history.md](../archived-phases/phase-history-example.md) (external link, customize for your project)
- **Risk Management**: Standard risk management practices apply
- **Metrics & Tracking**: Use your project management tool (Jira, GitHub Projects, etc.)

---

**This framework is project-agnostic and can be adapted for any team, project, or workflow.**

Last updated: 2026-08-25
