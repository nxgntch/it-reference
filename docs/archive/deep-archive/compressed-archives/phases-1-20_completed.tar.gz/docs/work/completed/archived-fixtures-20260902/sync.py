"""Sync pipeline configuration fixtures."""

import pytest
import yaml


@pytest.fixture
def mockSyncConfig():
    """Standard mock configuration for sync tests."""
    return {
        "source": "/home/user/it",
        "destination": "/home/user/NXGNTCH",
        "syncRules": [{"source": ".claude/rules", "destination": ".claude/rules"}],
        "documentationUpdates": [
            {"file": "CLAUDE.md", "preserveSections": ["Quick Links"]},
            {"file": ".claude/rules/models.md", "preserveSections": ["Anthropic Models"]},
        ],
    }


@pytest.fixture
def syncConfig(tmp_path):
    """Realistic sync configuration for integration tests."""
    sourceRepo = tmp_path / "source"
    targetRepo = tmp_path / "target"
    sourceRepo.mkdir()
    targetRepo.mkdir()
    return {
        "sync": {
            "source_repo": str(sourceRepo),
            "target_repo": str(targetRepo),
            "current_phase": "Phase 3.1",
            "last_update": "2026-08-17",
            "rules_to_sync": [
                {
                    "source": ".claude/rules/coding-style.md",
                    "target": ".claude/rules/coding-style.md",
                    "description": "Coding style and naming conventions",
                },
                {
                    "source": ".claude/rules/testing.md",
                    "target": ".claude/rules/testing.md",
                    "description": "Testing standards and TDD guidelines",
                },
            ],
            "docs_to_update": [
                {"source": "CLAUDE.md", "target": "CLAUDE.md", "preserve_sections": ["Quick Links"]}
            ],
            "model_assignments": {"architect": "claude-opus-5", "planner": "claude-sonnet-5"},
            "exclude_patterns": ["*.pyc", "__pycache__", ".git"],
            "validation": [],
        },
        "logging": {"level": "INFO"},
        "reporting": {"generate_report": True, "report_file": "SYNC_REPORT.md"},
    }


@pytest.fixture
def syncConfigFile(syncConfig, tmp_path):
    """Write sync config to YAML file for testing."""
    configFile = tmp_path / "config.yaml"
    with open(configFile, "w") as f:
        yaml.dump(syncConfig, f)
    return str(configFile)


@pytest.fixture
def validConfigFile(mockSyncConfig, tmp_path):
    """Valid YAML config file for sync testing."""
    configFile = tmp_path / "sync_config.yaml"
    with open(configFile, "w") as f:
        yaml.dump(mockSyncConfig, f)
    return str(configFile)
