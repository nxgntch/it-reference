"""Tests for ActiveTasksGenerator (Phase 5.2)."""

from pathlib import Path
from tempfile import TemporaryDirectory

import pytest

from tests.utilities.assertionHelpers import (
    assertConditionMet,
    assertListLength,
    assertMetricValue,
)
from scripts.docs.active_tasks_generator import ActiveTasksGenerator

pytestmark = pytest.mark.docs

pytestmark = [pytest.mark.unit, pytest.mark.docs]

class TestActiveTasksGeneratorInitialization:
    """Test ActiveTasksGenerator initialization."""

    def testInitializesWithDefaults(self):
        """Test initialization with default parameters."""
        gen = ActiveTasksGenerator()
        assert gen.name == "active-tasks"

    def testInitializesWithCustomSource(self):
        """Test initialization with custom task source."""
        source = Path("custom/tasks/")
        gen = ActiveTasksGenerator(task_source=source)
        assert gen.taskSource == source

class TestGetTasks:
    """Test task retrieval."""

    def testGetsTasks(self):
        """Test retrieving tasks."""
        gen = ActiveTasksGenerator()
        tasks = gen.getTasks()
        assert isinstance(tasks, list)
        assert len(tasks) > 0
        assert all("id" in t and "title" in t for t in tasks)

    def testTasksHaveRequiredFields(self):
        """Test that tasks have all required fields."""
        gen = ActiveTasksGenerator()
        tasks = gen.getTasks()
        required_fields = ["id", "title", "status", "priority", "description"]
        for task in tasks:
            for field in required_fields:
                assert field in task

class TestGenerateMarkdown:
    """Test Markdown generation."""

    def testGeneratesMarkdown(self):
        """Test generating Markdown content."""
        gen = ActiveTasksGenerator()
        tasks = gen.getTasks()
        markdown = gen.generateMarkdown(tasks)
        assert "# Active Tasks" in markdown
        assert "## Summary" in markdown
        assert "## Tasks by Status" in markdown

    def testGroupsTasksByStatus(self):
        """Test that tasks are grouped by status."""
        gen = ActiveTasksGenerator()
        tasks = [
            {
                "id": "1",
                "title": "Task 1",
                "status": "✅ Complete",
                "priority": "High",
                "description": "Desc 1",
            },
            {
                "id": "2",
                "title": "Task 2",
                "status": "⏳ In Progress",
                "priority": "High",
                "description": "Desc 2",
            },
        ]
        markdown = gen.generateMarkdown(tasks)
        assert "✅ Complete" in markdown
        assert "⏳ In Progress" in markdown

    def testHandlesEmptyTasks(self):
        """Test handling empty task list."""
        gen = ActiveTasksGenerator()
        markdown = gen.generateMarkdown([])
        assert markdown == ""

class TestGenerate:
    """Test full generation workflow."""

    def testGeneratesFile(self):
        """Test generating active-tasks.md file."""
        with TemporaryDirectory() as tmpDir:
            outputFile = Path(tmpDir) / "active-tasks.md"
            gen = ActiveTasksGenerator()
            success = gen.generate(output_path=outputFile)
            assert success is True
            assert outputFile.exists()
            content = outputFile.read_text(encoding="utf-8")
            assert "# Active Tasks" in content

    def testStatisticsTracking(self):
        """Test that statistics are tracked."""
        with TemporaryDirectory() as tmpDir:
            outputFile = Path(tmpDir) / "active-tasks.md"
            gen = ActiveTasksGenerator()
            gen.generate(output_path=outputFile)
            summary = gen.getSummary()
            assert "filesGenerated" in summary
            assert "durationSeconds" in summary
