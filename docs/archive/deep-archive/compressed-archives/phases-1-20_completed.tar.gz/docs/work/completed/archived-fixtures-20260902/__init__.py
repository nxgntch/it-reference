"""Shared pytest fixture implementations (loaded via conftest.py pytest_plugins)."""
