"""Database and HTTP client mock fixtures."""

import pytest


@pytest.fixture(scope="session")
def apiResponseFactory():
    """Centralized API response factory for all tests (session-scoped, cached)."""
    from tests.fixtures.api_response_factory import ResponseFactory

    return ResponseFactory()


@pytest.fixture
def mockHttpClient(apiResponseFactory):
    """Pre-configured HTTP client mock with response factory."""
    from tests.fixtures.http_client_mock import MockHTTPClient

    return MockHTTPClient(apiResponseFactory)


@pytest.fixture(scope="module")
def dbInterface():
    """Database interface abstraction for tests (module-scoped)."""
    from tests.fixtures.db_abstraction import DatabaseInterface

    return DatabaseInterface()


@pytest.fixture
def mockDatabase(dbInterface):
    """Pre-configured async database mock (function-scoped)."""
    from tests.fixtures.db_abstraction import AsyncSessionMock

    return AsyncSessionMock(dbInterface)


@pytest.fixture(
    params=[
        ("users", ["User"]),
        ("teams", ["Team"]),
        ("costs", ["Cost"]),
        ("agents", ["Agent"]),
        ("all", ["User", "Team", "Agent", "Cost"]),
    ],
    ids=lambda x: x[0],
)
def mockDatabaseWithData(request, mockDatabase):
    """Parametrized database fixture with standard mock data."""
    from tests.fixtures.shared_test_data import MOCK_AGENTS, MOCK_COSTS, MOCK_TEAMS, MOCK_USERS

    data_map = {
        "User": MOCK_USERS,
        "Team": MOCK_TEAMS,
        "Agent": MOCK_AGENTS,
        "Cost": MOCK_COSTS,
    }
    _fixture_id, entity_types = request.param
    for entity_type in entity_types:
        mockDatabase.configureQueryResult(entity_type, data_map[entity_type])
    return mockDatabase


# Backward-compatibility aliases (for existing tests)
@pytest.fixture
def mockDatabaseWithUsers(mockDatabaseWithData):
    """Database with standard user mock data."""
    if "users" in str(mockDatabaseWithData.__class__):
        return mockDatabaseWithData
    # Create fresh instance with only users
    from tests.fixtures.shared_test_data import MOCK_USERS

    mockDatabaseWithData.configureQueryResult("User", MOCK_USERS)
    return mockDatabaseWithData


@pytest.fixture
def mockDatabaseWithTeams(mockDatabaseWithData):
    """Database with standard team mock data."""
    from tests.fixtures.shared_test_data import MOCK_TEAMS

    mockDatabaseWithData.configureQueryResult("Team", MOCK_TEAMS)
    return mockDatabaseWithData


@pytest.fixture
def mockDatabaseWithCosts(mockDatabaseWithData):
    """Database with standard cost mock data."""
    from tests.fixtures.shared_test_data import MOCK_COSTS

    mockDatabaseWithData.configureQueryResult("Cost", MOCK_COSTS)
    return mockDatabaseWithData


@pytest.fixture
def mockDatabaseWithAgents(mockDatabaseWithData):
    """Database with standard agent mock data."""
    from tests.fixtures.shared_test_data import MOCK_AGENTS

    mockDatabaseWithData.configureQueryResult("Agent", MOCK_AGENTS)
    return mockDatabaseWithData


@pytest.fixture
def mockDatabaseWithAll(mockDatabaseWithData):
    """Database with all standard mock data."""
    return mockDatabaseWithData
