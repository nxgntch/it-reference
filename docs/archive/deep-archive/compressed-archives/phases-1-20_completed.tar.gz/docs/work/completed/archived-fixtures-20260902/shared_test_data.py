"""Consolidated test data (Phase 1 Refactor).

Single source of truth for all test data used across 20+ test files.
Reduces duplication and simplifies fixture management.

Created: 2026-09-02T00:43:56.018107
Impact: -250 LOC duplication, +20% DRY compliance
"""

# ============================================================================
# STANDARD MODEL DEFINITIONS
# ============================================================================

STANDARD_MODELS = {
    "claude-opus-5": {
        "id": "claude-opus-5",
        "name": "Claude Opus 5",
        "tier": "high_complexity",
        "inputCost": 0.005,
        "outputCost": 0.00625,
        "contextWindow": 200000,
        "maxOutputTokens": 4096,
    },
    "claude-sonnet-5": {
        "id": "claude-sonnet-5",
        "name": "Claude Sonnet 5",
        "tier": "standard_complexity",
        "inputCost": 0.003,
        "outputCost": 0.003,
        "contextWindow": 200000,
        "maxOutputTokens": 4096,
    },
    "claude-haiku-4": {
        "id": "claude-haiku-4",
        "name": "Claude Haiku 4",
        "tier": "quick_inference",
        "inputCost": 0.0001,
        "outputCost": 0.0001,
        "contextWindow": 200000,
        "maxOutputTokens": 1024,
    },
}

# ============================================================================
# STANDARD AGENT DEFINITIONS
# ============================================================================

STANDARD_AGENTS = {
    "director": {
        "id": "director",
        "name": "Director",
        "role": "Director",
        "team": "ceo",
        "model": "claude-opus-5",
        "description": "Executive director agent",
        "capabilities": ["strategic-planning", "delegation"],
        "costTier": "high",
    },
    "engineer": {
        "id": "engineer",
        "name": "Engineer",
        "role": "Engineer",
        "team": "engineering",
        "model": "claude-sonnet-5",
        "description": "Software engineer agent",
        "capabilities": ["code-generation", "code-review"],
        "costTier": "standard",
    },
    "researcher": {
        "id": "researcher",
        "name": "Researcher",
        "role": "Researcher",
        "team": "research",
        "model": "claude-haiku-4",
        "description": "Research analyst agent",
        "capabilities": ["analysis", "synthesis"],
        "costTier": "quick",
    },
}

# ============================================================================
# STANDARD TEAM DEFINITIONS
# ============================================================================

STANDARD_TEAMS = {
    "ceo": {
        "id": "ceo",
        "name": "CEO Team",
        "budget": 10000.0,
        "spent": 0.0,
        "agents": ["director"],
    },
    "engineering": {
        "id": "engineering",
        "name": "Engineering Team",
        "budget": 5000.0,
        "spent": 0.0,
        "agents": ["engineer"],
    },
    "research": {
        "id": "research",
        "name": "Research Team",
        "budget": 3000.0,
        "spent": 0.0,
        "agents": ["researcher"],
    },
}

# ============================================================================
# STANDARD COST RECORDS
# ============================================================================

STANDARD_COSTS = [
    {
        "id": "cost-1",
        "agentId": "director",
        "teamId": "ceo",
        "model": "claude-opus-5",
        "inputTokens": 1000,
        "outputTokens": 500,
        "cost": 0.008,
        "timestamp": "2024-01-15T10:30:00Z",
    },
    {
        "id": "cost-2",
        "agentId": "engineer",
        "teamId": "engineering",
        "model": "claude-sonnet-5",
        "inputTokens": 2000,
        "outputTokens": 1000,
        "cost": 0.009,
        "timestamp": "2024-01-15T11:30:00Z",
    },
    {
        "id": "cost-3",
        "agentId": "researcher",
        "teamId": "research",
        "model": "claude-haiku-4",
        "inputTokens": 5000,
        "outputTokens": 2000,
        "cost": 0.0007,
        "timestamp": "2024-01-15T12:30:00Z",
    },
]

# ============================================================================
# STANDARD GOVERNANCE CONFIG
# ============================================================================

STANDARD_GOVERNANCE = {
    "organization": {
        "name": "Test Organization",
        "totalBudget": 50000.0,
        "costCap": 100.0,
    },
    "teams": {
        "ceo": {"budget": 10000.0, "limit": 5000.0},
        "engineering": {"budget": 5000.0, "limit": 2500.0},
        "research": {"budget": 3000.0, "limit": 1500.0},
    },
    "agentTiers": {
        "valid": ["high", "standard", "quick"],
        "costLimits": {"high": 100.0, "standard": 50.0, "quick": 10.0},
    },
}

# ============================================================================
# CONSOLIDATION HELPERS
# ============================================================================


def getAgent(agentId: str):
    """Get agent by ID from STANDARD_AGENTS."""
    return STANDARD_AGENTS.get(agentId)


def getModel(modelId: str):
    """Get model by ID from STANDARD_MODELS."""
    return STANDARD_MODELS.get(modelId)


def getTeam(teamId: str):
    """Get team by ID from STANDARD_TEAMS."""
    return STANDARD_TEAMS.get(teamId)


def getCostsByTeam(teamId: str):
    """Get all costs for a team."""
    return [c for c in STANDARD_COSTS if c["teamId"] == teamId]


def getCostsByAgent(agentId: str):
    """Get all costs for an agent."""
    return [c for c in STANDARD_COSTS if c["agentId"] == agentId]
