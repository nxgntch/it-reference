"""Config file builders for test fixtures (centralized YAML setup)."""

import json
import tempfile
from pathlib import Path
from typing import Optional


class ConfigFileBuilder:
    """Factory for creating config YAML files in test directories."""

    @staticmethod
    def createModelsYaml(configDir: Path) -> Path:
        """Create models.yaml with standard model definitions.

        Args:
            configDir: Directory to create models.yaml in

        Returns:
            Path to created models.yaml
        """
        modelsYaml = configDir / "models.yaml"
        modelsYaml.write_text(
            """models:
  - id: claude-opus-5
    tier: high_complexity
    inputCost: 0.005
    outputCost: 0.00625
    maxTokens: 4096
    contextWindow: 200000
  - id: claude-sonnet-5
    tier: medium_complexity
    inputCost: 0.001
    outputCost: 0.002
    maxTokens: 3000
    contextWindow: 150000
  - id: claude-haiku-4
    tier: low_complexity
    inputCost: 0.0001
    outputCost: 0.0002
    maxTokens: 2048
    contextWindow: 100000
"""
        )
        return modelsYaml

    @staticmethod
    def createAgentsYaml(configDir: Path) -> Path:
        """Create agents.yaml with standard agent definitions.

        Args:
            configDir: Directory to create agents.yaml in

        Returns:
            Path to created agents.yaml
        """
        agentsYaml = configDir / "agents.yaml"
        agentsYaml.write_text(
            """agents:
  - id: director
    name: Director
    role: Director
    team: leadership
    model: claude-opus-5
  - id: architect
    name: Architect
    role: Architect
    team: engineering
    model: claude-sonnet-5
  - id: researcher
    name: Researcher
    role: Researcher
    team: research
    model: claude-haiku-4.5
  - id: engineer
    name: Engineer
    role: Engineer
    team: engineering
    model: claude-sonnet-5
  - id: coordinator
    name: Coordinator
    role: Coordinator
    team: operations
    model: claude-haiku-4.5
"""
        )
        return agentsYaml

    @staticmethod
    def createSkillsYaml(configDir: Path) -> Path:
        """Create skills.yaml with standard skill definitions.

        Args:
            configDir: Directory to create skills.yaml in

        Returns:
            Path to created skills.yaml
        """
        skillsYaml = configDir / "skills.yaml"
        skillsYaml.write_text(
            """skills:
  - name: code-review
    path: skills/codeReview
    agent: architect
    team: engineering
  - name: code-generation
    path: skills/codeGeneration
    agent: architect
    team: engineering
  - name: analysis
    path: skills/analysis
    agent: researcher
    team: research
  - name: cost-forecasting
    path: skills/costForecasting
    agent: director
    team: leadership
  - name: performance-optimization
    path: skills/performanceOptimization
    agent: architect
    team: engineering
"""
        )
        return skillsYaml

    @staticmethod
    def createGovernanceYaml(configDir: Path) -> Path:
        """Create governance.yaml with budget and cost limits.

        Args:
            configDir: Directory to create governance.yaml in

        Returns:
            Path to created governance.yaml
        """
        governanceYaml = configDir / "governance.yaml"
        governanceYaml.write_text(
            """governance:
  organization:
    monthlyBudget: 10000.0
    quarterlyBudget: 30000.0
  teams:
    engineering:
      monthlyBudget: 5000.0
      quarterlyBudget: 15000.0
    research:
      monthlyBudget: 2000.0
      quarterlyBudget: 6000.0
    leadership:
      monthlyBudget: 2000.0
      quarterlyBudget: 6000.0
    operations:
      monthlyBudget: 1000.0
      quarterlyBudget: 3000.0
"""
        )
        return governanceYaml

    @staticmethod
    def createOrchestrationYaml(configDir: Path) -> Path:
        """Create orchestration.yaml with timeouts and circuit breaker settings.

        Args:
            configDir: Directory to create orchestration.yaml in

        Returns:
            Path to created orchestration.yaml
        """
        orchestrationYaml = configDir / "orchestration.yaml"
        orchestrationYaml.write_text(
            """timeouts:
  agentInvocation: 600
  batchProcessing: 1800
  skillExecution: 300
circuitBreaker:
  failureThreshold: 5
  cooldownSeconds: 60
  timeoutSeconds: 30
retryPolicy:
  maxRetries: 3
  backoffMultiplier: 2
  initialDelaySec: 1
"""
        )
        return orchestrationYaml

    @staticmethod
    def createEnvSchema(configDir: Path) -> Path:
        """Create .env.schema.json with environment variable definitions.

        Args:
            configDir: Directory to create .env.schema.json in

        Returns:
            Path to created .env.schema.json
        """
        schemaFile = configDir / ".env.schema.json"
        schemaFile.write_text(
            json.dumps(
                {
                    "properties": {
                        "DATABASE_URL": {"default": "postgres://localhost"},
                        "API_KEY": {"description": "API key for external services"},
                        "LOG_LEVEL": {"default": "INFO"},
                        "DEBUG": {"default": "false"},
                    },
                    "required": ["API_KEY"],
                }
            )
        )
        return schemaFile

    @staticmethod
    def createTempConfigDir(
        withModels: bool = True,
        withAgents: bool = True,
        withSkills: bool = True,
        withGovernance: bool = True,
        withOrchestration: bool = True,
        withEnvSchema: bool = True,
    ) -> Path:
        """Create temporary config directory with all standard YAML files.

        Args:
            withModels: Include models.yaml
            withAgents: Include agents.yaml
            withSkills: Include skills.yaml
            withGovernance: Include governance.yaml
            withOrchestration: Include orchestration.yaml
            withEnvSchema: Include .env.schema.json

        Returns:
            Path to temporary config directory
        """
        tmpdir = tempfile.TemporaryDirectory()
        configDir = Path(tmpdir.name)

        if withModels:
            ConfigFileBuilder.createModelsYaml(configDir)
        if withAgents:
            ConfigFileBuilder.createAgentsYaml(configDir)
        if withSkills:
            ConfigFileBuilder.createSkillsYaml(configDir)
        if withGovernance:
            ConfigFileBuilder.createGovernanceYaml(configDir)
        if withOrchestration:
            ConfigFileBuilder.createOrchestrationYaml(configDir)
        if withEnvSchema:
            ConfigFileBuilder.createEnvSchema(configDir)

        return configDir


class TempConfigDirContext:
    """Context manager for temporary config directory."""

    def __init__(
        self,
        withModels: bool = True,
        withAgents: bool = True,
        withSkills: bool = True,
        withGovernance: bool = True,
        withOrchestration: bool = True,
        withEnvSchema: bool = True,
    ):
        """Initialize context manager."""
        self.withModels = withModels
        self.withAgents = withAgents
        self.withSkills = withSkills
        self.withGovernance = withGovernance
        self.withOrchestration = withOrchestration
        self.withEnvSchema = withEnvSchema
        self.tmpdir = None
        self.configDir = None

    def __enter__(self) -> Path:
        """Enter context and create temp directory."""
        self.tmpdir = tempfile.TemporaryDirectory()
        self.configDir = Path(self.tmpdir.name)

        if self.withModels:
            ConfigFileBuilder.createModelsYaml(self.configDir)
        if self.withAgents:
            ConfigFileBuilder.createAgentsYaml(self.configDir)
        if self.withSkills:
            ConfigFileBuilder.createSkillsYaml(self.configDir)
        if self.withGovernance:
            ConfigFileBuilder.createGovernanceYaml(self.configDir)
        if self.withOrchestration:
            ConfigFileBuilder.createOrchestrationYaml(self.configDir)
        if self.withEnvSchema:
            ConfigFileBuilder.createEnvSchema(self.configDir)

        return self.configDir

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Exit context and cleanup."""
        if self.tmpdir:
            self.tmpdir.cleanup()
