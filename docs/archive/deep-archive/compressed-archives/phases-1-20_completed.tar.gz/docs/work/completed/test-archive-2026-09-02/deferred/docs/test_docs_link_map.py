"""Tests for LinkMapGenerator (Phase 5.2)."""

from pathlib import Path
from tempfile import TemporaryDirectory

import pytest

from tests.utilities.assertionHelpers import (
    assertConditionMet,
    assertListLength,
    assertMetricValue,
)
from scripts.docs.link_map_generator import LinkMapGenerator

pytestmark = pytest.mark.docs

pytestmark = [pytest.mark.unit, pytest.mark.docs]

class TestLinkMapGeneratorInitialization:
    """Test LinkMapGenerator initialization."""

    def testInitializesWithDefaults(self):
        """Test initialization with default parameters."""
        gen = LinkMapGenerator()
        assert gen.name == "link-map"
        assert gen.docsRoot == Path("docs")

class TestScanDocumentation:
    """Test documentation scanning."""

    def testScansFindsMdFiles(self):
        """Test scanning finds markdown files."""
        with TemporaryDirectory() as tmpDir:
            tmpPath = Path(tmpDir)
            # Create mock docs structure
            guidesDir = tmpPath / "guides"
            guidesDir.mkdir()
            (guidesDir / "guide1.md").touch()
            (guidesDir / "guide2.md").touch()
            specDir = tmpPath / "specifications"
            specDir.mkdir()
            (specDir / "api.md").touch()
            gen = LinkMapGenerator(docs_root=tmpPath)
            files = gen.scanDocumentation()
            assert "guides" in files or "specifications" in files
            assert sum(len(v) for v in files.values()) >= 3

    def testHandlesMissingDocsDir(self):
        """Test handling missing docs directory."""
        gen = LinkMapGenerator(docs_root=Path("nonexistent"))
        files = gen.scanDocumentation()
        assert files == {}

class TestGenerateMarkdown:
    """Test Markdown generation."""

    def testGeneratesTableOfContents(self):
        """Test generating table of contents."""
        gen = LinkMapGenerator()
        files = {
            "guides": [Path("docs/guides/guide1.md"), Path("docs/guides/guide2.md")],
            "specs": [Path("docs/specs/api.md")],
        }
        markdown = gen.generateMarkdown(files)
        assert "# Documentation Link Map" in markdown
        assert "## By Category" in markdown

    def testHandlesEmptyFiles(self):
        """Test handling empty file dict."""
        gen = LinkMapGenerator()
        markdown = gen.generateMarkdown({})
        assert markdown == ""

class TestGenerate:
    """Test full generation workflow."""

    def testGeneratesFile(self):
        """Test generating LINK_MAP.md file."""
        with TemporaryDirectory() as tmpDir:
            tmpPath = Path(tmpDir)
            # Create mock docs
            docsDir = tmpPath / "docs"
            docsDir.mkdir()
            (docsDir / "guide.md").touch()
            outputFile = tmpPath / "LINK_MAP.md"
            gen = LinkMapGenerator(docs_root=docsDir)
            success = gen.generate(output_path=outputFile)
            # May or may not succeed depending on docs structure
            assert isinstance(success, bool)
