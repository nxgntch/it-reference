# Test Archive

**Location**: `tests/archive/`

Historical and superseded test files organized by phase.

---

## `phase-1-2/` — Foundation Phase Tests (Archived)

Tests from Phases 1-2 that have been superseded by newer Phase 3+ implementations.

### Archived Files

#### `test_api_responses.py`
- **Original Purpose**: API response validation and serialization (foundational)
- **Status**: Superseded by `test_api_response_consistency.py` (Initiative 3.4)
- **Reason**: Initiative 3.4 created ApiResponse module with standardized response envelope factory
- **Archived**: 2026-08-30
- **Notes**: The new `test_api_response_consistency.py` provides better coverage of response consistency and includes ErrorCode enum mapping

#### `test_config_output.py`
- **Original Purpose**: Configuration output testing (Phase 1-2 foundational)
- **Status**: Functionality covered by `test_config_cache.py` (Initiative 3.5)
- **Reason**: Initiative 3.5 created ConfigCache with file modification tracking and lazy loading
- **Archived**: 2026-08-30
- **Notes**: New test provides comprehensive coverage of config caching, validation, and load profiling

---

## Active Test Strategy

**Phase 3+ tests are kept in `tests/` root**:
- ✅ `test_api_response_consistency.py` (Initiative 3.4 - Response envelope factory)
- ✅ `test_config_cache.py` (Initiative 3.5 - Config lazy loading)
- ✅ `test_release_version.py` (Initiative 3.6 - Semantic versioning)
- ✅ `test_request_validator.py` (Initiative 3.4 - Input validation)

All active Phase 3+ tests continue to run in CI/CD and are part of the 1,161+ test suite.

---

## Archival Criteria

Tests are archived if:
- ✅ Functionality superseded by newer Phase 3+ implementation
- ✅ Better-organized replacement tests exist
- ✅ No longer aligns with current code patterns
- ✅ Coverage verified in replacement tests

Tests are kept active if:
- ✅ Part of Phase 3+ active development
- ✅ Unique coverage not in other tests
- ✅ Critical for regression detection

---

## Future Archival Candidates

Under review for potential archiving (Phase 4+ decision):
- `test_agent_and_skills_infrastructure.py` (2,199 LOC - consolidation opportunity)
- `test_cost_comprehensive.py` (may contain outdated patterns)

---

## Running Archived Tests

Archived tests are **not run in CI/CD by default**. To manually run archived tests:

```bash
# Run specific archived test
pytest tests/archive/phase-1-2/test_api_responses.py -v

# Run all archived tests (if debugging)
pytest tests/archive/ -v
```

To restore an archived test to active suite, move it back to `tests/`:

```bash
mv tests/archive/phase-1-2/test_api_responses.py tests/
```

---

**Archive Created**: 2026-08-30  
**Phase**: Consolidation (Phase 1-3 archiving)  
**Status**: Active tests continue at >90% coverage (1,161+)
