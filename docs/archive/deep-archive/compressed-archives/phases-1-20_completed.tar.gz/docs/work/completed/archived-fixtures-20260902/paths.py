"""Directory path and config ID fixtures."""

import json
import sys
from pathlib import Path

import pytest
import yaml

sys.path.insert(0, str(Path(__file__).parent.parent.parent))


@pytest.fixture(scope="module")
def configDir():
    """Path to config directory (immutable, reusable across module tests)."""
    return Path(__file__).parent.parent.parent / "config"


@pytest.fixture(scope="module")
def agentsDir():
    """Path to agents directory (immutable, reusable across module tests)."""
    return Path(__file__).parent.parent.parent / "agents"


@pytest.fixture(scope="module")
def skillsDir():
    """Path to skills directory (immutable, reusable across module tests)."""
    return Path(__file__).parent.parent.parent / "skills"


@pytest.fixture(scope="module")
def agentIds():
    """Get all agent IDs from config (read-only, module-scoped)."""
    agentsPath = Path("config/agents.yaml")
    with open(agentsPath) as f:
        config = yaml.safe_load(f)
    return {agent["id"] for agent in config.get("agents", [])}


@pytest.fixture(scope="module")
def agentFiles():
    """Get all agent markdown files (read-only, module-scoped)."""
    agents_dir = Path("agents")
    return {f.stem for f in agents_dir.glob("*.md") if f.name != "README.md"}


@pytest.fixture(scope="module")
def skillIds():
    """Get all skill IDs from config (read-only, module-scoped)."""
    skillsPath = Path("config/skills.yaml")
    with open(skillsPath) as f:
        config = yaml.safe_load(f)
    return {skill["id"] for skill in config.get("skills", [])}


@pytest.fixture(scope="module")
def skillDirs():
    """Get all skill directories (read-only, module-scoped)."""
    skills_dir = Path("skills")
    return {d.name for d in skills_dir.iterdir() if d.is_dir() and d.name != "agents"}


@pytest.fixture(scope="session")
def manifestData():
    """Load plugin.json for use in tests (session-scoped, immutable)."""
    with open("plugin.json") as f:
        return json.load(f)
