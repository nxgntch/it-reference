"""Comprehensive tests for IdempotencyTracker (app/core/idempotencyTracker.py).

Focus: Cover expired entry cleanup, logging, and status methods.
"""

import time
from unittest.mock import patch

import pytest

from tests.utilities.assertionHelpers import (
    assertConditionMet,
    assertListLength,
    assertMetricValue,
)
from app.core.idempotencyTracker import IdempotencyEntry, IdempotencyTracker

class TestIdempotencyTrackerBasics:
    """Test basic idempotency tracker functionality."""

    def testRecordRequest(self):
        """Test recording a request."""
        tracker = IdempotencyTracker()
        tracker.recordRequest("req-123", {"status": "success"}, agentId="agent-1")
        assert "req-123" in tracker.requests

    def testGetResultReturnsNoneIfNotFound(self):
        """Test getResult returns None for unknown request."""
        tracker = IdempotencyTracker()
        result = tracker.getResult("unknown")
        assert result is None

    def testGetResultReturnsRecordedResult(self):
        """Test getResult returns recorded result."""
        tracker = IdempotencyTracker()
        expected = {"status": "success", "data": [1, 2, 3]}
        tracker.recordRequest("req-456", expected)
        result = tracker.getResult("req-456")
        assert result == expected

    def testHasRequestReturnsTrueForExistingRequest(self):
        """Test hasRequest returns True for recorded request."""
        tracker = IdempotencyTracker()
        tracker.recordRequest("req-789", {"result": "ok"})
        assert tracker.hasRequest("req-789") is True

    def testHasRequestReturnsFalseForUnknownRequest(self):
        """Test hasRequest returns False for unknown request."""
        tracker = IdempotencyTracker()
        assert tracker.hasRequest("unknown") is False

class TestIdempotencyTrackerExpiration:
    """Test expired entry handling."""

    def testGetResultReturnsNoneIfExpired(self):
        """Test getResult returns None for expired entries."""
        tracker = IdempotencyTracker(ttlSeconds=1)
        tracker.recordRequest("req-exp", {"data": "test"})
        # Wait for expiration
        time.sleep(1.1)
        result = tracker.getResult("req-exp")
        assert result is None

    def testCleanupExpiredRemovesExpiredEntries(self):
        """Test cleanupExpired removes expired entries."""
        tracker = IdempotencyTracker(ttlSeconds=1)
        # Record multiple requests
        tracker.recordRequest("req-1", {"data": "test1"})
        tracker.recordRequest("req-2", {"data": "test2"})
        time.sleep(1.1)
        # Add fresh request
        tracker.recordRequest("req-3", {"data": "test3"})
        # Cleanup
        tracker.cleanupExpired()
        # Only fresh request should remain
        assert "req-1" not in tracker.requests
        assert "req-2" not in tracker.requests
        assert "req-3" in tracker.requests

    def testCleanupExpiredLogsWhenRemovingEntries(self):
        """Test cleanupExpired logs when removing entries."""
        tracker = IdempotencyTracker(ttlSeconds=1)
        tracker.recordRequest("req-log", {"data": "test"})
        time.sleep(1.1)
        # Cleanup should trigger logging
        with patch("app.core.idempotencyTracker.logger") as mockLogger:
            tracker.cleanupExpired()
            # Check if logger.info was called about cleanup
            mockLogger.info.assert_called()

    def testCleanupExpiredDoesNotLogIfNothingRemoved(self):
        """Test cleanupExpired doesn't log if nothing expired."""
        tracker = IdempotencyTracker()
        tracker.recordRequest("req-fresh", {"data": "test"})
        # Cleanup fresh entries
        with patch("app.core.idempotencyTracker.logger") as mockLogger:
            tracker.cleanupExpired()
            # Should not call the cleanup log line
            calls = [str(call) for call in mockLogger.info.call_args_list]
            cleanup_logs = [c for c in calls if "Cleaned up" in c]
            assert len(cleanup_logs) == 0

class TestIdempotencyTrackerClear:
    """Test clearing the cache."""

    def testClearRemovesAllEntries(self):
        """Test clear removes all cached requests."""
        tracker = IdempotencyTracker()
        tracker.recordRequest("req-1", {"data": "test1"})
        tracker.recordRequest("req-2", {"data": "test2"})
        tracker.recordRequest("req-3", {"data": "test3"})
        assert len(tracker.requests) == 3
        tracker.clear()
        assert len(tracker.requests) == 0

    def testClearLogsAction(self):
        """Test clear logs the action."""
        tracker = IdempotencyTracker()
        tracker.recordRequest("req-clear", {"data": "test"})
        with patch("app.core.idempotencyTracker.logger") as mockLogger:
            tracker.clear()
            # Check if cleared message was logged
            calls = [str(call) for call in mockLogger.info.call_args_list]
            clear_logs = [c for c in calls if "cleared" in c.lower()]
            assert len(clear_logs) > 0

    def testClearEmptyCacheDoesNotFail(self):
        """Test clear works on empty cache."""
        tracker = IdempotencyTracker()
        tracker.clear()  # Should not raise
        assert len(tracker.requests) == 0

class TestIdempotencyTrackerStatus:
    """Test status retrieval."""

    def testGetStatusReturnsDict(self):
        """Test getStatus returns a dict with expected keys."""
        tracker = IdempotencyTracker()
        tracker.recordRequest("req-status", {"data": "test"})
        status = tracker.getStatus()
        assert isinstance(status, dict)
        assert "cacheSize" in status
        assert "ttlSeconds" in status
        assert "entries" in status

    def testGetStatusIncludesCacheSize(self):
        """Test getStatus reports correct cache size."""
        tracker = IdempotencyTracker()
        tracker.recordRequest("req-1", {"data": "test1"})
        tracker.recordRequest("req-2", {"data": "test2"})
        status = tracker.getStatus()
        assert status["cacheSize"] == 2

    def testGetStatusIncludesRequestEntries(self):
        """Test getStatus includes request entries."""
        tracker = IdempotencyTracker()
        tracker.recordRequest("req-status-1", {"data": "test1"}, agentId="agent-1")
        tracker.recordRequest("req-status-2", {"data": "test2"}, agentId="agent-2")
        status = tracker.getStatus()
        assert len(status["entries"]) > 0
        entry_ids = [e["requestId"] for e in status["entries"]]
        assert "req-status-1" in entry_ids

    def testGetStatusLimitsEntriesToTen(self):
        """Test getStatus returns at most 10 entries."""
        tracker = IdempotencyTracker()
        # Record 15 requests
        for i in range(15):
            tracker.recordRequest(f"req-{i}", {"data": f"test{i}"})
        status = tracker.getStatus()
        assert len(status["entries"]) <= 10

class TestIdempotencyEntry:
    """Test IdempotencyEntry wrapper."""

    def testIdempotencyEntryStoresResult(self):
        """Test entry stores result and metadata."""
        result = {"status": "success"}
        entry = IdempotencyEntry(result, agentId="agent-x", ttlSeconds=3600)
        assert entry.result == result
        assert entry.agentId == "agent-x"

    def testIdempotencyEntryTracksAge(self):
        """Test entry tracks age correctly."""
        entry = IdempotencyEntry({"data": "test"}, agentId="agent-y")
        age1 = entry.getAgeSeconds()
        time.sleep(0.1)
        age2 = entry.getAgeSeconds()
        assert age2 > age1

    def testIdempotencyEntryRecordsHits(self):
        """Test entry tracks hit count."""
        entry = IdempotencyEntry({"data": "test"}, agentId="agent-z")
        entry.recordHit()
        entry.recordHit()
        # Verify hits were recorded (implementation detail via hitCount attribute)
        assert entry.hitCount == 2

class TestIdempotencyIntegration:
    """Integration tests for idempotency tracking."""

    def testIdempotencyAcrossRetries(self):
        """Test same request ID returns same result on retry."""
        tracker = IdempotencyTracker()
        result1 = {"status": "processing", "taskId": 123}
        tracker.recordRequest("retry-test", result1)

        # Simulate retry
        result2 = tracker.getResult("retry-test")
        assert result2 == result1

    def testIdempotencyWithMultipleAgents(self):
        """Test idempotency tracking with multiple agents."""
        tracker = IdempotencyTracker()
        tracker.recordRequest("multi-agent-1", {"agent": "agent-1"}, agentId="agent-1")
        tracker.recordRequest("multi-agent-2", {"agent": "agent-2"}, agentId="agent-2")

        result1 = tracker.getResult("multi-agent-1")
        result2 = tracker.getResult("multi-agent-2")

        assert result1["agent"] == "agent-1"
        assert result2["agent"] == "agent-2"

    def testIdempotencyCleanupDuringNormalOperation(self):
        """Test cleanup happens during normal operation."""
        tracker = IdempotencyTracker(ttlSeconds=1)
        # Record request
        tracker.recordRequest("cleanup-test", {"data": "original"})

        # Wait for expiration
        time.sleep(1.1)

        # Get expired result triggers cleanup
        result = tracker.getResult("cleanup-test")

        # Result should be None (expired)
        assert result is None
        # Entry should be removed during cleanup
        assert "cleanup-test" not in tracker.requests
