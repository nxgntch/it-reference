"""Comprehensive tests for logging and analytics observability.

Phase 4.2 consolidation: 2 observability test files merged into one domain-focused suite.
Original files: test_log_parser_coverage.py, test_analytics_base_coverage.py

Tests:
- Log parsing: JSON, text, timestamps, file operations, aggregation
- Analytics: mean, stdev, z-score, outliers, percentiles
- Trend analysis: growth rate, confidence, utilization
- Data aggregation by agent, day, and combinations
"""

import json
import tempfile
from datetime import datetime
from pathlib import Path

import pytest

from app.analytics.base import BaseAnalytics
from app.analytics.logParser import LogEntry, LogParser
from tests.utilities.assertionHelpers import (
    assertConditionMet,
    assertMetricValue,
    assertListNotEmpty,
)

# ============================================================================
# LOG PARSER TESTS
# ============================================================================

class TestLogParserJsonEntryParsing:
	"""Test JSON entry parsing edge cases."""

	def testParseJsonEntryInvalidJson(self):
		"""Test parsing invalid JSON triggers exception handler."""
		parser = LogParser()
		# Invalid JSON will trigger JSONDecodeError
		# The line "except (json.JSONDecodeError, ValueError): pass" on line 68
		# will catch it and then try text format
		result = parser.parseLine("{invalid json")
		# Should try text format after JSON fails
		assert result is None or isinstance(result, LogEntry)

	def testParseJsonEntryMissingTimestamp(self):
		"""Test JSON entry with missing timestamp returns None."""
		parser = LogParser()
		data = '{"agent_id": "agent1", "message": "test"}'
		result = parser.parseLine(data)
		# Missing timestamp causes _parseTimestamp to return None
		# Which causes _parseJsonEntry to return None (line 98-99)
		assert result is None

	def testParseJsonEntryExceptionInParseJsonEntry(self):
		"""Test exception in _parseJsonEntry returns None."""
		parser = LogParser()
		# Create malformed data that will pass json.loads but fail in processing
		# This is tricky - we need something that loads as JSON but causes exception
		# Actually, looking at the code, if timestamp is missing, it returns None
		# Let's test that path
		data = json.dumps(
			{
				"timestamp": "",  # Empty timestamp
				"agent_id": "agent1",
				"level": "info",
				"message": "test",
			}
		)
		result = parser.parseLine(data)
		assert result is None

	def testParseJsonEntryWithAllFields(self):
		"""Test successful JSON entry parsing with all fields."""
		parser = LogParser()
		data = json.dumps(
			{
				"timestamp": "2024-01-01T12:00:00",
				"agent_id": "agent1",
				"level": "info",
				"message": "test message",
				"cost": 0.50,
				"tokens_in": 100,
				"tokens_out": 50,
				"latency_ms": 250.5,
				"status": "success",
				"metadata": {"key": "value"},
			}
		)
		result = parser.parseLine(data)

		assert result is not None
		assert result.agent_id == "agent1"
		assert result.cost == 0.50
		assert result.tokens_in == 100
		assert result.tokens_out == 50
		assert result.status == "success"

	def testParseJsonEntryWithAgentAlias(self):
		"""Test JSON entry uses 'agent' as fallback for 'agent_id'."""
		parser = LogParser()
		data = json.dumps(
			{
				"timestamp": "2024-01-01T12:00:00",
				"agent": "architect",  # Using 'agent' instead of 'agent_id'
				"level": "info",
				"message": "test",
			}
		)
		result = parser.parseLine(data)

		assert result is not None
		assert result.agent_id == "architect"

class TestLogParserTextEntryParsing:
	"""Test text entry parsing edge cases."""

	def testParseTextEntryInvalidTimestamp(self):
		"""Test text entry with invalid timestamp returns None."""
		parser = LogParser()
		# Valid format but invalid timestamp
		line = "2024-13-45 12:00:00 | info | test message agent: agent1"
		result = parser.parseLine(line)
		# Invalid timestamp causes _parseTimestamp to return None
		# Which causes _parseTextEntry to return None (line 109)
		assert result is None

	def testParseTextEntryExceptionHandler(self):
		"""Test exception in _parseTextEntry returns None."""
		parser = LogParser()
		# Create a line that matches JSON_PATTERN but causes exception in processing
		# The simplest is an invalid timestamp that won't parse
		line = "invalid_date | info | test message"
		result = parser.parseLine(line)
		# This should return None due to exception handler (line 142-143)
		assert result is None

	def testParseTextEntryValidFormat(self):
		"""Test successful text entry parsing."""
		parser = LogParser()
		line = "2024-01-01T12:00:00 | info | agent: agent1 cost: $0.50 tokens_in: 100 tokens_out: 50 latency: 250.5ms status: success"
		result = parser.parseLine(line)

		assert result is not None
		assert result.agent_id == "agent1"
		assert result.level == "info"
		assert result.cost == 0.50
		assert result.tokens_in == 100
		assert result.tokens_out == 50
		assert result.latency_ms == 250.5
		assert result.status == "success"

class TestLogParserExtractPattern:
	"""Test pattern extraction with parser exception handling."""

	def testExtractPatternWithParserException(self):
		"""Test _extractPattern returns default when parser throws exception."""
		parser = LogParser()
		text = "cost: invalid_number"

		# This will match "invalid_number" but int() will fail
		result = parser._extractPattern(
			text,
			parser.COST_PATTERN,
			default=None,
			parser=int,  # Will fail to parse float string as int
		)
		# Should return default (line 396-397 exception handler)
		assert result is None

	def testExtractPatternWithFloatParserException(self):
		"""Test pattern extraction fails gracefully with bad float."""
		parser = LogParser()
		text = "latency: not_a_number ms"

		result = parser._extractPattern(text, parser.LATENCY_PATTERN, default=0.0, parser=float)
		# Should return default value
		assert result == 0.0

	def testExtractPatternNoMatch(self):
		"""Test pattern extraction returns default when no match."""
		parser = LogParser()
		text = "no numbers here"

		result = parser._extractPattern(text, parser.COST_PATTERN, default=None)
		assert result is None

	def testExtractPatternWithMatch(self):
		"""Test successful pattern extraction."""
		parser = LogParser()
		text = "processing took latency: 500ms to complete"

		result = parser._extractPattern(text, parser.LATENCY_PATTERN, default=0.0, parser=float)
		assert result == 500.0

class TestLogParserTimestampParsing:
	"""Test timestamp parsing with various formats."""

	def testParseTimestampIsoFormat(self):
		"""Test ISO 8601 timestamp parsing."""
		parser = LogParser()
		result = parser._parseTimestamp("2024-01-15T10:30:45.123456")

		assert result is not None
		assert result.year == 2024
		assert result.month == 1
		assert result.day == 15

	def testParseTimestampIsoWithZ(self):
		"""Test ISO format with Z timezone."""
		parser = LogParser()
		result = parser._parseTimestamp("2024-01-15T10:30:45Z")

		assert result is not None
		assert result.year == 2024

	def testParseTimestampDateOnly(self):
		"""Test date-only timestamp."""
		parser = LogParser()
		result = parser._parseTimestamp("2024-01-15")

		assert result is not None
		assert result.year == 2024
		assert result.month == 1
		assert result.day == 15

	def testParseTimestampUnixEpoch(self):
		"""Test Unix epoch timestamp."""
		parser = LogParser()
		# Use a known Unix timestamp (1704067200 is 2024-01-01 00:00:00 UTC)
		result = parser._parseTimestamp("1704067200")

		assert result is not None
		# The timestamp converts correctly
		assert isinstance(result, datetime)

	def testParseTimestampInvalid(self):
		"""Test invalid timestamp returns None."""
		parser = LogParser()
		result = parser._parseTimestamp("invalid_date")

		assert result is None

	def testParseTimestampEmpty(self):
		"""Test empty timestamp returns None."""
		parser = LogParser()
		result = parser._parseTimestamp("")

		assert result is None

class TestLogParserFileOperations:
	"""Test file parsing."""

	def testParseFileWithValidEntries(self):
		"""Test parsing file with valid log entries."""
		with tempfile.TemporaryDirectory() as tmpdir:
			filepath = Path(tmpdir) / "test.log"
			filepath.write_text(
				"2024-01-01T12:00:00 | info | agent: agent1 cost: $0.50\n"
				"2024-01-01T12:01:00 | error | agent: agent2 cost: $1.00\n"
				"# Comment line\n"
				"\n"  # Empty line
				"2024-01-01T12:02:00 | info | agent: agent3 cost: $0.25\n"
			)

			parser = LogParser()
			count = parser.parseFile(str(filepath))

			assert count == 3
			assert len(parser.entries) == 3

	def testParseFileNonexistent(self):
		"""Test parsing non-existent file returns 0."""
		parser = LogParser()
		count = parser.parseFile("/nonexistent/path/file.log")

		assert count == 0

	def testParseFileEmptyFile(self):
		"""Test parsing empty file."""
		with tempfile.TemporaryDirectory() as tmpdir:
			filepath = Path(tmpdir) / "empty.log"
			filepath.write_text("")

			parser = LogParser()
			count = parser.parseFile(str(filepath))

			assert count == 0

class TestLogParserAggregation:
	"""Test aggregation methods."""

	def testAggregateByAgentSingleAgent(self):
		"""Test aggregation by agent with single agent."""
		parser = LogParser()
		parser.entries = [
			LogEntry(
				timestamp=datetime(2024, 1, 1, 12, 0, 0),
				agent_id="agent1",
				level="info",
				message="test",
				cost=0.50,
				tokens_in=100,
				tokens_out=50,
				latency_ms=250.0,
				status="success",
			),
			LogEntry(
				timestamp=datetime(2024, 1, 1, 12, 1, 0),
				agent_id="agent1",
				level="info",
				message="test",
				cost=0.30,
				tokens_in=50,
				tokens_out=25,
				latency_ms=150.0,
				status="success",
			),
		]

		result = parser.aggregateByAgent()

		assert "agent1" in result
		assert result["agent1"]["total_cost"] == 0.80
		assert result["agent1"]["total_tokens_in"] == 150
		assert result["agent1"]["total_tokens_out"] == 75
		assert result["agent1"]["avg_latency_ms"] == 200.0
		assert result["agent1"]["invocations"] == 2
		assert result["agent1"]["successes"] == 2

	def testAggregateByAgentWithErrors(self):
		"""Test aggregation counts errors correctly."""
		parser = LogParser()
		parser.entries = [
			LogEntry(
				timestamp=datetime(2024, 1, 1, 12, 0, 0),
				agent_id="agent1",
				level="error",
				message="failed",
			),
			LogEntry(
				timestamp=datetime(2024, 1, 1, 12, 1, 0),
				agent_id="agent1",
				level="info",
				message="success",
				status="success",
			),
		]

		result = parser.aggregateByAgent()

		assert result["agent1"]["errors"] == 1
		assert result["agent1"]["successes"] == 1

	def testAggregateByDay(self):
		"""Test aggregation by day."""
		parser = LogParser()
		parser.entries = [
			LogEntry(
				timestamp=datetime(2024, 1, 1, 12, 0, 0),
				agent_id="agent1",
				level="info",
				message="test",
				cost=0.50,
			),
			LogEntry(
				timestamp=datetime(2024, 1, 2, 12, 0, 0),
				agent_id="agent1",
				level="info",
				message="test",
				cost=0.30,
			),
		]

		result = parser.aggregateByDay()

		assert "2024-01-01" in result
		assert "2024-01-02" in result
		assert result["2024-01-01"]["total_cost"] == 0.50
		assert result["2024-01-02"]["total_cost"] == 0.30

	def testAggregateByAgentAndDay(self):
		"""Test aggregation by agent and day."""
		parser = LogParser()
		parser.entries = [
			LogEntry(
				timestamp=datetime(2024, 1, 1, 12, 0, 0),
				agent_id="agent1",
				level="info",
				message="test",
				cost=0.50,
			),
			LogEntry(
				timestamp=datetime(2024, 1, 1, 13, 0, 0),
				agent_id="agent2",
				level="info",
				message="test",
				cost=0.30,
			),
		]

		result = parser.aggregateByAgentAndDay()

		assert "agent1" in result
		assert "2024-01-01" in result["agent1"]
		assert result["agent1"]["2024-01-01"]["total_cost"] == 0.50

class TestLogParserDateFiltering:
	"""Test date range filtering."""

	def testFilterByStartDate(self):
		"""Test filtering with start date."""
		parser = LogParser()
		parser.entries = [
			LogEntry(
				timestamp=datetime(2024, 1, 1, 12, 0, 0),
				agent_id="agent1",
				level="info",
				message="test",
			),
			LogEntry(
				timestamp=datetime(2024, 1, 2, 12, 0, 0),
				agent_id="agent1",
				level="info",
				message="test",
			),
		]

		result = parser.aggregateByAgent(start_date=datetime(2024, 1, 2))

		# Should only include agent1 with 1 entry (from Jan 2)
		assert result["agent1"]["invocations"] == 1

	def testFilterByEndDate(self):
		"""Test filtering with end date."""
		parser = LogParser()
		parser.entries = [
			LogEntry(
				timestamp=datetime(2024, 1, 1, 12, 0, 0),
				agent_id="agent1",
				level="info",
				message="test",
			),
			LogEntry(
				timestamp=datetime(2024, 1, 2, 12, 0, 0),
				agent_id="agent1",
				level="info",
				message="test",
			),
		]

		result = parser.aggregateByAgent(end_date=datetime(2024, 1, 1))

		# Should only include Jan 1 entry (end_date includes full day)
		assert result["agent1"]["invocations"] == 1

	def testFilterByDateRange(self):
		"""Test filtering with start and end dates."""
		parser = LogParser()
		parser.entries = [
			LogEntry(
				timestamp=datetime(2024, 1, 1, 12, 0, 0),
				agent_id="agent1",
				level="info",
				message="test",
			),
			LogEntry(
				timestamp=datetime(2024, 1, 2, 12, 0, 0),
				agent_id="agent1",
				level="info",
				message="test",
			),
			LogEntry(
				timestamp=datetime(2024, 1, 3, 12, 0, 0),
				agent_id="agent1",
				level="info",
				message="test",
			),
		]

		result = parser.aggregateByAgent(
			start_date=datetime(2024, 1, 1), end_date=datetime(2024, 1, 2)
		)

		# Should include Jan 1 and Jan 2
		assert result["agent1"]["invocations"] == 2

class TestLogParserSafetyParsing:
	"""Test safe parsing methods."""

	def testParseFloatValid(self):
		"""Test parsing valid float."""
		result = LogParser._parseFloat(3.14)
		assert result == 3.14

	def testParseFloatFromString(self):
		"""Test parsing float from string."""
		result = LogParser._parseFloat("3.14")
		assert result == 3.14

	def testParseFloatInvalid(self):
		"""Test parsing invalid float returns None."""
		result = LogParser._parseFloat("not_a_number")
		assert result is None

	def testParseFloatNone(self):
		"""Test parsing None returns None."""
		result = LogParser._parseFloat(None)
		assert result is None

	def testParseIntValid(self):
		"""Test parsing valid int."""
		result = LogParser._parseInt(42)
		assert result == 42

	def testParseIntFromString(self):
		"""Test parsing int from string."""
		result = LogParser._parseInt("42")
		assert result == 42

	def testParseIntInvalid(self):
		"""Test parsing invalid int returns None."""
		result = LogParser._parseInt("not_a_number")
		assert result is None

	def testParseIntNone(self):
		"""Test parsing None returns None."""
		result = LogParser._parseInt(None)
		assert result is None

class TestLogParserEdgeCases:
	"""Test edge cases and unusual inputs."""

	def testAggregateWithNoLatency(self):
		"""Test aggregation when entries have no latency."""
		parser = LogParser()
		parser.entries = [
			LogEntry(
				timestamp=datetime(2024, 1, 1, 12, 0, 0),
				agent_id="agent1",
				level="info",
				message="test",
				latency_ms=None,
			),
		]

		result = parser.aggregateByAgent()

		assert result["agent1"]["avg_latency_ms"] == 0.0

	def testAggregateWithMultipleAgents(self):
		"""Test aggregation separates multiple agents."""
		parser = LogParser()
		parser.entries = [
			LogEntry(
				timestamp=datetime(2024, 1, 1, 12, 0, 0),
				agent_id="agent1",
				level="info",
				message="test",
				cost=0.50,
			),
			LogEntry(
				timestamp=datetime(2024, 1, 1, 12, 0, 0),
				agent_id="agent2",
				level="info",
				message="test",
				cost=0.30,
			),
		]

		result = parser.aggregateByAgent()

		assert len(result) == 2
		assert result["agent1"]["total_cost"] == 0.50
		assert result["agent2"]["total_cost"] == 0.30

	def testEmptyAggregation(self):
		"""Test aggregation with no entries."""
		parser = LogParser()
		parser.entries = []

		result = parser.aggregateByAgent()

		assert result == {}

	def testAggregateDayWithLatency(self):
		"""Test aggregateByDay includes latency in calculation."""
		parser = LogParser()
		parser.entries = [
			LogEntry(
				timestamp=datetime(2024, 1, 1, 12, 0, 0),
				agent_id="agent1",
				level="info",
				message="test",
				latency_ms=200.0,
			),
			LogEntry(
				timestamp=datetime(2024, 1, 1, 13, 0, 0),
				agent_id="agent1",
				level="info",
				message="test",
				latency_ms=400.0,
			),
		]

		result = parser.aggregateByDay()

		assert result["2024-01-01"]["avg_latency_ms"] == 300.0

	def testAggregateDayWithErrors(self):
		"""Test aggregateByDay counts errors and success."""
		parser = LogParser()
		parser.entries = [
			LogEntry(
				timestamp=datetime(2024, 1, 1, 12, 0, 0),
				agent_id="agent1",
				level="error",
				message="failed",
			),
			LogEntry(
				timestamp=datetime(2024, 1, 1, 13, 0, 0),
				agent_id="agent1",
				level="info",
				message="success",
				status="success",
			),
		]

		result = parser.aggregateByDay()

		assert result["2024-01-01"]["errors"] == 1
		assert result["2024-01-01"]["successes"] == 1

	def testAggregateByAgentAndDayWithLatency(self):
		"""Test aggregateByAgentAndDay includes latency."""
		parser = LogParser()
		parser.entries = [
			LogEntry(
				timestamp=datetime(2024, 1, 1, 12, 0, 0),
				agent_id="agent1",
				level="info",
				message="test",
				latency_ms=250.0,
			),
			LogEntry(
				timestamp=datetime(2024, 1, 1, 13, 0, 0),
				agent_id="agent1",
				level="info",
				message="test",
				latency_ms=350.0,
			),
		]

		result = parser.aggregateByAgentAndDay()

		assert result["agent1"]["2024-01-01"]["avg_latency_ms"] == 300.0

	def testAggregateByAgentAndDayWithErrors(self):
		"""Test aggregateByAgentAndDay counts errors and success."""
		parser = LogParser()
		parser.entries = [
			LogEntry(
				timestamp=datetime(2024, 1, 1, 12, 0, 0),
				agent_id="agent1",
				level="error",
				message="failed",
			),
			LogEntry(
				timestamp=datetime(2024, 1, 1, 13, 0, 0),
				agent_id="agent1",
				level="info",
				message="success",
				status="success",
			),
			LogEntry(
				timestamp=datetime(2024, 1, 2, 12, 0, 0),
				agent_id="agent1",
				level="error",
				message="another failure",
			),
		]

		result = parser.aggregateByAgentAndDay()

		assert result["agent1"]["2024-01-01"]["errors"] == 1
		assert result["agent1"]["2024-01-01"]["successes"] == 1
		assert result["agent1"]["2024-01-02"]["errors"] == 1

# ============================================================================
# ANALYTICS BASE TESTS
# ============================================================================

@pytest.mark.unit
class TestCalculateMean:
	"""Test mean calculation."""

	@pytest.mark.parametrize(
		"data,expected",
		[
			([1, 2, 3, 4, 5], 3.0),
			([10], 10.0),
			([0, 0, 0], 0.0),
			([], 0),
			([1.5, 2.5, 3.5], 2.5),
			([-1, -2, -3], -2.0),
		],
	)
	def testCalculatesMeanCorrectly(self, data, expected):
		"""Test mean calculation with various inputs."""
		result = BaseAnalytics.calculateMean(data)
		assert result == expected

	def testCalculateMeanEmptyReturnsZero(self):
		"""Test mean of empty list."""
		assert BaseAnalytics.calculateMean([]) == 0

@pytest.mark.unit
class TestCalculateStdev:
	"""Test standard deviation calculation."""

	def testCalculatesStdevCorrectly(self):
		"""Test standard deviation calculation."""
		data = [1, 2, 3, 4, 5]
		result = BaseAnalytics.calculateStdev(data)
		# stdev of [1,2,3,4,5] is ~1.58
		assert 1.5 < result < 1.6

	def testCalculatesStdevSingleValue(self):
		"""Test stdev with single value."""
		result = BaseAnalytics.calculateStdev([10])
		assert result == 0

	def testCalculatesStdevEmpty(self):
		"""Test stdev with empty list."""
		result = BaseAnalytics.calculateStdev([])
		assert result == 0

	@pytest.mark.parametrize(
		"data,expected",
		[
			([1], 0),
			([1, 1], 0),
			([], 0),
		],
	)
	def testCalculatesStdevInsufficientData(self, data, expected):
		"""Test stdev with insufficient data."""
		result = BaseAnalytics.calculateStdev(data)
		assert result == expected

@pytest.mark.unit
class TestCalculateZScore:
	"""Test z-score calculation."""

	def testCalculatesZScoreCorrectly(self):
		"""Test z-score calculation."""
		value = 10
		mean = 5
		std_dev = 2
		result = BaseAnalytics.calculateZScore(value, mean, std_dev)
		assert result == 2.5

	def testCalculatesZScoreNegative(self):
		"""Test negative z-score."""
		result = BaseAnalytics.calculateZScore(0, 5, 2)
		assert result == -2.5

	def testCalculatesZScoreZeroStdev(self):
		"""Test z-score when std_dev is 0."""
		# Same value as mean
		result = BaseAnalytics.calculateZScore(5, 5, 0)
		assert result == 0

		# Different value than mean
		result = BaseAnalytics.calculateZScore(10, 5, 0)
		assert result == float("inf")

@pytest.mark.unit
class TestRemoveOutliers:
	"""Test outlier removal."""

	def testRemovesOutliersCorrectly(self):
		"""Test removing outliers using z-score."""
		data = [10, 11, 12, 13, 14, 100]  # 100 is outlier
		result = BaseAnalytics.removeOutliers(data, threshold=2.0)
		assert 100 not in result
		assert len(result) == 5

	def testKeepsAllIfNoOutliers(self):
		"""Test keeping all data if no outliers."""
		data = [1, 2, 3, 4, 5]
		result = BaseAnalytics.removeOutliers(data)
		assert len(result) == 5

	def testHandlesEmptyData(self):
		"""Test removing outliers from empty list."""
		result = BaseAnalytics.removeOutliers([])
		assert result == []

	def testHandlesSingleValue(self):
		"""Test removing outliers with single value."""
		result = BaseAnalytics.removeOutliers([10])
		assert result == [10]

	def testHandlesZeroStdev(self):
		"""Test outlier removal when all values are same."""
		data = [5, 5, 5, 5]
		result = BaseAnalytics.removeOutliers(data)
		assert result == data

	def testEmptyAfterRemovalReturnsOriginal(self):
		"""Test that original is returned if all removed."""
		data = [1, 1, 1, 100]
		result = BaseAnalytics.removeOutliers(data, threshold=0.1)
		# Should return original if cleaning would empty it
		assert len(result) > 0

@pytest.mark.unit
class TestCalculatePercentile:
	"""Test percentile calculation."""

	@pytest.mark.parametrize(
		"data,percentile,expected",
		[
			([1, 2, 3, 4, 5], 50, 2),
			([1, 2, 3, 4, 5], 25, 1),
			([1, 2, 3, 4, 5], 75, 3),
			([10], 50, 10),
			([5, 1, 3, 2, 4], 50, 2),  # Unsorted -> sorted [1,2,3,4,5]
		],
	)
	def testCalculatesPercentileCorrectly(self, data, percentile, expected):
		"""Test percentile calculation."""
		result = BaseAnalytics.calculatePercentile(data, percentile)
		assert result == expected

	def testCalculatesPercentileEmpty(self):
		"""Test percentile on empty data."""
		result = BaseAnalytics.calculatePercentile([], 50)
		assert result == 0

	def testCalculatesPercentile100(self):
		"""Test 100th percentile."""
		data = [1, 2, 3, 4, 5]
		result = BaseAnalytics.calculatePercentile(data, 100)
		assert result == 5

@pytest.mark.unit
class TestCalculateTrendDirection:
	"""Test trend direction calculation."""

	def testDetectsImprovingTrend(self):
		"""Test detecting improving trend (cost decrease)."""
		history = [100, 95, 90, 85, 80, 75, 70]
		direction, pctChange = BaseAnalytics.calculateTrendDirection(history)
		assert direction == "improving"
		assert pctChange < -10

	def testDetectsDegradingTrend(self):
		"""Test detecting degrading trend (cost increase)."""
		history = [50, 55, 60, 65, 70, 75, 80]
		direction, pctChange = BaseAnalytics.calculateTrendDirection(history)
		assert direction == "degrading"
		assert pctChange > 10

	def testDetectsStableTrend(self):
		"""Test detecting stable trend."""
		history = [100, 102, 98, 101, 99, 100, 102]
		direction, pctChange = BaseAnalytics.calculateTrendDirection(history)
		assert direction == "stable"
		assert abs(pctChange) <= 10

	def testHandlesInsufficientData(self):
		"""Test trend with insufficient data."""
		assert BaseAnalytics.calculateTrendDirection([1]) == ("stable", 0.0)
		assert BaseAnalytics.calculateTrendDirection([1, 2]) == ("stable", 0.0)

	def testHandlesEmptyFirstHalf(self):
		"""Test when first half is empty."""
		history = [100]
		result = BaseAnalytics.calculateTrendDirection(history)
		assert result == ("stable", 0.0)

	def testHandlesZeroAverage(self):
		"""Test when first half average is zero."""
		history = [0, 0, 1, 2]
		result = BaseAnalytics.calculateTrendDirection(history)
		assert result == ("stable", 0.0)

@pytest.mark.unit
class TestCalculateGrowthRate:
	"""Test growth rate calculation."""

	def testCalculatesPositiveGrowth(self):
		"""Test calculating positive growth rate."""
		history = [100, 110, 120]
		rate = BaseAnalytics.calculateGrowthRate(history)
		assert 0 < rate <= 0.20

	def testCalculatesNegativeGrowth(self):
		"""Test calculating negative growth rate."""
		history = [100, 90, 80]
		rate = BaseAnalytics.calculateGrowthRate(history)
		assert -0.10 <= rate < 0

	def testCapsCap(self):
		"""Test that growth rate is capped at 20%."""
		history = [1, 100, 10000]  # Extreme growth
		rate = BaseAnalytics.calculateGrowthRate(history)
		assert rate <= 0.20

	def testCapsFloor(self):
		"""Test that growth rate is floored at -10%."""
		history = [100, 10, 1]  # Extreme decline
		rate = BaseAnalytics.calculateGrowthRate(history)
		assert rate >= -0.10

	def testHandlesInsufficientData(self):
		"""Test with insufficient history."""
		assert BaseAnalytics.calculateGrowthRate([]) == 0.05
		assert BaseAnalytics.calculateGrowthRate([100]) == 0.05

	def testHandlesZeroValues(self):
		"""Test growth rate with zero values."""
		history = [0, 0, 1]
		rate = BaseAnalytics.calculateGrowthRate(history)
		# Should handle gracefully
		assert -0.10 <= rate <= 0.20

@pytest.mark.unit
class TestCalculateConfidence:
	"""Test confidence score calculation."""

	@pytest.mark.parametrize(
		"sample_size,target_size,expected",
		[
			(30, 30, 1.0),
			(15, 30, 0.5),
			(60, 30, 1.0),  # Capped at 1.0
			(0, 30, 0.0),
			(10, 20, 0.5),
		],
	)
	def testCalculatesConfidenceCorrectly(self, sample_size, target_size, expected):
		"""Test confidence score calculation."""
		result = BaseAnalytics.calculateConfidence(sample_size, target_size)
		assert result == expected

	def testDefaultTargetSize(self):
		"""Test using default target size."""
		result = BaseAnalytics.calculateConfidence(30)
		assert result == 1.0

@pytest.mark.unit
class TestCalculateUtilization:
	"""Test utilization calculation."""

	@pytest.mark.parametrize(
		"used,capacity,expected",
		[
			(50, 100, 50.0),
			(100, 100, 100.0),
			(0, 100, 0.0),
			(75, 100, 75.0),
			(100, 0, 0.0),  # Zero capacity
		],
	)
	def testCalculatesUtilizationCorrectly(self, used, capacity, expected):
		"""Test utilization calculation."""
		result = BaseAnalytics.calculateUtilization(used, capacity)
		assert result == expected

@pytest.mark.unit
class TestCalculateStatusFromUtilization:
	"""Test status determination from utilization."""

	@pytest.mark.parametrize(
		"utilization,expected",
		[
			(50, "ok"),
			(80, "ok"),
			(85, "warning"),
			(90, "warning"),
			(95, "critical"),
			(99, "critical"),
			(100, "exceeded"),
			(150, "exceeded"),
		],
	)
	def testDeterminesStatusCorrectly(self, utilization, expected):
		"""Test status determination from utilization."""
		result = BaseAnalytics.calculateStatusFromUtilization(utilization)
		assert result == expected

@pytest.mark.unit
class TestCalculateRollingAverage:
	"""Test rolling average calculation."""

	def testCalculatesRollingAverageDefault(self):
		"""Test rolling average with default window."""
		data = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
		result = BaseAnalytics.calculateRollingAverage(data)  # window=7
		# Last 7 values: [4, 5, 6, 7, 8, 9, 10] -> avg=7
		assert result == 7.0

	def testCalculatesRollingAverageCustomWindow(self):
		"""Test rolling average with custom window."""
		data = [1, 2, 3, 4, 5]
		result = BaseAnalytics.calculateRollingAverage(data, window_size=3)
		# Last 3 values: [3, 4, 5] -> avg=4
		assert result == 4.0

	def testHandlesSmallWindow(self):
		"""Test rolling average with window larger than data."""
		data = [1, 2, 3]
		result = BaseAnalytics.calculateRollingAverage(data, window_size=10)
		# All available data: avg=2
		assert result == 2.0

	def testHandlesEmptyData(self):
		"""Test rolling average with empty data."""
		result = BaseAnalytics.calculateRollingAverage([], window_size=7)
		assert result == 0

@pytest.mark.unit
class TestCompareWithBaseline:
	"""Test baseline comparison."""

	def testComparesHigherValue(self):
		"""Test comparing higher value than baseline."""
		pctChange, status = BaseAnalytics.compareWithBaseline(110, 100)
		assert status == "higher"
		assert pctChange == 10.0

	def testComparesLowerValue(self):
		"""Test comparing lower value than baseline."""
		pctChange, status = BaseAnalytics.compareWithBaseline(90, 100)
		assert status == "lower"
		assert pctChange == -10.0

	def testComparesStableValue(self):
		"""Test comparing similar value (within threshold)."""
		pctChange, status = BaseAnalytics.compareWithBaseline(102, 100)
		assert status == "stable"
		assert abs(pctChange) <= 5

	def testHandlesZeroBaseline(self):
		"""Test comparison with zero baseline."""
		pctChange, status = BaseAnalytics.compareWithBaseline(100, 0)
		assert pctChange == 0.0
		assert status == "stable"

	@pytest.mark.parametrize(
		"current,baseline,expected_status",
		[
			(106, 100, "higher"),  # >5%
			(105, 100, "stable"),  # =5% (not > 5)
			(94, 100, "lower"),  # <-5%
			(95, 100, "stable"),  # =-5% (not < -5)
		],
	)
	def testThresholdHandling(self, current, baseline, expected_status):
		"""Test 5% threshold handling."""
		_, status = BaseAnalytics.compareWithBaseline(current, baseline)
		assert status == expected_status
