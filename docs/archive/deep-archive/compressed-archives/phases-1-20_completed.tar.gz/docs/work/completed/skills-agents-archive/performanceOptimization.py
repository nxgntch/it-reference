"""Performance optimization skill for agents.
Analyze metrics and generate optimization tasks when performance degrades.
Used by engineering manager to create performance improvement work.
"""

from dataclasses import dataclass
from typing import Any, Dict, List, Optional


@dataclass
class OptimizationTask:
    """Generated optimization task"""

    task_type: str  # latency, throughput, error_rate, cost
    priority: str  # low, medium, high, critical
    description: str
    expected_improvement: str
    estimated_effort: str  # hours
    metrics_to_improve: List[str]
    success_criteria: str


class PerformanceOptimizationSkill:
    """Generate optimization tasks based on metrics."""

    def __init__(self, dashboard_registry=None, log_aggregator=None):
        """Initialize performance optimization skill.
        Args:
           dashboard_registry: DashboardRegistry instance for metrics
           log_aggregator: LogAggregator for error pattern analysis
        """
        self.registry = dashboard_registry
        self.log_aggregator = log_aggregator

    def generateOptimizationTasks(
        self,
        current_metrics: Dict[str, Any],
        budget_available: float,
        baseline_metrics: Optional[Dict[str, Any]] = None,
    ) -> List[OptimizationTask]:
        """Generate optimization tasks from current metrics.
        Args:
           current_metrics: Current system metrics
           budget_available: Available budget for optimization work
           baseline_metrics: Optional baseline for comparison
        Returns:
           List of optimization tasks prioritized by impact
        """
        tasks = []

        # Check latency
        latency_p95 = current_metrics.get("latency_p95", 0)
        if latency_p95 > 500:  # 500ms threshold
            tasks.append(
                OptimizationTask(
                    task_type="latency",
                    priority=self._calculatePriority(latency_p95, 200, 500, 1000),
                    description=f"Reduce API latency from {latency_p95}ms p95 to <200ms",
                    expected_improvement="50-80% latency reduction",
                    estimated_effort="16 hours",
                    metrics_to_improve=["latency_p50", "latency_p95", "latency_p99"],
                    success_criteria="Achieve <200ms p95 latency sustained",
                )
            )

        # Check error rate
        error_rate = current_metrics.get("error_rate", 0)
        if error_rate > 0.01:  # >1% threshold
            tasks.append(
                OptimizationTask(
                    task_type="error_rate",
                    priority=self._calculatePriority(error_rate, 0, 0.01, 0.05),
                    description=f"Reduce error rate from {error_rate * 100:.2f}% to <0.1%",
                    expected_improvement="50-90% error reduction",
                    estimated_effort="12 hours",
                    metrics_to_improve=["error_rate", "error_by_type"],
                    success_criteria="Achieve <0.1% error rate for 24 hours",
                )
            )

        # Check throughput
        throughput = current_metrics.get("throughput", 0)
        if throughput < 100:  # <100 req/s threshold
            tasks.append(
                OptimizationTask(
                    task_type="throughput",
                    priority="medium",
                    description=f"Increase throughput from {throughput} to 200+ req/s",
                    expected_improvement="2-4x throughput improvement",
                    estimated_effort="20 hours",
                    metrics_to_improve=["throughput", "concurrent_requests"],
                    success_criteria="Sustain 200+ req/s with <200ms latency",
                )
            )

        # Check CPU/Memory
        cpu_usage = current_metrics.get("cpu_usage", 0)
        memory_usage = current_metrics.get("memory_usage", 0)

        if cpu_usage > 80:
            tasks.append(
                OptimizationTask(
                    task_type="resource_efficiency",
                    priority="high",
                    description=f"Reduce CPU usage from {cpu_usage:.0f}% to <60%",
                    expected_improvement="25-40% CPU reduction",
                    estimated_effort="8 hours",
                    metrics_to_improve=["cpu_usage", "cpu_per_request"],
                    success_criteria="Maintain <60% CPU at peak load",
                )
            )

        if memory_usage > 85:
            tasks.append(
                OptimizationTask(
                    task_type="resource_efficiency",
                    priority="high",
                    description=f"Reduce memory usage from {memory_usage:.0f}% to <70%",
                    expected_improvement="15-25% memory reduction",
                    estimated_effort="6 hours",
                    metrics_to_improve=["memory_usage", "memory_leaks"],
                    success_criteria="Maintain <70% memory at sustained load",
                )
            )

        # Sort by priority and estimate effort cost
        priority_order = {"critical": 0, "high": 1, "medium": 2, "low": 3}
        tasks.sort(key=lambda t: (priority_order.get(t.priority, 999), t.estimated_effort))

        # Filter by budget
        total_hours = 0
        affordable_tasks = []
        hourly_cost = 50  # Assume $50/hour

        for task in tasks:
            task_hours = int(task.estimated_effort.split()[0])
            task_cost = task_hours * hourly_cost

            if total_hours * hourly_cost + task_cost <= budget_available:
                affordable_tasks.append(task)
                total_hours += task_hours
            elif task.priority == "critical":
                # Always include critical tasks
                affordable_tasks.append(task)

        return affordable_tasks

    def analyzePerformanceTrend(
        self,
        metric_history: Dict[str, list],
        metric_name: str,
    ) -> Dict[str, Any]:
        """Analyze performance trend for a specific metric.
        Args:
           metric_history: Dict with metric names and lists of values over time
           metric_name: Name of metric to analyze
        Returns:
           Trend analysis with direction and confidence
        """
        values = metric_history.get(metric_name, [])

        if len(values) < 2:
            return {"trend": "insufficient_data", "confidence": 0}

        # Calculate linear trend
        n = len(values)
        x_sum = n * (n - 1) / 2  # Sum of 0..n-1
        y_sum = sum(values)
        xy_sum = sum(i * values[i] for i in range(n))
        x2_sum = n * (n - 1) * (2 * n - 1) / 6

        # Slope calculation
        slope = (
            (n * xy_sum - x_sum * y_sum) / (n * x2_sum - x_sum**2)
            if n * x2_sum - x_sum**2 != 0
            else 0
        )

        # Determine trend
        if abs(slope) < 0.01:
            trend = "stable"
            confidence = 0.7
        elif slope > 0.01:
            trend = "degrading"
            confidence = min(0.95, 0.5 + (abs(slope) / 10))
        else:
            trend = "improving"
            confidence = min(0.95, 0.5 + (abs(slope) / 10))

        return {
            "metric": metric_name,
            "trend": trend,
            "slope": slope,
            "confidence": confidence,
            "current_value": values[-1],
            "recommendation": self._trendRecommendation(trend, slope),
        }

    def identifyBottlenecks(
        self,
        service_metrics: Dict[str, Dict[str, Any]],
    ) -> List[Dict[str, Any]]:
        """Identify performance bottlenecks across services.
        Args:
           service_metrics: Metrics dict with service names and their metrics
        Returns:
           List of identified bottlenecks ranked by severity
        """
        bottlenecks = []

        for service, metrics in service_metrics.items():
            # Check latency
            if metrics.get("latency_p95", 0) > 300:
                bottlenecks.append(
                    {
                        "service": service,
                        "type": "latency",
                        "severity": "high",
                        "value": metrics["latency_p95"],
                        "recommendation": f"Profile {service} and optimize hot paths",
                    }
                )

            # Check queue depth
            if metrics.get("queue_depth", 0) > 1000:
                bottlenecks.append(
                    {
                        "service": service,
                        "type": "queue",
                        "severity": "high",
                        "value": metrics["queue_depth"],
                        "recommendation": f"Scale {service} or reduce upstream load",
                    }
                )

            # Check error rate
            if metrics.get("error_rate", 0) > 0.02:
                bottlenecks.append(
                    {
                        "service": service,
                        "type": "error_rate",
                        "severity": "critical",
                        "value": metrics["error_rate"],
                        "recommendation": f"Investigate errors in {service}",
                    }
                )

        # Sort by severity
        severity_order = {"critical": 0, "high": 1, "medium": 2, "low": 3}
        bottlenecks.sort(key=lambda b: severity_order.get(b["severity"], 999))

        return bottlenecks

    def _calculatePriority(
        self,
        current: float,
        ideal: float,
        warning: float,
        critical: float,
    ) -> str:
        """Calculate priority based on thresholds.
        Args:
           current: Current value
           ideal: Ideal target value
           warning: Warning threshold
           critical: Critical threshold
        Returns:
           Priority level
        """
        if current >= critical:
            return "critical"
        elif current >= warning:
            return "high"
        else:
            return "medium"

    def _trendRecommendation(self, trend: str, slope: float) -> str:
        """Generate recommendation based on trend.
        Args:
           trend: Trend direction
           slope: Trend slope
        Returns:
           Recommendation string
        """
        if trend == "degrading":
            if abs(slope) > 0.1:
                return "URGENT: Performance degrading rapidly. Investigate immediately."
            else:
                return "Performance slowly degrading. Monitor and prepare optimization work."
        if trend == "improving":
            return "Performance improving. Continue current optimizations."
        return "Performance stable. No urgent action needed."


def performanceOptimization(
    dashboard_registry=None,
    log_aggregator=None,
) -> PerformanceOptimizationSkill:
    """Factory function for dependency injection.
    Usage in any agent:
       from skills.agents.performanceOptimization import performanceOptimization
       skill = performanceOptimization(dashboard_registry, log_aggregator)
       tasks = skill.generateOptimizationTasks(metrics, budget)
    """
    return PerformanceOptimizationSkill(
        dashboard_registry=dashboard_registry,
        log_aggregator=log_aggregator,
    )
