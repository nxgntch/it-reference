"""Incident response skill for agents.
Auto-route critical alerts to appropriate teams and agents.
Used by operations manager for rapid incident response.
"""

from dataclasses import dataclass
from datetime import datetime
from typing import Any, Dict, Optional


@dataclass
class IncidentResponse:
    """Incident response routing"""

    alert_id: str
    severity: str  # info, warning, critical, emergency
    target_team: str
    target_agent: str
    reasoning: str
    urgency_level: int  # 1-5
    estimated_impact: str
    recommended_action: str


class IncidentResponseSkill:
    """Route and respond to incidents."""

    def __init__(self, log_aggregator=None, alert_manager=None):
        """Initialize incident response skill.
        Args:
           log_aggregator: LogAggregator instance for context
           alert_manager: Alert management system for routing
        """
        self.log_aggregator = log_aggregator
        self.alert_manager = alert_manager

    def escalateAlert(
        self,
        alert: Dict[str, Any],
        severity: str,
        oncall_schedule: Optional[Dict[str, Any]] = None,
    ) -> IncidentResponse:
        """Route alert to appropriate team and agent.
        Args:
           alert: Alert details (service, error, metric)
           severity: Alert severity (info, warning, critical, emergency)
           oncall_schedule: Optional current on-call assignments
        Returns:
           IncidentResponse with routing decision
        """
        alert_id = alert.get("id", "unknown")
        service = alert.get("service", "unknown")
        error_type = alert.get("error_type", "unknown")
        metric = alert.get("metric", "unknown")

        # Determine target team and agent
        target_team, target_agent = self._selectResponseTeam(
            service=service,
            error_type=error_type,
            metric=metric,
            severity=severity,
            oncall_schedule=oncall_schedule,
        )

        # Calculate urgency
        urgency_level = self._calculateUrgency(severity, service)

        # Estimate impact
        estimated_impact = self._estimateImpact(alert)

        # Generate reasoning
        reasoning = f"{severity.upper()} alert in {service}: {error_type or metric}"

        # Recommend action
        recommended_action = self._recommendAction(severity, error_type, service)

        return IncidentResponse(
            alert_id=alert_id,
            severity=severity,
            target_team=target_team,
            target_agent=target_agent,
            reasoning=reasoning,
            urgency_level=urgency_level,
            estimated_impact=estimated_impact,
            recommended_action=recommended_action,
        )

    def createIncidentTicket(
        self,
        alert: Dict[str, Any],
        escalation: IncidentResponse,
    ) -> Dict[str, Any]:
        """Create incident ticket from alert.
        Args:
           alert: Original alert
           escalation: Escalation routing decision
        Returns:
           Incident ticket ready for assignment
        """
        return {
            "incident_id": f"INC-{escalation.alert_id}",
            "title": self._generateTitle(alert),
            "description": self._generateDescription(alert, escalation),
            "severity": escalation.severity,
            "assigned_team": escalation.target_team,
            "assigned_agent": escalation.target_agent,
            "urgency_level": escalation.urgency_level,
            "created_at": datetime.utcnow().isoformat(),
            "status": "open",
            "related_alert": alert.get("id"),
        }

    def analyzeMTTR(
        self,
        incident_history: list,
        lookback_days: int = 30,
    ) -> Dict[str, Any]:
        """Analyze Mean Time To Resolution (MTTR).
        Args:
           incident_history: List of resolved incidents
           lookback_days: Days to look back
        Returns:
           MTTR analysis with trends
        """
        if not incident_history:
            return {"mttr_minutes": 0, "count": 0, "message": "No incidents"}

        # Filter by lookback period
        recent_incidents = [
            i
            for i in incident_history
            if (datetime.utcnow() - datetime.fromisoformat(i.get("created_at", ""))).days
            <= lookback_days
        ]

        if not recent_incidents:
            return {"mttr_minutes": 0, "count": 0, "message": "No recent incidents"}

        # Calculate MTTR
        resolution_times = []
        for incident in recent_incidents:
            if incident.get("resolved_at"):
                created = datetime.fromisoformat(incident["created_at"])
                resolved = datetime.fromisoformat(incident["resolved_at"])
                minutes = (resolved - created).total_seconds() / 60
                resolution_times.append(minutes)

        if not resolution_times:
            return {
                "mttr_minutes": 0,
                "count": len(recent_incidents),
                "message": "No resolved incidents",
            }

        avg_mttr = sum(resolution_times) / len(resolution_times)
        median_mttr = sorted(resolution_times)[len(resolution_times) // 2]

        # Analyze by severity
        severity_mttr = {}
        for severity in ["info", "warning", "critical", "emergency"]:
            sev_incidents = [i for i in recent_incidents if i.get("severity") == severity]
            if sev_incidents:
                sev_times = []
                for incident in sev_incidents:
                    if incident.get("resolved_at"):
                        created = datetime.fromisoformat(incident["created_at"])
                        resolved = datetime.fromisoformat(incident["resolved_at"])
                        minutes = (resolved - created).total_seconds() / 60
                        sev_times.append(minutes)

                if sev_times:
                    severity_mttr[severity] = sum(sev_times) / len(sev_times)

        return {
            "mttr_minutes": avg_mttr,
            "median_mttr_minutes": median_mttr,
            "incident_count": len(recent_incidents),
            "by_severity": severity_mttr,
            "lookback_days": lookback_days,
            "trend": self._calculateMTTRTrend(resolution_times),
        }

    def recommendAlertTuning(
        self,
        alert_stats: Dict[str, Any],
        false_positive_rate: float,
        alert_volume: int,
    ) -> Dict[str, Any]:
        """Recommend alert threshold tuning.
        Args:
           alert_stats: Alert statistics
           false_positive_rate: Percentage of false positives
           alert_volume: Total alerts per day
        Returns:
           Tuning recommendations
        """
        recommendations = []

        # Check false positive rate
        if false_positive_rate > 0.3:
            recommendations.append(
                {
                    "alert": "High false positive rate",
                    "current": f"{false_positive_rate * 100:.1f}%",
                    "recommended": "Increase threshold by 10-20%",
                    "impact": "Reduce noise while maintaining coverage",
                }
            )

        # Check alert volume
        if alert_volume > 1000:
            recommendations.append(
                {
                    "alert": "High alert volume",
                    "current": f"{alert_volume} alerts/day",
                    "recommended": "Aggregate similar alerts or increase thresholds",
                    "impact": "Reduce alert fatigue for on-call",
                }
            )

        # Check recovery rate
        recovery_rate = alert_stats.get("recovery_rate", 0)
        if recovery_rate < 0.8:
            recommendations.append(
                {
                    "alert": "Low recovery rate",
                    "current": f"{recovery_rate * 100:.1f}%",
                    "recommended": "Review alert dependencies and alert flapping",
                    "impact": "Improve alert reliability",
                }
            )

        return {
            "recommendations": recommendations,
            "overall_health": self._assessAlertHealth(false_positive_rate, alert_volume),
            "tuning_priority": "high" if false_positive_rate > 0.3 else "medium",
        }

    def _selectResponseTeam(
        self,
        service: str,
        error_type: str,
        metric: str,
        severity: str,
        oncall_schedule: Optional[Dict[str, Any]] = None,
    ) -> tuple:
        """Select team and agent for incident response.
        Returns:
           (team, agent) tuple
        """
        # Service-based routing
        service_routing = {
            "api": ("engineering", "engineeringManager"),
            "database": ("engineering", "engineeringManager"),
            "cache": ("engineering", "engineeringManager"),
            "monitoring": ("operations", "operationsManager"),
            "logging": ("operations", "operationsManager"),
            "auth": ("security", "securityManager"),
            "cost": ("operations", "operationsManager"),
        }

        team, agent = service_routing.get(service, ("engineering", "engineeringManager"))

        # Override with on-call if available
        if oncall_schedule:
            oncall_agent = oncall_schedule.get(team)
            if oncall_agent:
                agent = oncall_agent

        return team, agent

    def _calculateUrgency(self, severity: str, service: str) -> int:
        """Calculate urgency level 1-5.
        Returns:
           Urgency level
        """
        severity_level = {
            "info": 1,
            "warning": 2,
            "critical": 4,
            "emergency": 5,
        }
        # Critical services get boost
        if service in ["api", "database", "auth"]:
            return min(5, severity_level.get(severity, 3) + 1)
        return severity_level.get(severity, 3)

    def _estimateImpact(self, alert: Dict[str, Any]) -> str:
        """Estimate business impact.
        Returns:
           Impact description
        """
        service = alert.get("service", "")
        error_count = alert.get("error_count", 0)
        if error_count > 1000:
            impact = "Severe"
        elif error_count > 100:
            impact = "High"
        elif error_count > 10:
            impact = "Medium"
        else:
            impact = "Low"
        if service in ["api", "auth", "database"]:
            impact = min("Severe", impact)  # Boost for critical services
        return f"{impact} - {error_count} errors"

    def _recommendAction(self, severity: str, error_type: str, service: str) -> str:
        """Recommend immediate action.
        Returns:
           Action string
        """
        if severity == "emergency":
            return f"IMMEDIATE: Page on-call engineer to investigate {service}"
        if severity == "critical":
            return f"Immediate: Investigate {error_type} in {service}, page if needed"
        if severity == "warning":
            return "Create incident and assign to team for investigation"
        return "Log and monitor"

    def _calculateMTTRTrend(self, resolution_times: list) -> str:
        """Calculate MTTR trend.
        Returns:
           Trend direction
        """
        if len(resolution_times) < 2:
            return "insufficient_data"
        recent_avg = sum(resolution_times[-5:]) / min(5, len(resolution_times))
        older_avg = (
            sum(resolution_times[:-5]) / max(1, len(resolution_times) - 5)
            if len(resolution_times) > 5
            else recent_avg
        )
        if recent_avg > older_avg * 1.1:
            return "degrading"
        elif recent_avg < older_avg * 0.9:
            return "improving"
        return "stable"

    def _generateTitle(self, alert: Dict[str, Any]) -> str:
        """Generate incident title.
        Returns:
           Title string
        """
        service = alert.get("service", "unknown")
        error_type = alert.get("error_type") or alert.get("metric", "unknown")
        return f"{service}: {error_type}"

    def _generateDescription(
        self,
        alert: Dict[str, Any],
        escalation: IncidentResponse,
    ) -> str:
        """Generate incident description.
        Returns:
           Description string
        """
        return f"""Alert: {escalation.alert_id}
Service: {alert.get('service')}
Error: {alert.get('error_type') or alert.get('metric')}
Severity: {escalation.severity}
Estimated Impact: {escalation.estimated_impact}
Recommended Action: {escalation.recommended_action}

Related Alert Details:
{alert!s}"""

    def _assessAlertHealth(self, false_positive_rate: float, alert_volume: int) -> str:
        """Assess overall alert system health.
        Returns:
           Health status
        """
        if false_positive_rate > 0.4 or alert_volume > 2000:
            return "poor"
        elif false_positive_rate > 0.2 or alert_volume > 1000:
            return "fair"
        else:
            return "good"


def incidentResponse(
    log_aggregator=None,
    alert_manager=None,
) -> IncidentResponseSkill:
    """Factory function for dependency injection.
    Usage in any agent:
       from skills.agents.incidentResponse import incidentResponse
       skill = incidentResponse(log_aggregator, alert_manager)
       response = skill.escalateAlert(alert, severity)
    """
    return IncidentResponseSkill(
        log_aggregator=log_aggregator,
        alert_manager=alert_manager,
    )
