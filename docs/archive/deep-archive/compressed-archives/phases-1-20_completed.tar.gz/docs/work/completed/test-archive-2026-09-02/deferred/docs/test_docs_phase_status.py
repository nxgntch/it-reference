"""Tests for PhaseStatusGenerator (Phase 5.2)."""

from pathlib import Path
from tempfile import TemporaryDirectory

import pytest

from tests.utilities.assertionHelpers import (
    assertConditionMet,
    assertListLength,
    assertMetricValue,
)
from scripts.docs.phase_status_generator import PhaseStatusGenerator

pytestmark = pytest.mark.docs

pytestmark = [pytest.mark.unit, pytest.mark.docs]

class TestPhaseStatusGeneratorInitialization:
    """Test PhaseStatusGenerator initialization."""

    def testInitializesWithDefaults(self):
        """Test initialization with default parameters."""
        gen = PhaseStatusGenerator()
        assert gen.name == "phase-status"
        assert gen.auditPath == Path("AUDIT.md")

    def testInitializesWithCustomPath(self):
        """Test initialization with custom audit path."""
        customPath = Path("custom/AUDIT.md")
        gen = PhaseStatusGenerator(audit_path=customPath)
        assert gen.auditPath == customPath

class TestExtractPhaseInfo:
    """Test phase information extraction."""

    def testExtractsPhaseFromAudit(self):
        """Test extracting phase info from mock AUDIT.md."""
        with TemporaryDirectory() as tmpDir:
            auditFile = Path(tmpDir) / "AUDIT.md"
            auditFile.write_text(
                "# Audit Trail\n"
                "\n"
                "✅ **Phase 15.2**: Test Refactoring (Complete)\n"
                "✅ **Phase 15.1**: Analytics Platform (Complete)\n"
                "⏳ **Phase 16**: Next Phase (In Progress)\n",
                encoding="utf-8",
            )
            gen = PhaseStatusGenerator(audit_path=auditFile)
            phases = gen.extractPhaseInfo()
            assert len(phases) >= 2
            assert any(p["number"] == "15.2" for p in phases)
            assert any(p["number"] == "15.1" for p in phases)

    def testHandlesMissingFile(self):
        """Test handling missing AUDIT.md."""
        gen = PhaseStatusGenerator(audit_path=Path("nonexistent.md"))
        phases = gen.extractPhaseInfo()
        assert phases == []
        assert gen.stats["errors"] == 1

    def testExtractsPhaseStatus(self):
        """Test extracting phase status emoji."""
        with TemporaryDirectory() as tmpDir:
            auditFile = Path(tmpDir) / "AUDIT.md"
            auditFile.write_text(
                "✅ **Phase 1**: Complete\n"
                "⏳ **Phase 2**: In Progress\n"
                "❌ **Phase 3**: Not Started\n",
                encoding="utf-8",
            )
            gen = PhaseStatusGenerator(audit_path=auditFile)
            phases = gen.extractPhaseInfo()
            statuses = {p["number"]: p["status"] for p in phases}
            assert statuses.get("1") == "✅"
            assert statuses.get("2") == "⏳"
            assert statuses.get("3") == "❌"

class TestGenerateMarkdown:
    """Test Markdown generation."""

    def testGeneratesTableFormat(self):
        """Test that output is Markdown table format."""
        gen = PhaseStatusGenerator()
        phases = [
            {
                "number": "1",
                "title": "Foundation",
                "status": "✅",
                "details": "Complete",
            },
            {
                "number": "2",
                "title": "Integration",
                "status": "⏳",
                "details": "In Progress",
            },
        ]
        markdown = gen.generateMarkdown(phases)
        assert "| Phase | Title | Status | Details |" in markdown
        assert "| **1** | Foundation | ✅ |" in markdown
        assert "| **2** | Integration | ⏳ |" in markdown

    def testHandlesEmptyPhases(self):
        """Test handling empty phase list."""
        gen = PhaseStatusGenerator()
        markdown = gen.generateMarkdown([])
        assert markdown == ""

class TestGenerate:
    """Test full generation workflow."""

    def testGeneratesFile(self):
        """Test generating phase-status.md file."""
        with TemporaryDirectory() as tmpDir:
            auditFile = Path(tmpDir) / "AUDIT.md"
            outputFile = Path(tmpDir) / "phase-status.md"
            auditFile.write_text(
                "# Audit\n" "✅ **Phase 1**: Foundation (Complete)\n", encoding="utf-8"
            )
            gen = PhaseStatusGenerator(audit_path=auditFile)
            success = gen.generate(output_path=outputFile)
            assert success is True
            assert outputFile.exists()
            content = outputFile.read_text(encoding="utf-8")
            assert "# Phase Status" in content
            assert "Foundation" in content

    def testHandlesNoPhases(self):
        """Test when no phases found."""
        with TemporaryDirectory() as tmpDir:
            auditFile = Path(tmpDir) / "AUDIT.md"
            outputFile = Path(tmpDir) / "phase-status.md"
            auditFile.write_text("# Audit\nNo phases here\n", encoding="utf-8")
            gen = PhaseStatusGenerator(audit_path=auditFile)
            success = gen.generate(output_path=outputFile)
            # Should still write something (even if empty)
            assert isinstance(success, bool)
