# Scripts Improvement Analysis

**Audit of automation scripts applying improved orchestrator patterns.**

Date: 2026-09-02  
Scope: 30+ scripts across 8 modules

---

## Summary

| Category | Count | Status | Priority |
|----------|-------|--------|----------|
| **Analysis-first improvement** | 8 | ⚠️ Needs work | HIGH |
| **Viability assessment missing** | 12 | ⚠️ Needs work | MEDIUM |
| **Error handling weak** | 5 | ⚠️ Needs work | MEDIUM |
| **Infrastructure leverage** | 3 | ✅ Good | - |
| **Decision gates missing** | 15 | ⚠️ Needs work | LOW |

---

## Critical Issues (Fix First)

### 1. Config Validator: Unreachable Code Logic

**File**: `scripts/validate/config_validator.py` (lines 68-71)

```python
# ✗ WRONG: Unreachable return False statements
if not isinstance(config, dict):
    self.addError("agents.yaml should be a dictionary")
return False  # ← Always returns after error

if "agents" not in config and len(config) == 0:
    self.addError("agents.yaml should contain agents")
return False  # ← Unreachable
```

**Fix**:
```python
# ✓ CORRECT: Validate before returning
if not isinstance(config, dict):
    self.addError("agents.yaml should be a dictionary")
    return False
if not config or ("agents" not in config):
    self.addError("agents.yaml should contain agents")
    return False
# Continue validation...
```

**Impact**: Currently, validation passes even when it should fail

---

### 2. Sync/Validate Scripts: No Analysis Phase

**Files**: 
- `scripts/sync/syncDoc.py` (Phase 8 stub)
- `scripts/validate/owasp_audit.py`
- `scripts/validate/api_consistency.py`

**Problem**: Jump directly to validation without analyzing viability

**Pattern**:
```python
# ✗ WRONG
def validate_everything():
    check_all_configs()
    check_all_apis()
    check_all_docs()
    # No decision on what's important

# ✓ RIGHT
def analyze_then_validate():
    analysis = {
        "config_issues": count_config_issues(),
        "api_issues": count_api_issues(), 
        "doc_issues": count_doc_issues(),
    }
    # Only validate high-priority areas
    if analysis["config_issues"] > THRESHOLD:
        validate_configs()
```

**Effort**: Add `analyze_phase()` before validation

---

## High Priority Improvements

### 3. Audit Scripts: Missing Viability Assessment

**File**: `scripts/audit/testDuplicationAudit.py`

**Current**: Reports all findings equally

**Improve**:
```python
@dataclass
class FindingReport:
    # Current fields...
    is_actionable: bool  # ← Add this
    remediation_effort: int  # LOC to fix
    impact_if_ignored: str  # What breaks?
    recommended_action: str  # MUST FIX, SHOULD FIX, COULD FIX

def should_report_finding(finding: FindingReport) -> bool:
    """Only report actionable findings."""
    if not finding.is_actionable:
        return False
    if finding.remediation_effort > 500:  # Too expensive to fix
        return False
    return True
```

**Why**: Currently reports minor issues alongside critical ones—no prioritization

---

### 4. CLI Scripts: No Decision Gates

**Files**:
- `scripts/cli/interface.py`
- `scripts/cli/sync.py`
- `scripts/cli/profiling.py`

**Problem**: Execute commands without confirmation

**Add**:
```python
def execute_with_gate(self, action: str, analysis: dict) -> bool:
    """Execute only if decision gate passes."""
    print("\n" + "=" * 80)
    print(f"ACTION: {action}")
    print(f"Impact: {analysis['impact']}")
    print(f"Changes: {analysis['files_affected']} files")
    print("=" * 80)
    
    response = input("Proceed? (y/n): ")
    return response.lower() == 'y'
```

---

## Medium Priority Improvements

### 5. Error Handling Pattern

**Affected**: Most scripts

**Current**: Mix of exceptions, return codes, logging

**Standardize**:
```python
class ScriptError(Exception):
    """Base error for all scripts."""
    def __init__(self, message: str, remediation: str = ""):
        self.message = message
        self.remediation = remediation
    
    def report(self):
        print(f"ERROR: {self.message}")
        if self.remediation:
            print(f"FIX: {self.remediation}")

# Usage
try:
    validate_config()
except ScriptError as e:
    e.report()
    sys.exit(1)
```

---

### 6. Profiling Scripts: Missing Impact Metrics

**File**: `scripts/profiling/parametrization/measurement.py`

**Current**: Collects metrics, doesn't assess impact

**Add**:
```python
@dataclass
class ParametrizationMetrics:
    total_decorators: int
    duplicates: int
    estimated_deduplication_savings: int
    
    @property
    def is_worth_optimizing(self) -> bool:
        """Should we optimize parametrization?"""
        return (
            self.duplicates > 20 and  # Significant duplication
            self.estimated_deduplication_savings > 200  # Worth effort
        )
```

---

## Low Priority (Nice-to-Have)

### 7. Add Logging Standards

Standardize across all scripts:
```python
import logging

def setup_logging(verbose: bool = False):
    """Setup standard logging for all scripts."""
    level = logging.DEBUG if verbose else logging.INFO
    logging.basicConfig(
        format="%(timestamp)s | %(level)s | %(message)s",
        level=level
    )
```

### 8. Add Dry-Run Support

All scripts that modify files should support `--dry-run`:
```python
def should_apply_change(self, change: str) -> bool:
    if self.dry_run:
        self.log(f"[DRY RUN] Would {change}")
        return False
    return True
```

---

## Quick Wins (Easy, High Impact)

| Script | Issue | Fix | Effort | Impact |
|--------|-------|-----|--------|--------|
| config_validator.py | Unreachable code | Fix return logic | 15 min | CRITICAL |
| testDuplicationAudit.py | All findings equal priority | Add `is_actionable` flag | 30 min | HIGH |
| cli/interface.py | No confirmation | Add decision gate | 20 min | MEDIUM |
| profiling/measurement.py | No viability check | Add `is_worth_optimizing` | 20 min | MEDIUM |
| All scripts | Mixed error handling | Standardize to ScriptError | 1 hour | HIGH |

---

## Implementation Plan

### Phase 1: Critical Fixes (This Week)
1. Fix config_validator.py unreachable code
2. Standardize error handling (ScriptError class)
3. Add decision gates to CLI scripts

### Phase 2: Viability Assessment (Next Week)
4. Add viability checks to audit scripts
5. Improve profiling metrics
6. Add analysis phases to sync/validate

### Phase 3: Polish (Optional)
7. Standardize logging
8. Add dry-run support to all modification scripts
9. Create script template for future scripts

---

## Script-by-Script Recommendations

### Validation Module

| Script | Lines | Status | Recommendation |
|--------|-------|--------|-----------------|
| owasp_audit.py | 756 | ⚠️ No analysis | Add analysis phase, viability check |
| config_validator.py | 417 | 🔴 Critical bug | Fix unreachable code (lines 68-71) |
| checkConfigConsistency.py | 398 | ⚠️ No gates | Add decision gates before changes |
| checkDocLinks.py | 316 | ✅ Decent | Add impact metrics |
| api_consistency.py | 243 | ⚠️ No viability | Add viability assessment |

### Sync Module

| Script | Lines | Status | Recommendation |
|--------|-------|--------|-----------------|
| syncDoc.py | 594 | 📋 Phase 8 stub | Plan analysis + gates for Phase 8 |
| syncMobile.py | TBD | ? | Review when implementing |
| optimized.py | 253 | ⚠️ No metrics | Add impact measurement |

### CLI Module

| Script | Lines | Status | Recommendation |
|--------|-------|--------|-----------------|
| interface.py | 383 | ⚠️ No gates | Add user confirmation gates |
| profiling.py | 312 | ⚠️ Weak impact | Add viability check |
| base.py | 304 | ✅ Good structure | Use as template |
| sync.py | 262 | ⚠️ No analysis | Add analysis phase |

### Profiling Module

| Script | Lines | Status | Recommendation |
|--------|-------|--------|-----------------|
| parametrization_dashboard.py | ? | ? | Review and improve metrics |
| measurement.py | ? | ⚠️ No viability | Add is_worth_optimizing check |
| parametrization_weekly_report.py | ? | ? | Add decision context |

### Audit Module

| Script | Lines | Status | Recommendation |
|--------|-------|--------|-----------------|
| testDuplicationAudit.py | 268 | ⚠️ All findings equal | Add actionability check, prioritize |

---

## Template for Future Scripts

```python
#!/usr/bin/env python3
"""Script purpose and expected improvements."""

from dataclasses import dataclass
from enum import Enum
from pathlib import Path
import logging

logger = logging.getLogger(__name__)

@dataclass
class AnalysisResult:
    """Assessment of what script should do."""
    metric: str
    count: int
    is_viable: bool  # Should we proceed?
    recommendation: str
    estimated_impact: int  # LOC saved, time saved, etc.

class MyScript:
    """Template following improved patterns."""
    
    def __init__(self, verbose: bool = False, dry_run: bool = False):
        self.verbose = verbose
        self.dry_run = dry_run
        self.repo_root = Path(__file__).parents[2]
        self.analyses = []
    
    def analyze(self) -> bool:
        """Phase 1: Analyze before doing anything."""
        analysis = self._evaluate_targets()
        self.analyses.append(analysis)
        
        if not analysis.is_viable:
            logger.info(f"Not viable: {analysis.recommendation}")
            return False
        
        logger.info(f"Analysis found {analysis.count} {analysis.metric}")
        logger.info(f"Estimated impact: {analysis.estimated_impact}")
        return True
    
    def plan(self) -> bool:
        """Phase 2: Plan based on analysis."""
        viable = [a for a in self.analyses if a.is_viable]
        if not viable:
            return False
        
        logger.info(f"Plan: {len(viable)} improvements to make")
        return True
    
    def execute(self) -> bool:
        """Phase 3: Execute with gates."""
        if self.dry_run:
            logger.info("DRY RUN: Not making actual changes")
        
        # Implementation
        return True
    
    def verify(self) -> bool:
        """Phase 4: Verify changes."""
        # Validation
        return True
    
    def run(self):
        """Execute full script."""
        if not self.analyze():
            logger.info("Analysis blocked execution—no action needed")
            return
        
        if not self.plan():
            logger.info("Planning blocked execution")
            return
        
        if not self.execute():
            logger.error("Execution failed")
            return
        
        if not self.verify():
            logger.error("Verification failed")
            return
        
        logger.info("✓ Script completed successfully")
```

---

## Checklist for Script Improvements

- [ ] **Analysis phase** comes before automation
- [ ] **Viability assessment** with explicit thresholds
- [ ] **Impact metrics** documented (LOC, time, risk)
- [ ] **Decision gates** prevent unwanted changes
- [ ] **Dry-run support** for destructive operations
- [ ] **Error handling** uses consistent ScriptError
- [ ] **Logging** is clear and actionable
- [ ] **Recommendations** explain why/why-not proceeding

---

## References

- **Automation Patterns**: `docs/guides/operations/AUTOMATION_SCRIPT_PATTERNS.md`
- **Test Refactoring Closure**: `docs/work/completed/TEST_REFACTORING_PHASE1_CLOSURE.md`
- **Improved Orchestrator**: `scripts/test_refactor/orchestrate_refactor_improved.py`

---

*Analysis based on lessons learned from test refactoring effort. Apply these patterns to all future scripts.*
