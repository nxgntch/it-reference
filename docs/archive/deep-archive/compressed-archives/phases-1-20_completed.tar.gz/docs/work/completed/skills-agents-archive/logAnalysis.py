"""Log analysis skill for agents.
Research-focused pattern mining and hypothesis generation from logs.
Used by research manager to discover insights and patterns in system logs.
"""

from collections import Counter
from dataclasses import dataclass
from typing import Any, Dict, List, Optional


@dataclass
class DiscoveredPattern:
    """Pattern discovered in logs"""

    pattern_type: str  # temporal, error, performance, behavioral
    description: str
    frequency: int
    confidence: float  # 0-1
    affected_components: List[str]
    severity: str  # low, medium, high, critical


@dataclass
class Anomaly:
    """Detected anomaly in logs"""

    anomaly_type: str  # spike, drop, absence, unexpected_behavior
    description: str
    timestamp: str
    affected_metric: str
    severity: str  # low, medium, high, critical
    possible_causes: List[str]


class LogAnalysisSkill:
    """Analyze logs for patterns, anomalies, and insights."""

    def __init__(self, log_aggregator=None):
        """Initialize log analysis skill.
        Args:
           log_aggregator: LogAggregator instance for accessing logs
        """
        self.log_aggregator = log_aggregator

    def discoverPatterns(
        self,
        log_entries: List[Dict[str, Any]],
        lookback_hours: int = 24,
    ) -> List[DiscoveredPattern]:
        """Discover patterns in logs through analysis.
        Args:
           log_entries: Log entries to analyze
           lookback_hours: Hours of logs to analyze
        Returns:
           List of discovered patterns ranked by relevance
        """
        patterns: List[DiscoveredPattern] = []

        if not log_entries:
            return patterns

        # Extract error patterns
        error_logs = [l for l in log_entries if l.get("level") == "ERROR"]
        if error_logs:
            error_patterns = self._analyzeErrorPatterns(error_logs)
            patterns.extend(error_patterns)

        # Extract performance patterns
        perf_logs = [l for l in log_entries if l.get("latency_ms")]
        if perf_logs:
            perf_patterns = self._analyzePerformancePatterns(perf_logs)
            patterns.extend(perf_patterns)

        # Extract temporal patterns
        temporal_patterns = self._analyzeTemporalPatterns(log_entries)
        patterns.extend(temporal_patterns)

        # Extract behavioral patterns
        behavioral_patterns = self._analyzeBehavioralPatterns(log_entries)
        patterns.extend(behavioral_patterns)

        # Sort by confidence and frequency
        patterns.sort(key=lambda p: (p.confidence, p.frequency), reverse=True)

        return patterns

    def identifyAnomalies(
        self,
        log_entries: List[Dict[str, Any]],
        baseline_metrics: Optional[Dict[str, Any]] = None,
    ) -> List[Anomaly]:
        """Identify anomalies in log data.
        Args:
           log_entries: Log entries to analyze
           baseline_metrics: Optional baseline for comparison
        Returns:
           List of detected anomalies
        """
        anomalies: List[Anomaly] = []

        if not log_entries:
            return anomalies

        # Check for error spikes
        error_anomalies = self._detectErrorSpikes(log_entries, baseline_metrics)
        anomalies.extend(error_anomalies)

        # Check for performance degradation
        perf_anomalies = self._detectPerformanceDegradation(log_entries, baseline_metrics)
        anomalies.extend(perf_anomalies)

        # Check for absence anomalies (expected logs not present)
        absence_anomalies = self._detectAbsenceAnomalies(log_entries)
        anomalies.extend(absence_anomalies)

        # Check for unusual behavioral patterns
        behavior_anomalies = self._detectBehavioralAnomalies(log_entries)
        anomalies.extend(behavior_anomalies)

        # Sort by severity
        severity_order = {"critical": 0, "high": 1, "medium": 2, "low": 3}
        anomalies.sort(key=lambda a: severity_order.get(a.severity, 999))

        return anomalies

    def generateHypotheses(
        self,
        patterns: List[DiscoveredPattern],
        anomalies: List[Anomaly],
        domain_knowledge: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Generate research hypotheses from patterns and anomalies.
        Args:
           patterns: Discovered patterns
           anomalies: Detected anomalies
           domain_knowledge: Optional domain context
        Returns:
           Dict with hypotheses, evidence, and research directions
        """
        hypotheses = []

        # Generate hypotheses from patterns
        for pattern in patterns[:5]:  # Top 5 patterns
            hypothesis = {
                "hypothesis": self._formulateHypothesis(pattern),
                "evidence": [
                    f"Pattern '{pattern.pattern_type}' detected with {pattern.frequency} occurrences",
                    f"Confidence: {pattern.confidence * 100:.1f}%",
                    f"Affected: {', '.join(pattern.affected_components)}",
                ],
                "research_direction": self._suggestResearchDirection(pattern),
                "priority": "high" if pattern.confidence > 0.8 else "medium",
            }
            hypotheses.append(hypothesis)

        # Generate hypotheses from anomalies
        for anomaly in anomalies[:3]:  # Top 3 anomalies
            hypothesis = {
                "hypothesis": f"{anomaly.description} is due to: {' or '.join(anomaly.possible_causes)}",
                "evidence": [
                    f"Anomaly type: {anomaly.anomaly_type}",
                    f"Metric affected: {anomaly.affected_metric}",
                    f"Timestamp: {anomaly.timestamp}",
                ],
                "research_direction": f"Investigate root cause of {anomaly.anomaly_type}",
                "priority": "high" if anomaly.severity in ["critical", "high"] else "medium",
            }
            hypotheses.append(hypothesis)

        return {
            "hypotheses": hypotheses,
            "total_patterns_found": len(patterns),
            "total_anomalies_found": len(anomalies),
            "high_priority_hypotheses": len([h for h in hypotheses if h["priority"] == "high"]),
            "next_steps": self._suggestNextSteps(patterns, anomalies),
        }

    def _analyzeErrorPatterns(self, error_logs: List[Dict[str, Any]]) -> List[DiscoveredPattern]:
        """Analyze error patterns in logs.
        Returns:
           List of error patterns
        """
        patterns = []
        # Count error types
        error_types = Counter(l.get("error_type") for l in error_logs if l.get("error_type"))
        for error_type, count in error_types.most_common(3):
            affected = [
                c
                for c in {
                    l.get("component") for l in error_logs if l.get("error_type") == error_type
                }
                if c
            ]
            patterns.append(
                DiscoveredPattern(
                    pattern_type="error",
                    description=f"Recurring error: {error_type}",
                    frequency=count,
                    confidence=min(0.95, 0.5 + (count / 100)),
                    affected_components=affected,
                    severity="high" if count > 10 else "medium",
                )
            )
        return patterns

    def _analyzePerformancePatterns(
        self, perf_logs: List[Dict[str, Any]]
    ) -> List[DiscoveredPattern]:
        """Analyze performance patterns.
        Returns:
           List of performance patterns
        """
        patterns = []
        latencies = [l.get("latency_ms", 0) for l in perf_logs if l.get("latency_ms")]
        if latencies:
            avg_latency = sum(latencies) / len(latencies)
            slow_count = len([l for l in latencies if l > avg_latency * 2])
            if slow_count > 0:
                components = [
                    c
                    for c in {
                        l.get("component")
                        for l in perf_logs
                        if l.get("latency_ms", 0) > avg_latency * 2
                    }
                    if c
                ]
                patterns.append(
                    DiscoveredPattern(
                        pattern_type="performance",
                        description=f"Latency spikes detected ({slow_count} instances >2x avg)",
                        frequency=slow_count,
                        confidence=0.8,
                        affected_components=components,
                        severity="high" if slow_count > 5 else "medium",
                    )
                )
        return patterns

    def _analyzeTemporalPatterns(
        self, log_entries: List[Dict[str, Any]]
    ) -> List[DiscoveredPattern]:
        """Analyze temporal patterns (time-based).
        Returns:
           List of temporal patterns
        """
        patterns = []
        # Extract hours and count
        hours: Counter = Counter()
        for log in log_entries:
            if log.get("timestamp"):
                try:
                    hour = int(log["timestamp"].split("T")[1].split(":")[0])
                    hours[hour] += 1
                except (IndexError, ValueError):
                    pass
        if hours:
            peak_hour, peak_count = hours.most_common(1)[0]
            if peak_count > len(log_entries) * 0.3:
                patterns.append(
                    DiscoveredPattern(
                        pattern_type="temporal",
                        description=f"Activity peak during hour {peak_hour}:00-{peak_hour}:59",
                        frequency=peak_count,
                        confidence=0.75,
                        affected_components=["system-wide"],
                        severity="low",
                    )
                )
        return patterns

    def _analyzeBehavioralPatterns(
        self, log_entries: List[Dict[str, Any]]
    ) -> List[DiscoveredPattern]:
        """Analyze behavioral patterns (user/system behavior).
        Returns:
           List of behavioral patterns
        """
        patterns = []
        # Count actions
        actions = Counter(l.get("action") for l in log_entries if l.get("action"))
        for action, count in actions.most_common(3):
            if count > 5:
                patterns.append(
                    DiscoveredPattern(
                        pattern_type="behavioral",
                        description=f"Frequent action: {action}",
                        frequency=count,
                        confidence=0.7,
                        affected_components=["behavioral"],
                        severity="low",
                    )
                )
        return patterns

    def _detectErrorSpikes(
        self,
        log_entries: List[Dict[str, Any]],
        baseline_metrics: Optional[Dict[str, Any]] = None,
    ) -> List[Anomaly]:
        """Detect spikes in error rate.
        Returns:
           List of error spike anomalies
        """
        anomalies: List[Anomaly] = []

        error_logs = [l for l in log_entries if l.get("level") == "ERROR"]
        total_logs = len(log_entries)

        if total_logs == 0:
            return anomalies

        error_rate = len(error_logs) / total_logs

        # Use baseline if available, else assume <1% is normal
        baseline_error_rate = baseline_metrics.get("error_rate", 0.01) if baseline_metrics else 0.01
        spike_threshold = baseline_error_rate * 5

        if error_rate > spike_threshold:
            anomalies.append(
                Anomaly(
                    anomaly_type="spike",
                    description=f"Error rate spike: {error_rate * 100:.1f}% (baseline: {baseline_error_rate * 100:.1f}%)",
                    timestamp=log_entries[0].get("timestamp", "unknown"),
                    affected_metric="error_rate",
                    severity="critical" if error_rate > spike_threshold * 2 else "high",
                    possible_causes=[
                        "System degradation",
                        "Configuration issue",
                        "Upstream service failure",
                    ],
                )
            )

        return anomalies

    def _detectPerformanceDegradation(
        self,
        log_entries: List[Dict[str, Any]],
        baseline_metrics: Optional[Dict[str, Any]] = None,
    ) -> List[Anomaly]:
        """Detect performance degradation.
        Returns:
           List of performance anomalies
        """
        anomalies: List[Anomaly] = []

        perf_logs = [l for l in log_entries if l.get("latency_ms")]
        if not perf_logs:
            return anomalies

        latencies = [float(l.get("latency_ms", 0)) for l in perf_logs if l.get("latency_ms")]
        if not latencies:
            return anomalies
        avg_latency = sum(latencies) / len(latencies)

        baseline_latency = baseline_metrics.get("latency_p95", 200) if baseline_metrics else 200
        degradation_threshold = baseline_latency * 1.5

        if avg_latency > degradation_threshold:
            anomalies.append(
                Anomaly(
                    anomaly_type="spike",
                    description=f"Latency degradation: {avg_latency:.0f}ms (baseline: {baseline_latency}ms)",
                    timestamp=perf_logs[0].get("timestamp", "unknown"),
                    affected_metric="latency_ms",
                    severity="high" if avg_latency > degradation_threshold * 1.5 else "medium",
                    possible_causes=[
                        "Resource contention",
                        "Database slowdown",
                        "Network issues",
                    ],
                )
            )

        return anomalies

    def _detectAbsenceAnomalies(self, log_entries: List[Dict[str, Any]]) -> List[Anomaly]:
        """Detect absence anomalies (missing expected logs).
        Returns:
           List of absence anomalies
        """
        anomalies: List[Anomaly] = []
        # Check if health checks are missing (expected every 5 min)
        health_checks = [l for l in log_entries if l.get("action") == "health_check"]
        if not health_checks and len(log_entries) > 10:
            anomalies.append(
                Anomaly(
                    anomaly_type="absence",
                    description="No health check logs detected",
                    timestamp=log_entries[-1].get("timestamp", "unknown"),
                    affected_metric="health_checks",
                    severity="high",
                    possible_causes=[
                        "Health check system offline",
                        "Logging disabled",
                        "Service down",
                    ],
                )
            )
        return anomalies

    def _detectBehavioralAnomalies(self, log_entries: List[Dict[str, Any]]) -> List[Anomaly]:
        """Detect unusual behavioral patterns.
        Returns:
           List of behavioral anomalies
        """
        anomalies: List[Anomaly] = []
        # Count failed attempts by agent
        failed_actions: Counter = Counter()
        for log in log_entries:
            if log.get("status") == "failed" and log.get("agent_id"):
                failed_actions[log["agent_id"]] += 1
        for agent_id, fail_count in failed_actions.most_common(3):
            if fail_count > 3:
                anomalies.append(
                    Anomaly(
                        anomaly_type="unexpected_behavior",
                        description=f"Agent {agent_id} has {fail_count} failures",
                        timestamp=log_entries[-1].get("timestamp", "unknown"),
                        affected_metric="agent_failures",
                        severity="medium",
                        possible_causes=[
                            "Agent misconfiguration",
                            "Invalid input",
                            "Dependency unavailable",
                        ],
                    )
                )
        return anomalies

    def _formulateHypothesis(self, pattern: DiscoveredPattern) -> str:
        """Formulate hypothesis from pattern.
        Returns:
           Hypothesis statement
        """
        if pattern.pattern_type == "error":
            return f"The system experiences recurring {pattern.description}"
        if pattern.pattern_type == "performance":
            return f"Performance degrades due to {pattern.description}"
        if pattern.pattern_type == "temporal":
            return f"There are temporal factors affecting system behavior: {pattern.description}"
        return f"The system exhibits: {pattern.description}"

    def _suggestResearchDirection(self, pattern: DiscoveredPattern) -> str:
        """Suggest research direction.
        Returns:
           Research direction
        """
        if pattern.pattern_type == "error":
            return f"Investigate root causes of {pattern.description} in {pattern.affected_components[0] if pattern.affected_components else 'system'}"
        if pattern.pattern_type == "performance":
            return f"Profile {pattern.affected_components[0] if pattern.affected_components else 'system'} to identify optimization opportunities"
        return f"Further analyze {pattern.pattern_type} patterns for insights"

    def _suggestNextSteps(
        self,
        patterns: List[DiscoveredPattern],
        anomalies: List[Anomaly],
    ) -> List[str]:
        """Suggest next research steps.
        Returns:
           List of suggested next steps
        """
        steps = []

        if patterns:
            top_pattern = patterns[0]
            steps.append(
                f"Deep-dive analysis of {top_pattern.pattern_type}: {top_pattern.description}"
            )

        if anomalies:
            top_anomaly = anomalies[0]
            steps.append(f"Investigate root cause: {top_anomaly.description}")

        steps.append("Correlate patterns with system events and deployments")
        steps.append("Generate detailed report for stakeholders")

        return steps


def logAnalysis(log_aggregator=None) -> LogAnalysisSkill:
    """Factory function for dependency injection.
    Usage in any agent:
       from skills.agents.logAnalysis import logAnalysis
       skill = logAnalysis(log_aggregator)
       patterns = skill.discoverPatterns(logs)
    """
    return LogAnalysisSkill(log_aggregator=log_aggregator)
