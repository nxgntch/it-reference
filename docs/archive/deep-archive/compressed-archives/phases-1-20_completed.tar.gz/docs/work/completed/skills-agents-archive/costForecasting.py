"""Cost forecasting skill for agents.
CONSOLIDATION NOTE (Phase 2 Cleanup):
This module now delegates to app.analytics.costForecaster for unified cost forecasting logic.
Eliminates ~100 LOC of duplicate forecasting calculations across multiple skill modules.
Predict future costs and budget exhaustion based on current spending patterns.
Used by research and operations managers to plan work.
"""

from typing import Any, Dict, Optional

from app.analytics.costForecaster import (
    CostForecast,
)
from app.analytics.costForecaster import (
    CostForecasterSkill as AnalyticsCostForecaster,
)


class CostForecastingSkill:
    """Forecast costs and budget trajectories.
    Wraps the unified cost forecasting analytics module (app.analytics.costForecaster)
    to provide backward-compatible interface for agent skills.
    """

    def __init__(self, dashboard_registry=None, cost_tracker=None):
        """Initialize cost forecasting skill.
        Args:
           dashboard_registry: DashboardRegistry instance for cost metrics
           cost_tracker: CostTracker for historical spending data
        """
        self.registry = dashboard_registry
        self.cost_tracker = cost_tracker
        # Delegate to analytics module for actual forecasting
        self._analytics = AnalyticsCostForecaster(cost_tracker)

    def forecastMonthlySpend(
        self,
        current_spend: float,
        monthly_budget: float,
        days_elapsed: int,
        historical_daily_spend: Optional[list] = None,
    ) -> CostForecast:
        """Forecast monthly spend based on current trajectory.
        Delegates to app.analytics.costForecaster for unified logic.
        Args:
           current_spend: Amount spent so far this month
           monthly_budget: Total monthly budget
           days_elapsed: Days elapsed in month
           historical_daily_spend: Optional list of daily spend amounts (last 30 days)
        Returns:
           CostForecast with prediction and recommendation
        """
        # Use analytics module for forecasting (SSOT)
        return self._analytics.forecastMonthlySpend(
            current_spend=current_spend,
            monthly_budget=monthly_budget,
            days_elapsed=days_elapsed,
            daily_history=historical_daily_spend,
        )

    def recommendBudgetAllocation(
        self,
        total_budget: float,
        team_spending: Dict[str, float],
        team_projects: Dict[str, list],
    ) -> Dict[str, Any]:
        """Recommend budget allocation across teams.
        Args:
           total_budget: Total organization budget
           team_spending: Current spend by team
           team_projects: Active projects by team
        Returns:
           Allocation recommendation with rationale
        """
        allocations = {}
        rationale = {}

        # Calculate proportional allocation based on project count and spend
        sum(len(projects) for projects in team_projects.values())

        for team, current_spend in team_spending.items():
            project_count = len(team_projects.get(team, []))

            # Allocate based on current activity and historical spend
            allocation = (
                (current_spend / sum(team_spending.values())) * total_budget
                if sum(team_spending.values()) > 0
                else total_budget / len(team_spending)
            )

            allocations[team] = allocation
            rationale[team] = f"{project_count} active projects, ${current_spend:.2f} current spend"

        return {
            "allocations": allocations,
            "rationale": rationale,
            "total_allocated": sum(allocations.values()),
            "recommendation": "Rebalance if any team significantly overallocated",
        }

    def identifySpendAnomalies(
        self,
        daily_spend_history: list,
        threshold_std_dev: float = 2.0,
    ) -> Dict[str, Any]:
        """Identify unusual spending patterns.
        Args:
           daily_spend_history: List of daily spend amounts (last 30 days)
           threshold_std_dev: Standard deviations above mean = anomaly
        Returns:
           Anomalies found with dates and severity
        """
        if len(daily_spend_history) < 3:
            return {"anomalies": [], "message": "Insufficient data"}

        # Calculate statistics
        mean_spend = sum(daily_spend_history) / len(daily_spend_history)
        variance = sum((x - mean_spend) ** 2 for x in daily_spend_history) / len(
            daily_spend_history
        )
        std_dev = variance**0.5

        # Find anomalies
        anomalies = []
        for i, spend in enumerate(daily_spend_history):
            z_score = (spend - mean_spend) / std_dev if std_dev > 0 else 0
            if z_score > threshold_std_dev:
                anomalies.append(
                    {
                        "day": i,
                        "spend": spend,
                        "z_score": z_score,
                        "severity": "high" if z_score > 3 else "medium",
                    }
                )

        return {
            "anomalies": anomalies,
            "mean_daily_spend": mean_spend,
            "std_dev": std_dev,
            "count": len(anomalies),
            "recommendation": "Investigate high-cost anomalies for efficiency gains",
        }

    def _calculateTrend(self, historical_daily_spend: list) -> str:
        """Calculate spending trend from history.
        Args:
           historical_daily_spend: List of daily spend amounts
        Returns:
           Trend direction (increasing, decreasing, stable)
        """
        if len(historical_daily_spend) < 3:
            return "stable"
        first_half_avg = sum(historical_daily_spend[: len(historical_daily_spend) // 2]) / (
            len(historical_daily_spend) // 2
        )
        second_half_avg = sum(historical_daily_spend[len(historical_daily_spend) // 2 :]) / (
            len(historical_daily_spend) - len(historical_daily_spend) // 2
        )
        change_percent = (
            (second_half_avg - first_half_avg) / first_half_avg if first_half_avg > 0 else 0
        )
        if change_percent > 0.1:
            return "increasing"
        elif change_percent < -0.1:
            return "decreasing"
        else:
            return "stable"

    def _generateRecommendation(
        self,
        budget_status: str,
        trend: str,
        days_until_exhausted: Optional[int],
        percent_used: float,
    ) -> str:
        """Generate recommendation based on forecast.
        Args:
           budget_status: Current budget status
           trend: Spending trend
           days_until_exhausted: Days until budget exhausted
           percent_used: Percentage of budget used
        Returns:
           Recommendation string
        """
        if budget_status == "exceeded":
            return "URGENT: Budget exceeded. Stop non-critical work immediately."

        if budget_status == "critical":
            return f"CRITICAL: {percent_used:.0f}% of budget used. Only {days_until_exhausted} days remaining. Halt expensive work."

        if budget_status == "warning":
            if trend == "increasing":
                return f"WARNING: {percent_used:.0f}% used with increasing trend. Reduce spending in next {days_until_exhausted} days."
            else:
                return f"WARNING: {percent_used:.0f}% used. Monitor closely."

        if trend == "increasing":
            return "Spending trending upward. Consider cost optimization measures."

        return "Budget status healthy. Proceed with planned work."


def costForecasting(dashboard_registry=None, cost_tracker=None) -> CostForecastingSkill:
    """Factory function for dependency injection.
    Usage in any agent:
       from skills.agents.costForecasting import costForecasting
       skill = costForecasting(dashboard_registry, cost_tracker)
       forecast = skill.forecastMonthlySpend(...)
    """
    return CostForecastingSkill(
        dashboard_registry=dashboard_registry,
        cost_tracker=cost_tracker,
    )
