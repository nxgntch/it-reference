# TASK 2: Prepare Shared Folder & Zoom Links (30 minutes)

**Status**: ⏱️ IN PROGRESS
**Time Estimate**: 30 minutes total
**Owner**: You (Christian Salvador)
**Deadline**: Complete before sending emails

---

## 📋 TASK 2 BREAKDOWN

### **Step 2a: Create Shared Folder** (10 min)

**Where**: Google Drive OR Notion (your choice)

#### **Option A: Google Drive**

1. [ ] Open Google Drive (drive.google.com)
2. [ ] Click **"+ New"** → **"Folder"**
3. [ ] Name it: **`Phase 12 - Planning & Execution (Feb 11 - May 5)`**
4. [ ] Right-click folder → **"Share"**
5. [ ] Set permissions: **"Viewer"** (view only, no edit)
6. [ ] Get shareable link:
   - Click **"Share"** button (top right)
   - Copy link under "Anyone with the link"
   - **SAVE THIS LINK** ← You'll need it for emails

**Your Google Drive Link**: ___________________________________________________________

#### **Option B: Notion**

1. [ ] Open Notion (notion.so)
2. [ ] Create new page: **"Phase 12 - Planning & Execution"**
3. [ ] Add description: "Planning documents Feb 11 - May 5, 2027"
4. [ ] Click **"Share"** (top right)
5. [ ] Set to **"Anyone with link can view"**
6. [ ] Copy shareable link
7. [ ] **SAVE THIS LINK** ← You'll need it for emails

**Your Notion Link**: ___________________________________________________________

---

### **Step 2b: Upload 8 Planning Documents** (10 min)

**Documents to upload** (copy from your local `docs/work/` folder):

1. [ ] PHASE_12_COMBINED_ROADMAP.md
2. [ ] PHASE_12A_DETAILED_EXECUTION.md
3. [ ] PHASE_12B_DETAILED_EXECUTION.md
4. [ ] MASTER_TIMELINE_FEB_TO_MAY_2027.md
5. [ ] V1_5_0_RELEASE_PLAN.md
6. [ ] PHASE_12_KICKOFF_AGENDA.md
7. [ ] PHASE_12_EXECUTION_TRACKER.md
8. [ ] IMMEDIATE_ACTION_ITEMS_FEB_11_28.md

**How to upload**:
- [ ] Open your Phase 12 folder in Google Drive / Notion
- [ ] Drag and drop all 8 files into folder
- [ ] OR click "Upload" and select files
- [ ] Wait for upload to complete

**Verification** (IMPORTANT):
- [ ] Open the shared folder link in a private/incognito window
- [ ] Can you see all 8 documents?
- [ ] Can you open and read each file?
- [ ] If NO, check permissions (should be "Viewer")

---

### **Step 2c: Create 5 Zoom Meetings** (10 min)

**Meeting 1: Planning Refinement Meeting**

1. [ ] Go to Zoom (zoom.us) → Sign in
2. [ ] Click **"Schedule a Meeting"**
3. [ ] Fill in:
   - [ ] Topic: **Phase 12 Planning Refinement**
   - [ ] Date: **Thursday, February 14, 2027**
   - [ ] Time: **10:00 AM UTC**
   - [ ] Duration: **1 hour**
   - [ ] Recurring: **No**
   - [ ] Video: Host & Participants **ON**
   - [ ] Meeting ID: Auto-generate
4. [ ] Click **"Save"**
5. [ ] Copy Zoom link and save below:

**Zoom Link (Thu Planning Meeting)**: ___________________________________________________________

---

**Meeting 2: Phase 12A - Performance Engineer 1-on-1 (Marcus ↔ Elena)**

1. [ ] Click **"Schedule a Meeting"** again
2. [ ] Fill in:
   - [ ] Topic: **Phase 12A: Performance Engineer 1-on-1**
   - [ ] Date: **Friday, February 15, 2027**
   - [ ] Time: **10:30 AM UTC**
   - [ ] Duration: **30 minutes**
   - [ ] Video: Host & Participants **ON**
3. [ ] Click **"Save"**
4. [ ] Copy Zoom link:

**Zoom Link (Fri 10:30 AM - Marcus ↔ Elena)**: ___________________________________________________________

---

**Meeting 3: Phase 12A - QA Engineer 1-on-1 (Marcus ↔ James)**

1. [ ] Click **"Schedule a Meeting"** again
2. [ ] Fill in:
   - [ ] Topic: **Phase 12A: QA Engineer 1-on-1**
   - [ ] Date: **Friday, February 15, 2027**
   - [ ] Time: **11:00 AM UTC**
   - [ ] Duration: **30 minutes**
   - [ ] Video: Host & Participants **ON**
3. [ ] Click **"Save"**
4. [ ] Copy Zoom link:

**Zoom Link (Fri 11:00 AM - Marcus ↔ James)**: ___________________________________________________________

---

**Meeting 4: Phase 12B - Backend Engineer 1-on-1 (David ↔ Aisha)**

1. [ ] Click **"Schedule a Meeting"** again
2. [ ] Fill in:
   - [ ] Topic: **Phase 12B: Backend Engineer 1-on-1**
   - [ ] Date: **Friday, February 15, 2027**
   - [ ] Time: **2:00 PM UTC**
   - [ ] Duration: **30 minutes**
   - [ ] Video: Host & Participants **ON**
3. [ ] Click **"Save"**
4. [ ] Copy Zoom link:

**Zoom Link (Fri 2:00 PM - David ↔ Aisha)**: ___________________________________________________________

---

**Meeting 5: Phase 12B - QA Engineer 1-on-1 (David ↔ James)**

1. [ ] Click **"Schedule a Meeting"** again
2. [ ] Fill in:
   - [ ] Topic: **Phase 12B: QA Engineer 1-on-1**
   - [ ] Date: **Friday, February 15, 2027**
   - [ ] Time: **2:30 PM UTC**
   - [ ] Duration: **30 minutes**
   - [ ] Video: Host & Participants **ON**
3. [ ] Click **"Save"**
4. [ ] Copy Zoom link:

**Zoom Link (Fri 2:30 PM - David ↔ James)**: ___________________________________________________________

---

## ✅ VERIFICATION CHECKLIST

Before moving to Task 3, verify:

### **Folder Check**
- [ ] Shared folder created in Google Drive or Notion
- [ ] Folder name: "Phase 12 - Planning & Execution (Feb 11 - May 5)"
- [ ] All 8 documents uploaded
- [ ] Permissions set to "Viewer" (view only)
- [ ] Test: Opened link in private window, can see all docs? ✅

### **Zoom Meetings Check**
- [ ] Meeting 1 (Thu): Planning Refinement - 10 AM UTC
- [ ] Meeting 2 (Fri): Marcus ↔ Elena - 10:30 AM UTC
- [ ] Meeting 3 (Fri): Marcus ↔ James - 11:00 AM UTC
- [ ] Meeting 4 (Fri): David ↔ Aisha - 2:00 PM UTC
- [ ] Meeting 5 (Fri): David ↔ James - 2:30 PM UTC
- [ ] All 5 Zoom links copied and saved above? ✅

### **Links Saved**
- [ ] Shared folder link saved above ✅
- [ ] All 5 Zoom links saved above ✅

---

## 📝 COPY YOUR LINKS HERE

**Shared Folder Link** (for email):
```
[PASTE HERE]
```

**Zoom Links** (for calendar invites):
```
Thu Feb 14 @ 10:00 AM UTC - Planning Refinement:
[PASTE HERE]

Fri Feb 15 @ 10:30 AM UTC - Marcus ↔ Elena:
[PASTE HERE]

Fri Feb 15 @ 11:00 AM UTC - Marcus ↔ James:
[PASTE HERE]

Fri Feb 15 @ 2:00 PM UTC - David ↔ Aisha:
[PASTE HERE]

Fri Feb 15 @ 2:30 PM UTC - David ↔ James:
[PASTE HERE]
```

---

## 🎯 WHAT'S NEXT

✅ **Task 1**: Create 6 team profiles (DONE)
⏳ **Task 2**: Prepare shared folder & Zoom links (IN PROGRESS - YOU ARE HERE)
📧 **Task 3**: Prepare email templates
💬 **Task 4**: Create Slack channel
📅 **Task 5**: Send calendar invites

---

## ⏱️ Timer: 30 minutes

**Start now**:
1. Create folder in Google Drive/Notion
2. Upload 8 documents
3. Create 5 Zoom meetings
4. Save all links in the section above

When done, reply with **"Done with Task 2"** and I'll guide you through Task 3 (Prepare Email Templates).

Go! 🚀
