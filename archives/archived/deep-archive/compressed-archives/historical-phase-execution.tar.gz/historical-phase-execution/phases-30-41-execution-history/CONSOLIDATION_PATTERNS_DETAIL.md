# Consolidation Patterns - Technical Deep Dive

**Analysis Date**: 2026-09-03
**Focus**: Specific code patterns duplicated across modules

---

## Pattern 1: Batch Processing - Duplicate Statistics Tracking

### Current Duplication

**Files**:
- `app/core/batchStats.py` - Basic stat tracking
- `app/core/batchAnalyzer.py` - Analysis with embedded stats
- `app/core/batchProcessor.py` - Processor with stats collection
- `app/core/statsCollector.py` - Shared stats (partial consolidation exists)

### Duplicate Code Example

Each file implements similar metric collection:
```python
# In batchStats.py (208 LOC)
class BatchStatsMixin:
    def __init__(self):
        self.successful_count = 0
        self.failed_count = 0
        self.total_cost = 0.0
        self.execution_time = 0.0

    def update_stats(self, successful: bool, cost: float, time: float):
        if successful:
            self.successful_count += 1
        else:
            self.failed_count += 1
        self.total_cost += cost
        self.execution_time += time

# In batchAnalyzer.py (similar logic, 185 LOC)
class BatchAnalyzer:
    def __init__(self):
        self.metrics = {
            'successful': 0,
            'failed': 0,
            'total_cost': 0.0,
            'time': 0.0
        }

    def track_metrics(self, status, cost, duration):
        if status == 'success':
            self.metrics['successful'] += 1
        # ... similar tracking
```

### Impact
- **Duplication**: 100+ LOC of identical metric tracking
- **Bugs**: If one changes, others may diverge
- **Testing**: Same logic tested in 3+ places

### Solution
Create single `BatchMetricsCollector` class, use via composition:
```python
class BatchMetricsCollector:
    """Single source of truth for batch metrics."""
    successful_count: int = 0
    failed_count: int = 0
    total_cost: float = 0.0
    execution_time: float = 0.0

    def record_execution(self, status: str, cost: float, duration: float):
        if status == 'success':
            self.successful_count += 1
        else:
            self.failed_count += 1
        self.total_cost += cost
        self.execution_time += duration

# Used in all batch modules
class BatchProcessor:
    def __init__(self):
        self.metrics = BatchMetricsCollector()
```

**Expected Savings**: 80-100 LOC, single test suite

---

## Pattern 2: Analytics - Duplicate Statistical Calculations

### Current Duplication

**Files**:
- `app/analytics/base.py` - Base statistical utilities (251 LOC)
- `app/analytics/performanceTrendAnalyzer.py` - Duplicates mean/stdev (309 LOC)
- `app/analytics/costForecaster.py` - Duplicates forecasting logic (311 LOC)
- `app/analytics/metricsAlerts.py` - Duplicates threshold detection (281 LOC)

### Duplicate Code Example

```python
# In base.py
class BaseAnalytics:
    @staticmethod
    def calculateMean(data: List[float]) -> float:
        return statistics.mean(data) if data else 0

    @staticmethod
    def calculateStdev(data: List[float]) -> float:
        return statistics.stdev(data) if len(data) > 1 else 0

# In performanceTrendAnalyzer.py (reimplemented)
def _calculate_average(values):
    if not values:
        return 0
    return sum(values) / len(values)

# In costForecaster.py (reimplemented again)
def get_average_cost(costs):
    return sum(costs) / len(costs) if costs else 0

# In metricsAlerts.py (yet another implementation)
def compute_mean(data):
    return statistics.mean(data) if data else 0
```

### Additional Pattern: Forecast Calculation

```python
# In costForecaster.py (311 LOC with ~80 LOC for forecasting)
def forecast_monthly_cost(self, daily_costs):
    mean_daily = self.calculateMean(daily_costs)
    stdev_daily = self.calculateStdev(daily_costs)
    # Forecast logic...
    return forecast

# In performanceTrendAnalyzer.py (similar pattern, 309 LOC)
def trend_analysis(self, performance_metrics):
    mean = statistics.mean(performance_metrics)
    stdev = statistics.stdev(performance_metrics)
    # Similar trend calculation...
    return trend
```

### Impact
- **Duplication**: 120-150 LOC of statistical calculations
- **Inconsistency**: Different implementations (sum/len vs statistics module)
- **Maintenance**: Bug fixes needed in multiple places

### Solution
Consolidate statistical library + create domain-specific analyzers:

```python
# Unified statistics
class AnalyticsUtilities:
    """Core statistical operations - single source of truth."""
    @staticmethod
    def mean(data: List[float]) -> float:
        return statistics.mean(data) if data else 0

    @staticmethod
    def stdev(data: List[float]) -> float:
        return statistics.stdev(data) if len(data) > 1 else 0

    @staticmethod
    def forecast_linear_trend(values: List[float]) -> float:
        """Unified forecasting using linear regression."""
        # Implementation once, used everywhere

# Domain analyzers inherit and reuse
class CostForecaster(AnalyticsUtilities):
    def forecast_monthly(self, daily_costs: List[float]):
        mean = self.mean(daily_costs)
        trend = self.forecast_linear_trend(daily_costs)
        return mean * 30 + trend
```

**Expected Savings**: 150-200 LOC, improved consistency

---

## Pattern 3: Configuration - Duplicate Caching Logic

### Current Duplication

**Files**:
- `app/core/configCache.py` - Generic config cache (265 LOC)
- `app/core/agentConfigCache.py` - Specialized agent config cache (305 LOC)
- `app/core/responseCache.py` - Response caching (242 LOC)
- `app/core/cacheBase.py` - Old cache base class (174 LOC)

### Duplicate Code Example

```python
# In configCache.py
class ConfigCache:
    def __init__(self, ttl=3600):
        self.cache = {}
        self.ttl = ttl
        self.last_update = {}

    def get(self, key):
        if key in self.cache:
            if time.time() - self.last_update[key] < self.ttl:
                return self.cache[key]
            else:
                del self.cache[key]
        return None

    def set(self, key, value):
        self.cache[key] = value
        self.last_update[key] = time.time()

# In agentConfigCache.py (identical logic with different data structure)
class AgentConfigCache:
    def __init__(self, ttl=3600):
        self.agent_configs = {}
        self.cache_times = {}
        self.ttl = ttl

    def get_config(self, agent_id):
        if agent_id in self.agent_configs:
            if time.time() - self.cache_times[agent_id] < self.ttl:
                return self.agent_configs[agent_id]
        return None

    def set_config(self, agent_id, config):
        self.agent_configs[agent_id] = config
        self.cache_times[agent_id] = time.time()

# In responseCache.py (identical pattern again)
class ResponseCache:
    def __init__(self, ttl=3600):
        self.responses = {}
        self.timestamps = {}
        self.ttl = ttl
```

### Impact
- **Duplication**: 180-200 LOC of identical cache logic
- **Inconsistency**: Slightly different interfaces (get vs get_config vs cached_get)
- **Bug risk**: TTL logic may diverge

### Solution
Use existing `cacheFramework` - consolidate under unified interface:

```python
# Already exists but underutilized
from app.core.cacheFramework import UnifiedCache, EvictionStrategy

# Single cache implementation
config_cache = UnifiedCache[dict](ttl=3600)
agent_cache = UnifiedCache[AgentConfig](ttl=3600)
response_cache = UnifiedCache[dict](ttl=3600)

# Replace all three modules with factory:
def get_cache(cache_type: str) -> UnifiedCache:
    ttl_map = {
        'config': 3600,
        'agent': 3600,
        'response': 1800
    }
    return UnifiedCache(ttl=ttl_map[cache_type])
```

**Expected Savings**: 500-600 LOC, consistent caching behavior

---

## Pattern 4: Validators - Duplicate Result Formatting

### Current Duplication

**Files**:
- `scripts/validate/base.py` - Base class (74 LOC)
- `scripts/validate/owasp_audit.py` - Custom result format (768 LOC, ~100 LOC for formatting)
- `scripts/validate/config_validator.py` - Custom result format (427 LOC, ~80 LOC for formatting)
- `scripts/validate/check_doc_links.py` - Custom result format (325 LOC, ~60 LOC for formatting)
- ... (9 more validators with custom formatting)

### Duplicate Code Example

```python
# In owasp_audit.py
class OWASPAudit:
    def format_results(self, findings):
        report = {
            'total_findings': len(findings),
            'critical': len([f for f in findings if f['severity'] == 'critical']),
            'high': len([f for f in findings if f['severity'] == 'high']),
            'findings': findings
        }
        return json.dumps(report, indent=2)

# In config_validator.py (similar structure)
class ConfigValidator:
    def generate_report(self, errors):
        summary = {
            'total_errors': len(errors),
            'critical_errors': len([e for e in errors if e['level'] == 'critical']),
            'warnings': len([e for e in errors if e['level'] == 'warning']),
            'details': errors
        }
        return json.dumps(summary, indent=2)

# In check_doc_links.py (same pattern)
class LinkValidator:
    def create_report(self, issues):
        output = {
            'total_issues': len(issues),
            'broken_links': len([i for i in issues if i['type'] == 'broken']),
            'orphaned_docs': len([i for i in issues if i['type'] == 'orphaned']),
            'issues': issues
        }
        return json.dumps(output, indent=2)
```

### Impact
- **Duplication**: 100-150 LOC across validators
- **Inconsistency**: Different severity/level/type field names
- **Maintenance**: Report format changes require updating 12 validators

### Solution
Create unified result formatter in base class:

```python
# In scripts/validate/base.py
class BaseValidator:
    def format_results(self, findings: List[dict], categories: dict = None):
        """Unified result formatting.

        Args:
            findings: List of finding dicts with 'severity' field
            categories: Optional category counts {category: count}
        """
        summary = {
            'timestamp': datetime.now().isoformat(),
            'total_findings': len(findings),
            'severity_summary': {
                'critical': len([f for f in findings if f.get('severity') == 'critical']),
                'high': len([f for f in findings if f.get('severity') == 'high']),
                'medium': len([f for f in findings if f.get('severity') == 'medium']),
                'low': len([f for f in findings if f.get('severity') == 'low']),
            },
            'findings': findings
        }
        if categories:
            summary['categories'] = categories
        return summary

# In subclasses (owasp_audit.py, config_validator.py, etc.)
class OWASPAudit(BaseValidator):
    def audit(self):
        findings = []  # ... find issues
        return self.format_results(findings, categories={'xss': 3, 'injection': 2})
```

**Expected Savings**: 150-200 LOC, consistent reporting across all validators

---

## Pattern 5: CLI - Duplicate Command Setup

### Current Duplication

**Files**:
- `scripts/cli/base.py` - Base CLI class (310 LOC)
- `scripts/cli/profiling.py` - Profiling commands (218 LOC)
- `scripts/cli/sync.py` - Sync commands (177 LOC)
- `scripts/cli/validation.py` - Validation commands (142 LOC)
- `scripts/cli/plugin_registry.py` - Plugin commands (213 LOC)

### Duplicate Code Example

```python
# In profiling.py
class ProfilingCLI:
    def __init__(self, parser):
        self.parser = parser
        self._setup_commands()

    def _setup_commands(self):
        profiling_parser = self.parser.add_subparsers(dest='profiling_command')

        profile_cmd = profiling_parser.add_parser('profile', help='Run profiling')
        profile_cmd.add_argument('--target', required=True)
        profile_cmd.add_argument('--verbose', action='store_true')
        profile_cmd.set_defaults(func=self.run_profile)

        analyze_cmd = profiling_parser.add_parser('analyze', help='Analyze results')
        analyze_cmd.add_argument('--file', required=True)
        analyze_cmd.add_argument('--format', choices=['json', 'html'])
        analyze_cmd.set_defaults(func=self.run_analyze)

# In validation.py (identical setup pattern)
class ValidationCLI:
    def __init__(self, parser):
        self.parser = parser
        self._setup_commands()

    def _setup_commands(self):
        validation_parser = self.parser.add_subparsers(dest='validation_command')

        validate_cmd = validation_parser.add_parser('validate', help='Run validation')
        validate_cmd.add_argument('--target', required=True)
        validate_cmd.add_argument('--verbose', action='store_true')
        validate_cmd.set_defaults(func=self.run_validation)

        # ... more commands with identical pattern
```

### Impact
- **Duplication**: 100-120 LOC of command setup patterns
- **Inconsistency**: Different argument naming conventions
- **Maintenance**: Hard to update CLI globally

### Solution
Create command builder pattern:

```python
# In scripts/cli/base.py
class CommandBuilder:
    """Builder for CLI commands with consistent patterns."""

    def __init__(self, parser, name: str):
        self.parser = parser
        self.name = name
        self.command_group = parser.add_subparsers(dest=f'{name}_command')

    def add_command(self, command_name: str, handler, help: str, args: dict):
        """Add a command with standard arguments."""
        cmd = self.command_group.add_parser(command_name, help=help)
        for arg_name, arg_config in args.items():
            cmd.add_argument(arg_name, **arg_config)
        cmd.set_defaults(func=handler)
        return cmd

# In profiling.py (simplified)
class ProfilingCLI:
    def __init__(self, parser):
        builder = CommandBuilder(parser, 'profiling')
        builder.add_command(
            'profile',
            self.run_profile,
            'Run profiling',
            {
                '--target': {'required': True},
                '--verbose': {'action': 'store_true'}
            }
        )
```

**Expected Savings**: 100-150 LOC, consistent CLI experience

---

## Summary: Duplication Metrics by Category

| Category | Pattern Type | Total Duplication | Instances | Avg Per-Instance |
|----------|--------------|-------------------|-----------|------------------|
| Statistics | Calc mean/stdev | 120-150 LOC | 5 | 24-30 LOC |
| Caching | TTL + storage logic | 180-200 LOC | 3 | 60-67 LOC |
| Metrics | Tracking/collection | 100-120 LOC | 4 | 25-30 LOC |
| Validation | Result formatting | 100-150 LOC | 12 | 8-12 LOC |
| CLI | Command setup | 100-120 LOC | 5 | 20-24 LOC |
| Config | Initialization | 80-100 LOC | 4 | 20-25 LOC |

**Total Identified Duplication**: 600-750 LOC (conservative estimate based on patterns shown)

---

## Implementation Approach

### Quick Wins (30-45 minutes)
1. ✅ Extract `AnalyticsUtilities` (80 LOC consolidation)
2. ✅ Create unified `ResultFormatter` (70 LOC consolidation)
3. ✅ Create `CommandBuilder` (40 LOC consolidation)

### Medium Effort (1-2 hours)
1. ✅ Consolidate batch statistics (100 LOC)
2. ✅ Migrate caches to framework (200 LOC)
3. ✅ Enhance `BaseValidator` (80 LOC)

### High Impact (2+ hours)
1. ✅ Complete batch framework
2. ✅ Complete analytics consolidation
3. ✅ Complete validator consolidation

---

**Analysis Date**: 2026-09-03
**Total Quantified Duplication**: 600-750 LOC (patterns shown)
**Additional Duplication**: ~100-200 LOC (similar patterns not shown)
**Conservative Estimate**: 700-950 LOC duplicate patterns ready for consolidation
