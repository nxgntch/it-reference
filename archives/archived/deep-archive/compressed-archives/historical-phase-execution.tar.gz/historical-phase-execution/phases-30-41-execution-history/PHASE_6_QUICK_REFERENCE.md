# Phase 6 Quick Reference Guide

**Cost-Optimized Performance & Scaling** | Week 1-2 Summary

---

## 🚀 Components Summary

| Component | Purpose | Status | Usage |
|-----------|---------|--------|-------|
| **PerformanceProfiler** | Profile operations, identify hot paths | ✅ Working | Profile any operation |
| **IntelligentAutoScaler** | Real-time scaling + predictions | ✅ Working | Evaluate scaling needs |
| **AdvancedCostAnalytics** | Multi-dimensional cost analysis | ✅ Working | Analyze costs by dimension |
| **BaselineAnalyzer** | Establish & track baselines | ✅ Working | Record measurements, compare |
| **performanceOptimizer** (Skill) | Generate optimization recommendations | ✅ Ready | Identify hot paths |
| **autoScalingManager** (Skill) | Generate scaling plans | ✅ Ready | Plan scaling for 24h |
| **phase6Assessment** (Skill) | Unified assessment interface | ✅ Ready | Get complete status |

---

## 📊 Quick API Examples

### Profile an Operation
```python
from app.core.performance_profiler import get_profiler

profiler = get_profiler()

async def my_operation():
    return await do_work()

metric = await profiler.profile_operation(
    "my_operation",
    my_operation,
    cost_estimate=0.05
)

print(f"Latency: {metric.duration_ms}ms")
print(f"Efficiency: {metric.efficiency}")
```

### Evaluate Scaling Decision
```python
from app.core.intelligent_auto_scaler import get_auto_scaler

scaler = get_auto_scaler()

decision = await scaler.evaluate_scaling(
    current_load=0.75,
    current_cost_rate=100.0,
    current_latency_ms=450,
    budget_remaining=5000.0,
    sla_target_latency_ms=500
)

print(f"Action: {decision.action}")  # scale_up, scale_down, or maintain
print(f"Factor: {decision.scale_factor}")  # 1.3 = 30% up
```

### Analyze Costs
```python
from app.core.advanced_cost_analytics import get_analytics

analytics = get_analytics()

# Record transactions
analytics.record_transaction(
    cost=50.0,
    agent="opus",
    feature="analysis",
    task_type="complex",
    duration_ms=5000
)

# Analyze
analysis = await analytics.analyze_cost_by_dimension()

print(f"Total cost: ${analysis.total_cost}")
print(f"ROI scores: {analysis.roi_scores}")
```

### Establish Baseline
```python
from app.core.baseline_analyzer import get_baseline_analyzer

analyzer = get_baseline_analyzer()

# Record measurements
for measurement in measurements:
    analyzer.record_operation(
        "query_op",
        latency_ms=measurement["latency"],
        cost=measurement["cost"],
        success=True
    )

# Establish baseline (needs 10+ samples)
baseline = analyzer.establish_baseline("query_op")

print(f"P95 Latency: {baseline.latency.p95}ms")
print(f"Cost per op: ${baseline.cost_per_operation}")
```

### Use Phase 6 Assessment Skill
```python
from skills.phase6Assessment.skill import Phase6Assessment

assessment = Phase6Assessment()

# Get current state
state = await assessment.assess_current_state({
    "metrics": {
        "current_load": 0.65,
        "current_cost_rate": 125.0,
        "current_latency_ms": 350,
        "budget_remaining": 8000.0,
    }
})

# Generate optimization report
report = await assessment.generate_optimization_report({})

# Get roadmap
roadmap = await assessment.optimization_roadmap({})
```

---

## 📈 Key Metrics

### Profiler Metrics
- `duration_ms`: Operation latency
- `throughput`: Operations per second
- `efficiency`: Throughput / Cost
- `cost`: Estimated cost

### Auto-Scaler Metrics
- `current_load`: 0-1 (0% to 100% utilization)
- `scale_factor`: 0.5-3.0 (50% to 300% of current)
- `current_capacity`: Relative capacity level

### Analytics Metrics
- `total_cost`: Sum of all transactions
- `cost_per_operation`: Average cost
- `roi_scores`: Value per dollar by feature
- `efficiency_score`: Success rate * throughput / cost

### Baseline Metrics
- `p50`: Median latency
- `p95`: 95th percentile latency
- `p99`: 99th percentile latency
- `success_rate`: Percentage of successful operations

---

## 🎯 Decision Trees

### Should I Scale Up?
```
if latency > SLA_TARGET × 1.2:
  → Scale up (critical)
else if load > 85%:
  → Scale up (high priority)
else if load > 60%:
  → Monitor (medium priority)
else:
  → Consider scaling down
```

### What Should I Optimize?
```
Priority = (latency × 0.4 + cost × 0.4 + efficiency_gap × 0.2)

if priority > threshold:
  if latency > 1000ms:
    → Aggressive caching + parallelization
  else if latency > 500ms:
    → Selective caching + parallelization
  else if latency > 100ms:
    → Result caching
  else:
    → Monitor for regressions
```

### What's My Optimization ROI?
```
Potential = latency_reduction% + cost_reduction% + efficiency_improvement%

Effort = "low" if latency < 500ms else "medium" if latency < 1000ms else "high"

ROI_Score = Potential / Effort_Level

Recommend if ROI_Score > 10
```

---

## 📋 Common Workflows

### Workflow 1: Establish Baselines
```
1. Profile production operations (20+ samples each)
2. Call analyzer.establish_baseline("operation_name")
3. Get baseline report
4. Identify top 5 optimization targets
5. Estimate ROI for each target
```

### Workflow 2: Optimize Hot Path
```
1. Identify hot path from profiler
2. Estimate effort (low/medium/high)
3. Calculate ROI
4. Implement optimization (cache/batch/parallelize)
5. Track baseline - compare to original
6. Verify improvement and no regression
```

### Workflow 3: Scale Dynamically
```
1. Measure current load, latency, budget
2. Call scaler.evaluate_scaling(...)
3. Get scaling decision (action + factor)
4. Apply capacity change
5. Monitor impact on latency
6. Verify cost impact
```

### Workflow 4: Continuous Optimization
```
1. Use phase6Assessment.assess_current_state()
2. Get optimization_report with recommendations
3. Track baseline for each optimization
4. Implement phase_1_quick_wins
5. Monitor and validate improvements
6. Plan phase_2 and phase_3 work
```

---

## ✅ Health Checks

**Phase 6 Health Status**:
- [ ] Profiler: Operations being profiled
- [ ] Auto-Scaler: Load being tracked
- [ ] Analytics: Costs being recorded
- [ ] Baselines: At least 5 operations baseline established

**Optimization Health**:
- [ ] Hot paths identified
- [ ] Top 5 targets analyzed
- [ ] ROI calculated
- [ ] Implementation plan created

**Baseline Health**:
- [ ] 10+ samples per operation
- [ ] Baselines establish successfully
- [ ] Comparison showing progress
- [ ] No regressions detected

---

## 🔧 Configuration

### Profiler
```python
profiler.get_hot_paths(threshold_pct=10)  # Hot path threshold: 10%
```

### Auto-Scaler
```python
scaler.min_capacity = 0.5  # Don't scale below 50%
scaler.max_capacity = 3.0  # Don't scale above 300%
```

### Analyzer
```python
analyzer.current_measurements  # Recorded measurements
analyzer.baselines  # Established baselines
analyzer.scaling_history  # Scaling decisions made
```

---

## 📊 Example Output

### Profiler Report
```json
{
  "summary": {
    "total_operations": 50,
    "operations_profiled": 5,
    "avg_latency_per_operation": 250.5
  },
  "hot_paths": [
    {
      "operation": "expensiveQuery",
      "percentage_of_total": 35.2,
      "avg_duration_ms": 800,
      "avg_cost": 0.05
    }
  ],
  "recommendations": [
    {
      "operation": "expensiveQuery",
      "issue": "High latency",
      "target_duration_ms": 640,
      "potential_savings_pct": 20
    }
  ]
}
```

### Scaling Decision
```json
{
  "action": "scale_up",
  "factor": 1.3,
  "reason": "Load at 90% utilization",
  "priority": "high",
  "estimated_cost_impact": 30.0
}
```

### Optimization Report
```json
{
  "optimizations_identified": 5,
  "total_potential_improvement_pct": 25,
  "recommendations": [
    {
      "operation": "expensiveQuery",
      "current_p95_latency_ms": 800,
      "recommended_actions": ["Implement aggressive caching"],
      "estimated_roi": {
        "improvement_pct": 30,
        "cost_savings": 75.0
      }
    }
  ],
  "implementation_priority": [...]
}
```

---

## 📞 Troubleshooting

### "Baseline not established"
- **Cause**: Fewer than 10 measurements recorded
- **Fix**: Record more operation measurements, then retry

### "No hot paths identified"
- **Cause**: No operations profiled yet
- **Fix**: Profile operations with `profiler.profile_operation()`

### "Scaling decisions not being made"
- **Cause**: Load history insufficient
- **Fix**: Run scaler with multiple measurements to build trend

### "Cost analysis shows no data"
- **Cause**: No transactions recorded
- **Fix**: Record transactions with `analytics.record_transaction()`

---

## 🎓 Learning Resources

- **PHASE_6_PLAN.md**: Complete phase plan
- **PHASE_6_STATUS.md**: Detailed status and progress
- **`docs/guides/skills/`**: Assessment skill docs
- **`docs/guides/skills/`**: Optimizer skill docs
- **`docs/guides/skills/`**: Scaler skill docs

---

## 🚦 Next Steps

### Week 2 (Now)
- [ ] Profile production operations
- [ ] Establish baselines (10+ samples each)
- [ ] Identify top 5 optimization targets
- [ ] Calculate ROI per target
- [ ] Rank by effort vs. reward

### Week 3
- [ ] Implement Phase 1 quick wins (low effort, high ROI)
- [ ] Measure improvements
- [ ] Verify no regressions
- [ ] Plan Phase 2 work

### Week 4
- [ ] Fine-tune scaling parameters
- [ ] Document best practices
- [ ] Create runbooks
- [ ] Prepare for production

---

**Status**: 🟢 Phase 6 Infrastructure Ready | 7/7 Components Working
**Commit**: `c27c9d67` | **Next**: Production profiling & baseline establishment
