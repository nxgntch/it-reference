# Phase 4: Parametrization Optimization Plan

## Current State

- Parametrized fixtures: 5
- Tests using @pytest.mark.parametrize: 13
- Total parametrization instances: 15
- Estimated fixture memory: ~75KB

## Optimization Opportunities

### Extract Heavy Parametrized Fixtures

**budgetAmount** (4 variants, from performance.py)

```python
# Before: Fixture parametrization (creates N instances)
@pytest.fixture(params=100, 500, 1000, 5000...)
def budgetAmount(request):
    return request.param

# After: Extract to constant, use decorator
BUDGETAMOUNT_VALUES = [100, 500, 1000, 5000...]

@pytest.mark.parametrize('budgetAmount', BUDGETAMOUNT_VALUES)
def testSomething(budgetAmount):
    # Only initialize when test uses it
    pass
```

**modelVariant** (3 variants, from auth.py)

```python
# Before: Fixture parametrization (creates N instances)
@pytest.fixture(params="claude-opus-5", "claude-sonnet-5", "claude-haiku-...)
def modelVariant(request):
    return request.param

# After: Extract to constant, use decorator
MODELVARIANT_VALUES = ["claude-opus-5", "claude-sonnet-5", "claude-haiku-...]

@pytest.mark.parametrize('modelVariant', MODELVARIANT_VALUES)
def testSomething(modelVariant):
    # Only initialize when test uses it
    pass
```

**costTier** (3 variants, from auth.py)

```python
# Before: Fixture parametrization (creates N instances)
@pytest.fixture(params="high", "standard", "quick"...)
def costTier(request):
    return request.param

# After: Extract to constant, use decorator
COSTTIER_VALUES = ["high", "standard", "quick"...]

@pytest.mark.parametrize('costTier', COSTTIER_VALUES)
def testSomething(costTier):
    # Only initialize when test uses it
    pass
```

**teamId** (3 variants, from performance.py)

```python
# Before: Fixture parametrization (creates N instances)
@pytest.fixture(params="engineering", "research", "operations"...)
def teamId(request):
    return request.param

# After: Extract to constant, use decorator
TEAMID_VALUES = ["engineering", "research", "operations"...]

@pytest.mark.parametrize('teamId', TEAMID_VALUES)
def testSomething(teamId):
    # Only initialize when test uses it
    pass
```

**featureFlag** (2 variants, from performance.py)

```python
# Before: Fixture parametrization (creates N instances)
@pytest.fixture(params=True, False...)
def featureFlag(request):
    return request.param

# After: Extract to constant, use decorator
FEATUREFLAG_VALUES = [True, False...]

@pytest.mark.parametrize('featureFlag', FEATUREFLAG_VALUES)
def testSomething(featureFlag):
    # Only initialize when test uses it
    pass
```

## Benefits

- Parametrization data extracted to module-level constants
- Fixtures only initialized when explicitly used
- Reduced memory footprint for tests not using parametrization
- Clearer dependency between test and parametrization data
- Expected savings: ~11KB (10-15%)

## Implementation Strategy

1. Identify all parametrized fixtures
2. Extract parametrization data to module-level constants
3. Create parametrization helper module (conftest_parametrize.py)
4. Replace fixture parametrization with @pytest.mark.parametrize
5. Update tests to use decorator instead of fixture param
6. Run test suite and verify all tests pass

## Timeline

- Analysis: 30 min (DONE)
- Implementation: 1-2 hours
- Testing & validation: 30 min
- Total: 2-2.5 hours

## Risk Assessment

- Low risk: Only affects tests using parametrization
- No breaking changes: Decorator is equivalent to fixture params
- Reversible: Can revert to fixture params if needed
- Test coverage: Unchanged - same test cases run
