# Phases 27-29: Infrastructure Consolidation Detailed Specs

**Document Type**: Complete implementation guide for infrastructure phases
**Phases Covered**: 27 (Sync Systems), 28 (Performance), 29 (Test Utils)
**Target Audience**: Developers executing these phases
**Status**: Ready for execution

---

## Phase 27: Sync Systems Consolidation (2 hours, -1,800 LOC)

### Objective
Consolidate 13 sync files (3,352 LOC) into SyncFramework + RepoSyncOrchestrator + unified GitOperations.

### Directory Structure
```
scripts/sync/syncFramework/
├── __init__.py
├── framework.py              (150 LOC - main framework)
├── git_operations.py         (100 LOC - unified git ops)
├── orchestrator.py           (150 LOC - sync orchestrator)
├── strategies/
│   ├── __init__.py
│   ├── base_strategy.py      (80 LOC)
│   ├── doc_strategy.py       (60 LOC)
│   ├── config_strategy.py    (60 LOC)
│   ├── mobile_strategy.py    (50 LOC)
│   └── archive_strategy.py   (50 LOC)
└── shims/
    ├── syncDoc_shim.py
    ├── syncConfig_shim.py
    ├── syncClean_shim.py
    ├── syncMobile_shim.py
    ├── syncit_shim.py
    ├── optimized_shim.py
    ├── autosync_shim.py
    └── base_shim.py

scripts/sync/repos/repoSync/
├── __init__.py
├── orchestrator.py           (200 LOC)
├── handlers/
│   ├── __init__.py
│   ├── base_handler.py       (100 LOC)
│   ├── nxgntch_handler.py    (100 LOC)
│   ├── logs_handler.py       (100 LOC)
│   ├── archive_handler.py    (100 LOC)
│   └── reference_handler.py  (100 LOC)
├── validators/
│   ├── repo_validator.py     (80 LOC)
│   └── github_validator.py   (70 LOC)
└── shims/
    ├── daily_sync_shim.py
    ├── logs_sync_shim.py
    ├── archive_workflow_shim.py
    ├── reference_sync_shim.py
    └── nxgntch_sync_shim.py
```

### Core Components

#### 1. GitOperations (100 LOC)
```python
# scripts/sync/syncFramework/git_operations.py

import subprocess
from pathlib import Path
from typing import List, Optional, Tuple
from dataclasses import dataclass
from enum import Enum

class GitCommand(Enum):
    """Standard git commands."""
    STATUS = "status"
    COMMIT = "commit"
    PUSH = "push"
    PULL = "pull"
    ADD = "add"
    CLONE = "clone"
    REMOTE = "remote"
    BRANCH = "branch"
    CHECKOUT = "checkout"

@dataclass
class GitResult:
    """Result from git operation."""
    command: str
    repo_path: Path
    returncode: int
    stdout: str
    stderr: str

    @property
    def success(self) -> bool:
        return self.returncode == 0

    def raise_if_error(self) -> None:
        """Raise GitError if operation failed."""
        if not self.success:
            raise GitError(
                f"Git command failed: {self.command}\n"
                f"stderr: {self.stderr}"
            )

class GitError(Exception):
    """Base exception for git operations."""
    pass

class GitOperations:
    """Unified git operations - single source of truth for all git calls."""

    DEFAULT_TIMEOUT = 30
    DEFAULT_RETRIES = 3

    @staticmethod
    def run(cmd: List[str], repo_path: Path = None,
            timeout: int = None, capture: bool = True) -> GitResult:
        """
        Execute git command.

        Args:
            cmd: Command args (without 'git' prefix)
            repo_path: Repository path (default: cwd)
            timeout: Command timeout in seconds
            capture: Capture output (vs stream to console)

        Returns:
            GitResult with returncode, stdout, stderr
        """
        if timeout is None:
            timeout = GitOperations.DEFAULT_TIMEOUT

        full_cmd = ["git"] + cmd

        try:
            result = subprocess.run(
                full_cmd,
                cwd=repo_path,
                capture_output=capture,
                text=True,
                timeout=timeout
            )

            return GitResult(
                command=' '.join(cmd),
                repo_path=repo_path,
                returncode=result.returncode,
                stdout=result.stdout.strip(),
                stderr=result.stderr.strip()
            )

        except subprocess.TimeoutExpired:
            raise GitError(f"Git command timed out: {' '.join(cmd)}")
        except Exception as e:
            raise GitError(f"Git execution failed: {str(e)}")

    @staticmethod
    def status(repo_path: Path) -> GitResult:
        """Get repo status."""
        return GitOperations.run(["status", "--porcelain"], repo_path)

    @staticmethod
    def commit(repo_path: Path, message: str) -> GitResult:
        """Commit changes."""
        return GitOperations.run(["commit", "-m", message], repo_path)

    @staticmethod
    def push(repo_path: Path, branch: str = "main",
             remote: str = "origin") -> GitResult:
        """Push to remote."""
        return GitOperations.run(["push", remote, branch], repo_path)

    @staticmethod
    def pull(repo_path: Path, branch: str = "main",
             remote: str = "origin") -> GitResult:
        """Pull from remote."""
        return GitOperations.run(["pull", remote, branch], repo_path)

    @staticmethod
    def verify_repo(repo_path: Path) -> Tuple[bool, str]:
        """Verify repo is valid git repository."""
        if not repo_path.exists():
            return False, f"Path does not exist: {repo_path}"

        git_dir = repo_path / ".git"
        if not git_dir.exists():
            return False, f"Not a git repository: {repo_path}"

        # Try running git command
        result = GitOperations.status(repo_path)
        if result.success:
            return True, "Valid git repository"
        else:
            return False, f"Git repository check failed: {result.stderr}"

# Usage replaces 45+ subprocess.run() calls
# Old: subprocess.run(["git", "status"], cwd=repo_path)
# New: GitOperations.status(repo_path)
```

#### 2. SyncFramework (150 LOC)
```python
# scripts/sync/syncFramework/framework.py

from abc import ABC, abstractmethod
from typing import Dict, Any, List, Optional
from pathlib import Path
from dataclasses import dataclass
import logging

logger = logging.getLogger(__name__)

@dataclass
class SyncConfig:
    """Configuration for sync operation."""
    source_path: Path
    target_path: Path
    sync_type: str
    dry_run: bool = False
    verbose: bool = False
    auto_commit: bool = False

@dataclass
class SyncResult:
    """Result from sync operation."""
    success: bool
    sync_type: str
    items_processed: int
    items_skipped: int
    items_failed: int
    errors: List[str]
    duration_seconds: float

    @property
    def summary(self) -> str:
        return (
            f"{self.sync_type} sync: "
            f"{self.items_processed} processed, "
            f"{self.items_skipped} skipped, "
            f"{self.items_failed} failed"
        )

class SyncStrategy(ABC):
    """Base sync strategy."""

    @abstractmethod
    def sync(self, config: SyncConfig) -> SyncResult:
        """Execute sync operation."""
        pass

class DocSyncStrategy(SyncStrategy):
    """Sync documentation files."""

    def sync(self, config: SyncConfig) -> SyncResult:
        logger.info(f"🔄 Syncing docs from {config.source_path}")

        # Implementation
        return SyncResult(
            success=True,
            sync_type="docs",
            items_processed=0,
            items_skipped=0,
            items_failed=0,
            errors=[],
            duration_seconds=0.0
        )

class ConfigSyncStrategy(SyncStrategy):
    """Sync configuration files."""

    def sync(self, config: SyncConfig) -> SyncResult:
        logger.info(f"⚙️ Syncing config from {config.source_path}")
        return SyncResult(
            success=True,
            sync_type="config",
            items_processed=0,
            items_skipped=0,
            items_failed=0,
            errors=[],
            duration_seconds=0.0
        )

class SyncFramework:
    """Unified sync framework with pluggable strategies."""

    def __init__(self):
        self.strategies: Dict[str, SyncStrategy] = {}
        self._register_default_strategies()

    def _register_default_strategies(self):
        """Register built-in strategies."""
        self.strategies['docs'] = DocSyncStrategy()
        self.strategies['config'] = ConfigSyncStrategy()

    def register_strategy(self, name: str, strategy: SyncStrategy) -> None:
        """Register custom sync strategy."""
        self.strategies[name] = strategy
        logger.debug(f"Registered sync strategy: {name}")

    def execute_sync(self, config: SyncConfig) -> SyncResult:
        """Execute sync operation."""
        strategy = self.strategies.get(config.sync_type)

        if not strategy:
            return SyncResult(
                success=False,
                sync_type=config.sync_type,
                items_processed=0,
                items_skipped=0,
                items_failed=0,
                errors=[f"Unknown sync type: {config.sync_type}"],
                duration_seconds=0.0
            )

        try:
            result = strategy.sync(config)
            logger.info(result.summary)
            return result

        except Exception as e:
            logger.error(f"Sync failed: {str(e)}")
            return SyncResult(
                success=False,
                sync_type=config.sync_type,
                items_processed=0,
                items_skipped=0,
                items_failed=1,
                errors=[str(e)],
                duration_seconds=0.0
            )

# Global framework instance
_sync_framework: Optional[SyncFramework] = None

def get_sync_framework() -> SyncFramework:
    """Get or create singleton sync framework."""
    global _sync_framework
    if _sync_framework is None:
        _sync_framework = SyncFramework()
    return _sync_framework
```

#### 3. Migration Script
```python
# scripts/consolidation/migrate_phase27_sync.py

"""
Phase 27 migration: Update sync module imports.

Migrates from old sync modules to new framework.
"""

import re
from pathlib import Path
from typing import Dict, List

SYNC_IMPORTS = {
    'from scripts.sync.syncDoc import': 'from scripts.sync.syncFramework.shims.syncDoc_shim import',
    'from scripts.sync.syncConfig import': 'from scripts.sync.syncFramework.shims.syncConfig_shim import',
    'from scripts.sync.base import': 'from scripts.sync.syncFramework.shims.base_shim import',
    'from scripts.sync.repos.daily_sync import': 'from scripts.sync.repos.repoSync.shims.daily_sync_shim import',
    'from scripts.sync.repos.logs_sync import': 'from scripts.sync.repos.repoSync.shims.logs_sync_shim import',
}

SUBPROCESS_PATTERNS = [
    (r'subprocess\.run\(\["git".*?\)\)', 'GitOperations.run(...)'),
    (r'subprocess\.run\(\["git",', 'GitOperations.run(['),
]

def migrate_imports(source_file: Path) -> int:
    """Migrate imports in a file."""
    try:
        content = source_file.read_text()
        original = content

        for old, new in SYNC_IMPORTS.items():
            content = content.replace(old, new)

        # Also migrate subprocess calls
        for pattern, replacement in SUBPROCESS_PATTERNS:
            if re.search(pattern, content):
                print(f"⚠️  Found subprocess pattern in {source_file}")
                print(f"  Consider migrating to: {replacement}")

        if content != original:
            source_file.write_text(content)
            return 1
        return 0

    except Exception as e:
        print(f"❌ Error migrating {source_file}: {e}")
        return 0

def main():
    """Migrate all Python files."""
    total = 0

    for py_file in Path('.').rglob('*.py'):
        if 'test' not in str(py_file) and '.git' not in str(py_file):
            count = migrate_imports(py_file)
            total += count

    print(f"\n✅ Migrated {total} files")
    print("\nNext steps:")
    print("1. Review subprocess.run calls in sync modules")
    print("2. Migrate to GitOperations.run()")
    print("3. Run pytest to verify")

if __name__ == '__main__':
    main()
```

### Testing Strategy
```python
# tests/test_phase27_sync_framework.py

import pytest
from pathlib import Path
from scripts.sync.syncFramework.git_operations import GitOperations, GitResult
from scripts.sync.syncFramework.framework import (
    SyncFramework, SyncConfig, DocSyncStrategy
)

def test_git_operations_status(tmp_path):
    """Test git status command."""
    # Create temp git repo
    repo = tmp_path / "test_repo"
    repo.mkdir()

    result = GitOperations.status(repo)
    # Either success or git not initialized (both acceptable)
    assert isinstance(result, GitResult)
    assert result.returncode in (0, 128)  # 0=success, 128=not a repo

def test_sync_framework_registration():
    """Test strategy registration."""
    framework = SyncFramework()

    original_count = len(framework.strategies)

    class CustomStrategy:
        def sync(self, config):
            return None

    framework.register_strategy('custom', CustomStrategy())

    assert len(framework.strategies) == original_count + 1
    assert 'custom' in framework.strategies

def test_sync_result():
    """Test sync result generation."""
    config = SyncConfig(
        source_path=Path('/tmp'),
        target_path=Path('/tmp/target'),
        sync_type='docs'
    )

    framework = SyncFramework()
    result = framework.execute_sync(config)

    assert result.sync_type == 'docs'
    assert isinstance(result.success, bool)
```

### Validation Checklist (Phase 27)
```
□ Create directory structure
□ Implement GitOperations (100 LOC)
□ Implement SyncFramework (150 LOC)
□ Implement SyncOrchestrator (150 LOC)
□ Create sync strategies (5 files, 270 LOC)
□ Create 8 backward-compat shims
□ Create migration script
□ Run migration: python scripts/consolidation/migrate_phase27_sync.py
□ Verify imports updated (40+ files)
□ Run test suite: pytest tests/test_phase27_* -v
□ Benchmark git operations (should be < ±5% from baseline)
□ Verify all sync operations work
□ Test repo validation functions
□ Commit: "feat(consolidation): sync framework - phase 27"
□ Merge to main
```

---

## Phase 28: Performance Systems Consolidation (2.5 hours, -1,200 LOC)

### Objective
Consolidate 9 performance/profiling modules (2,616 LOC) into ProfilingFramework + OptimizationFramework.

### Directory Structure
```
app/core/performanceCore/
├── __init__.py
├── profiling_framework.py    (150 LOC)
├── optimization_framework.py (150 LOC)
├── metrics/
│   ├── __init__.py
│   ├── measurement.py        (120 LOC)
│   ├── aggregator.py         (100 LOC)
│   └── reporter.py           (100 LOC)
├── strategies/
│   ├── optimizer_strategy.py (100 LOC)
│   ├── profiler_strategy.py  (100 LOC)
│   ├── auto_scaler.py        (120 LOC)
│   ├── circuit_breaker.py    (100 LOC)
│   └── token_optimizer.py    (100 LOC)
└── shims/
    ├── tokenOptimizer_shim.py
    ├── optimization_executor_shim.py
    ├── performance_profiler_shim.py
    ├── intelligent_auto_scaler_shim.py
    └── circuitBreaker_shim.py

scripts/profiling/
├── profiling_framework.py    (150 LOC)
├── reporters/
│   ├── base_reporter.py      (100 LOC)
│   ├── dashboard_reporter.py (150 LOC)
│   ├── weekly_reporter.py    (150 LOC)
│   └── alert_reporter.py     (100 LOC)
└── shims/
    ├── parametrization_dashboard_shim.py
    ├── parametrization_weekly_report_shim.py
    └── measurement_shim.py
```

### Core Components

#### 1. ProfilingFramework (150 LOC)
```python
# scripts/profiling/profiling_framework.py

from abc import ABC, abstractmethod
from typing import Dict, Any, List
from dataclasses import dataclass
from datetime import datetime
import logging

logger = logging.getLogger(__name__)

@dataclass
class PerformanceMetric:
    """Single performance metric."""
    name: str
    value: float
    unit: str
    timestamp: str
    tags: Dict[str, str] = None

class ProfilerStrategy(ABC):
    """Base profiler strategy."""

    @abstractmethod
    def collect(self) -> List[PerformanceMetric]:
        """Collect performance metrics."""
        pass

class DashboardReporter(ProfilerStrategy):
    """Generate performance dashboard."""

    def collect(self) -> List[PerformanceMetric]:
        logger.info("📊 Collecting dashboard metrics")
        # Implementation
        return []

class WeeklyReporter(ProfilerStrategy):
    """Generate weekly performance report."""

    def collect(self) -> List[PerformanceMetric]:
        logger.info("📈 Collecting weekly metrics")
        # Implementation
        return []

class ProfilingFramework:
    """Unified profiling framework."""

    def __init__(self):
        self.reporters: Dict[str, ProfilerStrategy] = {}
        self._register_defaults()

    def _register_defaults(self):
        """Register default reporters."""
        self.reporters['dashboard'] = DashboardReporter()
        self.reporters['weekly'] = WeeklyReporter()

    def register_reporter(self, name: str, reporter: ProfilerStrategy):
        """Register custom reporter."""
        self.reporters[name] = reporter

    def generate_report(self, report_type: str) -> Dict[str, Any]:
        """Generate performance report."""
        if report_type not in self.reporters:
            return {'error': f'Unknown report type: {report_type}'}

        reporter = self.reporters[report_type]
        metrics = reporter.collect()

        return {
            'report_type': report_type,
            'timestamp': datetime.now().isoformat(),
            'metrics': metrics,
            'success': True
        }
```

#### 2. OptimizationFramework (150 LOC)
```python
# app/core/performanceCore/optimization_framework.py

from abc import ABC, abstractmethod
from typing import Dict, Any, List, Optional
from dataclasses import dataclass
import logging

logger = logging.getLogger(__name__)

@dataclass
class OptimizationResult:
    """Result from optimization."""
    strategy: str
    improvement_percent: float
    actions_taken: List[str]
    metrics_before: Dict[str, float]
    metrics_after: Dict[str, float]

class OptimizerStrategy(ABC):
    """Base optimizer strategy."""

    @abstractmethod
    def optimize(self) -> OptimizationResult:
        """Execute optimization."""
        pass

class TokenOptimizer(OptimizerStrategy):
    """Optimize token usage."""

    def optimize(self) -> OptimizationResult:
        logger.info("🔧 Optimizing token usage")
        return OptimizationResult(
            strategy='token',
            improvement_percent=0.0,
            actions_taken=[],
            metrics_before={},
            metrics_after={}
        )

class AutoScaler(OptimizerStrategy):
    """Auto-scale resources."""

    def optimize(self) -> OptimizationResult:
        logger.info("📈 Auto-scaling resources")
        return OptimizationResult(
            strategy='autoscale',
            improvement_percent=0.0,
            actions_taken=[],
            metrics_before={},
            metrics_after={}
        )

class OptimizationFramework:
    """Unified optimization framework."""

    def __init__(self):
        self.optimizers: Dict[str, OptimizerStrategy] = {}
        self._register_defaults()

    def _register_defaults(self):
        self.optimizers['token'] = TokenOptimizer()
        self.optimizers['autoscale'] = AutoScaler()

    def register_optimizer(self, name: str, optimizer: OptimizerStrategy):
        self.optimizers[name] = optimizer

    def run_optimization(self, optimizer_type: str) -> OptimizationResult:
        if optimizer_type not in self.optimizers:
            raise ValueError(f"Unknown optimizer: {optimizer_type}")

        optimizer = self.optimizers[optimizer_type]
        return optimizer.optimize()
```

### Testing Strategy
```python
# tests/test_phase28_performance_framework.py

import pytest
from scripts.profiling.profiling_framework import ProfilingFramework, DashboardReporter
from app.core.performanceCore.optimization_framework import (
    OptimizationFramework, TokenOptimizer
)

def test_profiling_framework_registration():
    """Test reporter registration."""
    framework = ProfilingFramework()

    class CustomReporter:
        def collect(self):
            return []

    framework.register_reporter('custom', CustomReporter())
    assert 'custom' in framework.reporters

def test_optimization_framework():
    """Test optimization execution."""
    framework = OptimizationFramework()

    result = framework.run_optimization('token')

    assert result.strategy == 'token'
    assert isinstance(result.improvement_percent, float)
    assert isinstance(result.actions_taken, list)
```

### Validation Checklist (Phase 28)
```
□ Create directory structures
□ Implement ProfilingFramework (150 LOC)
□ Implement OptimizationFramework (150 LOC)
□ Create metric collectors (4 files, 220 LOC)
□ Create optimizers (5 files, 300 LOC)
□ Create reporters (4 files, 250 LOC)
□ Create 5 backward-compat shims
□ Create migration script
□ Run migration
□ Run test suite: pytest tests/test_phase28_* -v
□ Benchmark performance metrics collection
□ Test all optimizer strategies
□ Verify profiling accuracy
□ Commit: "feat(consolidation): performance frameworks - phase 28"
□ Merge to main
```

---

## Phase 29: Test Utilities Consolidation (1 hour, -400 LOC)

### Objective
Consolidate 5+ test utility files (1,678 LOC) into unified TestFactory + MockBuilders.

### Directory Structure
```
tests/common/
├── __init__.py
├── factories/
│   ├── __init__.py
│   ├── test_factory.py           (180 LOC)
│   ├── mock_builder.py           (150 LOC)
│   ├── fixture_builder.py        (100 LOC)
│   └── data_builder.py           (100 LOC)
├── assertions/
│   ├── __init__.py
│   ├── assertion_helpers.py      (100 LOC)
│   └── custom_assertions.py      (80 LOC)
└── utilities/
    ├── __init__.py
    ├── performance_helpers.py     (80 LOC)
    └── data_generators.py        (100 LOC)
```

### Core Components

#### 1. TestFactory (180 LOC)
```python
# tests/common/factories/test_factory.py

"""
Unified test factory for creating test objects.

Replaces 5+ scattered factory implementations.
"""

from dataclasses import dataclass
from typing import Any, Dict, List, Optional
from pathlib import Path

@dataclass
class TestConfig:
    """Test configuration."""
    name: str
    debug: bool = False
    timeout: int = 30

class TestFactory:
    """Factory for creating test objects."""

    @staticmethod
    def create_batch_task(
        task_id: str = "task1",
        agent_id: str = "agent1",
        cost: float = 10.0,
        **kwargs
    ) -> Dict[str, Any]:
        """Create batch task for testing."""
        return {
            'taskId': task_id,
            'agentId': agent_id,
            'description': kwargs.get('description', 'Test task'),
            'complexity': kwargs.get('complexity', 'medium'),
            'estimatedCost': cost,
            'model': kwargs.get('model', 'gpt-4'),
            'parameters': kwargs.get('parameters', {})
        }

    @staticmethod
    def create_analytics_data(
        data_points: int = 100,
        value_range: tuple = (0, 100)
    ) -> List[float]:
        """Create sample analytics data."""
        return [
            float(i * (value_range[1] - value_range[0]) / data_points + value_range[0])
            for i in range(data_points)
        ]

    @staticmethod
    def create_config(
        name: str = "test_config",
        **kwargs
    ) -> Dict[str, Any]:
        """Create test configuration."""
        return {
            'name': name,
            'agents': kwargs.get('agents', {}),
            'skills': kwargs.get('skills', {}),
            **kwargs
        }

    @staticmethod
    def create_sync_result(
        success: bool = True,
        items_processed: int = 0,
        **kwargs
    ) -> Dict[str, Any]:
        """Create sync operation result."""
        return {
            'success': success,
            'items_processed': items_processed,
            'items_skipped': kwargs.get('items_skipped', 0),
            'items_failed': kwargs.get('items_failed', 0),
            'errors': kwargs.get('errors', [])
        }

    @staticmethod
    def create_test_repo(tmp_path: Path) -> Path:
        """Create minimal test repository."""
        repo = tmp_path / "test_repo"
        repo.mkdir()
        (repo / ".git").mkdir()
        return repo
```

#### 2. MockBuilder (150 LOC)
```python
# tests/common/factories/mock_builder.py

"""
Unified mock builder for creating test doubles.
"""

from unittest.mock import Mock, MagicMock, patch
from typing import Any, Callable, Dict

class MockBuilder:
    """Builder for creating configured mocks."""

    @staticmethod
    def create_orchestrator_mock() -> Mock:
        """Create mocked orchestrator."""
        mock = MagicMock()
        mock.invoke.return_value = {
            'status': 'success',
            'result': {}
        }
        return mock

    @staticmethod
    def create_git_operations_mock() -> Mock:
        """Create mocked git operations."""
        mock = MagicMock()
        mock.status.return_value = Mock(
            success=True,
            stdout="",
            stderr=""
        )
        mock.commit.return_value = Mock(success=True)
        mock.push.return_value = Mock(success=True)
        return mock

    @staticmethod
    def create_config_manager_mock() -> Mock:
        """Create mocked config manager."""
        mock = MagicMock()
        mock.get_agent_config.return_value = {
            'name': 'test_agent',
            'type': 'director'
        }
        mock.validate.return_value = True
        return mock

    @staticmethod
    def create_validator_mock(findings: list = None) -> Mock:
        """Create mocked validator."""
        mock = MagicMock()
        mock.validate.return_value = findings or []
        mock.get_results.return_value = {
            'findings': findings or [],
            'timestamp': '2026-01-01T00:00:00'
        }
        return mock

    @staticmethod
    def create_context_manager(return_value: Any = None) -> Mock:
        """Create mock context manager."""
        mock = MagicMock()
        mock.__enter__.return_value = return_value
        mock.__exit__.return_value = None
        return mock
```

### Testing Strategy
```python
# tests/test_phase29_test_utilities.py

import pytest
from pathlib import Path
from tests.common.factories.test_factory import TestFactory
from tests.common.factories.mock_builder import MockBuilder

def test_batch_task_creation():
    """Test batch task factory."""
    task = TestFactory.create_batch_task(
        task_id="batch_test",
        cost=20.0
    )

    assert task['taskId'] == "batch_test"
    assert task['estimatedCost'] == 20.0
    assert 'agentId' in task

def test_analytics_data_creation():
    """Test analytics data factory."""
    data = TestFactory.create_analytics_data(points=50)

    assert len(data) == 50
    assert all(isinstance(x, float) for x in data)

def test_mock_orchestrator():
    """Test orchestrator mock."""
    mock = MockBuilder.create_orchestrator_mock()

    result = mock.invoke({})

    assert result['status'] == 'success'

def test_test_repo_creation(tmp_path):
    """Test repository creation."""
    repo = TestFactory.create_test_repo(tmp_path)

    assert repo.exists()
    assert (repo / ".git").exists()
```

### Validation Checklist (Phase 29)
```
□ Create test/common directory structure
□ Implement TestFactory (180 LOC)
□ Implement MockBuilder (150 LOC)
□ Create assertion helpers (180 LOC)
□ Create data generators (100 LOC)
□ Create performance helpers (80 LOC)
□ Update test conftest.py to use new utilities
□ Migrate existing test fixtures
□ Run test suite: pytest tests/ -v
□ Verify all 1,611+ tests passing
□ Check coverage ≥85%
□ Commit: "feat(consolidation): test utilities - phase 29"
□ Merge to main
```

---

## Cross-Phase Integration

### Meta-Pattern Application (Phases 27-29)

**Phase 27 (Sync)**:
- [ ] Apply ProcessRunner to all git operations (✅ Built-in via GitOperations)
- [ ] Apply FileFormat to sync file operations
- [ ] Apply CommonArguments to sync CLI

**Phase 28 (Performance)**:
- [ ] Apply FileFormat to metric reporting
- [ ] Apply ResultFormatter to optimization results
- [ ] Apply ContentBuilder to report generation

**Phase 29 (Tests)**:
- [ ] TestFactory uses ResultFormatter
- [ ] MockBuilder uses CommonArguments patterns
- [ ] Assertion helpers use FileFormat for output

---

## Migration Commands (Phases 27-29)

### Phase 27
```bash
# Create structure
mkdir -p scripts/sync/syncFramework/{strategies,shims}
mkdir -p scripts/sync/repos/repoSync/{handlers,validators,shims}

# Run migration
python scripts/consolidation/migrate_phase27_sync.py

# Verify
pytest tests/test_phase27_* -v
git diff --stat | head -20
```

### Phase 28
```bash
# Create structure
mkdir -p app/core/performanceCore/{metrics,strategies,shims}
mkdir -p scripts/profiling/{reporters,shims}

# Run migration
python scripts/consolidation/migrate_phase28_performance.py

# Verify
pytest tests/test_phase28_* -v
python scripts/benchmarks/run_critical_paths.py
```

### Phase 29
```bash
# Create structure
mkdir -p tests/common/{factories,assertions,utilities}

# Update test utilities
# (No large migration needed - just reorganization)

# Verify
pytest tests/ -v
pytest tests/ --cov=app --cov=scripts
```

---

## Completion Sign-Off Template (Phases 27-29)

```markdown
# Phase [27/28/29] Completion Sign-Off

**Phase**: [Name]
**Developer**: [Name]
**Reviewer**: [Lead]
**Duration**: X hours

## Completion Status
- [x] Framework created (X LOC)
- [x] Shims working correctly
- [x] Migration script executed
- [x] All tests passing
- [x] 0 regressions
- [x] Performance verified (±5%)

## Metrics
- **LOC Removed**: -X LOC
- **Frameworks Created**: X
- **Files Modified**: X files
- **Test Results**: XXX passed, 0 failed

## Sign-Off
Developer: ___________________
Lead Reviewer: ___________________

✅ APPROVED FOR MERGE
```

---

**Phases 27-29 Specs Complete ✅**
**Ready for execution in Week 2**
