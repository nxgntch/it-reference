# Phase 5: Documentation Reorganization Plan

## Current State

- Root-level documentation files: 8

- Lightweight root files: 2

- Heavy nested files: 2

- Estimated root verbose size: 47.0KB


## Reorganization Opportunities

### Root-Level Files to Move

**FAQ_TROUBLESHOOTING.md** (9.0KB, 482 lines)

- Destination: guides/operations/ or guides/setup/

- Reason: Operational/setup - can move to nested


**LAUNCH_METRICS.md** (7.0KB, 338 lines)

- Destination: guides/architecture/ or guides/reference/

- Reason: Reference - can move to nested structure


**RELEASE_CHECKLIST.md** (6.0KB, 257 lines)

- Destination: guides/operations/ or guides/setup/

- Reason: Operational/setup - can move to nested


**ONBOARDING_CHECKLIST.md** (6.0KB, 321 lines)

- Destination: guides/operations/ or guides/setup/

- Reason: Operational/setup - can move to nested


**INTERACTIVE_DOCS_INDEX.md** (5.0KB, 257 lines)

- Destination: guides/operations/ or guides/setup/

- Reason: Operational/setup - can move to nested


**SDK_PUBLICATION.md** (5.0KB, 295 lines)

- Destination: guides/operations/ or guides/setup/

- Reason: Operational/setup - can move to nested


**SWAGGER_SETUP.md** (4.0KB, 240 lines)

- Destination: guides/operations/ or guides/setup/

- Reason: Operational/setup - can move to nested


**ARCHITECTURE.md** (1.0KB, 46 lines)

- Destination: guides/architecture/ or guides/reference/

- Reason: Reference - can move to nested structure


## Lightweight Root Documentation

Keep these at root (navigation and entry points):

- **INDEX.md** - Main entry point and navigation

- **QUICKSTART.md** - Quick-reference guide

- **README.md** (if needed) - Project overview


## Directory Structure After Reorganization

```

docs/

├── INDEX.md (lightweight)

├── QUICKSTART.md (lightweight)

├── guides/

│   ├── operations/ (checklists, deployment, CI/CD)

│   ├── setup/ (onboarding, setup, configuration)

│   ├── architecture/ (architectural decisions)

│   └── reference/ (FAQ, troubleshooting)

├── specifications/ (API specs, protocols)

├── examples/ (integration examples, tutorials)

└── work/ (status, phases, roadmap)

```


## Benefits

- Estimated savings: 23.0KB (10-15% context reduction)

- Clearer documentation hierarchy

- Faster documentation navigation

- Reduced root-level clutter

- Better organization by use case


## Implementation Strategy

1. Create lightweight root INDEX.md (links to subsections)

2. Move checklists to guides/operations/

3. Move setup guides to guides/setup/

4. Move reference docs to guides/reference/

5. Consolidate duplicate content

6. Update CLAUDE.md with new documentation structure

7. Verify all links are correct


## Timeline

- Analysis: 30 min (DONE)

- Implementation: 1-1.5 hours

- Verification & testing: 30 min

- Total: 2-2.5 hours
