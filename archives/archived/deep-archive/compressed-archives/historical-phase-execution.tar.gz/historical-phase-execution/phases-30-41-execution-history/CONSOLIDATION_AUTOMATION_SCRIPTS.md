# Consolidation Automation Scripts & Tools

**Type**: Executable Python scripts for automated migration, validation, and daily operations
**Status**: Ready to run - Copy and execute
**Location**: `scripts/consolidation/` directory

---

## Script 1: Unified Pre-Execution Health Check

```python
#!/usr/bin/env python3
# scripts/consolidation/health_check_complete.py

"""
Complete pre-execution health check.
Run this Monday morning before Phase 22 starts.

Usage: python scripts/consolidation/health_check_complete.py
Expected: All GREEN ✅
"""

import subprocess
import sys
from pathlib import Path
from datetime import datetime

class HealthCheckSuite:
    def __init__(self):
        self.passed = 0
        self.failed = 0
        self.warnings = []

    def check_python(self):
        """Check Python version."""
        import sys
        version = sys.version_info
        if version >= (3, 9):
            print(f"✅ Python {version.major}.{version.minor}")
            self.passed += 1
        else:
            print(f"❌ Python 3.9+ required, found {version.major}.{version.minor}")
            self.failed += 1

    def check_git(self):
        """Check git is clean."""
        result = subprocess.run(
            ['git', 'status', '--porcelain'],
            capture_output=True,
            text=True
        )

        if result.stdout.strip():
            print(f"⚠️  Git working directory not clean:")
            print(f"   {result.stdout[:100]}")
            self.warnings.append("Stash changes before starting")
        else:
            print("✅ Git working directory clean")
            self.passed += 1

    def check_tests(self):
        """Run test baseline."""
        print("\n🧪 Running test baseline (this takes 2-3 minutes)...")
        result = subprocess.run(
            ['pytest', 'tests/', '-q', '--tb=no'],
            capture_output=True,
            text=True,
            timeout=300
        )

        if '1611 passed' in result.stdout or 'passed' in result.stdout:
            print(f"✅ Tests passing: {result.stdout.split(chr(10))[0]}")
            self.passed += 1
        else:
            print(f"❌ Test failures detected: {result.stdout[:200]}")
            self.failed += 1

    def check_code_quality(self):
        """Check ruff and mypy."""
        print("\n📋 Checking code quality...")

        # Ruff
        result = subprocess.run(
            ['ruff', 'check', 'app/', 'scripts/', '--quiet'],
            capture_output=True,
            text=True
        )

        if result.returncode == 0:
            print("✅ Ruff linting passed")
            self.passed += 1
        else:
            print(f"⚠️  Ruff issues found: {result.stdout[:100]}")
            self.warnings.append("Fix ruff issues before starting")

        # MyPy
        result = subprocess.run(
            ['mypy', 'app/', '--ignore-missing-imports', '--quiet'],
            capture_output=True,
            text=True
        )

        if result.returncode == 0:
            print("✅ MyPy type checking passed")
            self.passed += 1
        else:
            print(f"⚠️  MyPy issues found: {result.stdout[:100]}")
            self.warnings.append("Type checking issues exist")

    def check_docs(self):
        """Check documentation files exist."""
        docs = [
            'CONSOLIDATION_QUICK_REFERENCE.md',
            'CONSOLIDATION_COMPLETE.md',
            'CONSOLIDATION_PARALLEL_EXECUTION_PLAN.md',
            'CONSOLIDATION_IMPLEMENTATION_SPECS.md',
        ]

        for doc in docs:
            if Path(doc).exists():
                print(f"✅ {doc}")
                self.passed += 1
            else:
                print(f"❌ {doc} MISSING")
                self.failed += 1

    def check_branches(self):
        """Check git branches ready."""
        # Try to create phase branches
        for phase in [22, 24, 25, 26, 27]:
            branch = f"phase-{phase}"
            result = subprocess.run(
                ['git', 'branch', '-l', branch],
                capture_output=True,
                text=True
            )

            if branch in result.stdout:
                print(f"ℹ️  Branch {branch} already exists")
            else:
                print(f"⚠️  Branch {branch} needs creation")
                self.warnings.append(f"Create {branch} before starting")

    def run_all(self):
        """Run all checks."""
        print("=" * 70)
        print(f"CONSOLIDATION HEALTH CHECK - {datetime.now().strftime('%Y-%m-%d %H:%M')}")
        print("=" * 70)

        print("\n🔧 Environment:")
        self.check_python()

        print("\n📁 Git:")
        self.check_git()
        self.check_branches()

        print("\n📚 Documentation:")
        self.check_docs()

        print("\n🧪 Quality & Tests:")
        self.check_tests()
        self.check_code_quality()

        print("\n" + "=" * 70)
        print(f"RESULTS: {self.passed} ✅ | {self.failed} ❌")

        if self.warnings:
            print(f"\n⚠️  {len(self.warnings)} WARNINGS:")
            for warn in self.warnings:
                print(f"  • {warn}")

        print("=" * 70)

        if self.failed == 0:
            print("\n✅ HEALTH CHECK PASSED - Ready to execute!")
            return True
        else:
            print(f"\n❌ {self.failed} issues must be fixed before executing")
            return False

if __name__ == '__main__':
    checker = HealthCheckSuite()
    success = checker.run_all()
    sys.exit(0 if success else 1)
```

---

## Script 2: Daily Execution Dashboard

```python
#!/usr/bin/env python3
# scripts/consolidation/daily_dashboard.py

"""
Daily consolidation execution dashboard.
Run at 4 PM standup for status update.

Usage: python scripts/consolidation/daily_dashboard.py
Output: Real-time status of all phases
"""

import subprocess
from datetime import datetime
from pathlib import Path

class ExecutionDashboard:
    def __init__(self):
        self.day = datetime.now().strftime('%A')
        self.date = datetime.now().strftime('%Y-%m-%d')

    def get_test_status(self):
        """Get current test results."""
        result = subprocess.run(
            ['pytest', 'tests/', '-q', '--tb=no'],
            capture_output=True,
            text=True,
            timeout=180
        )

        # Parse output
        for line in result.stdout.split('\n'):
            if 'passed' in line:
                return line.strip()
        return "Unable to determine status"

    def get_git_status(self):
        """Get current git branch."""
        result = subprocess.run(
            ['git', 'rev-parse', '--abbrev-ref', 'HEAD'],
            capture_output=True,
            text=True
        )
        return result.stdout.strip()

    def get_phase_progress(self):
        """Estimate phase completion."""
        phases = {
            'phase-22': 'Batch Processing',
            'phase-24': 'Configuration',
            'phase-23': 'Analytics',
            'phase-25': 'Validators',
            'phase-26': 'CLI & Cache',
            'phase-27': 'Sync Systems',
            'phase-28': 'Performance',
            'phase-29': 'Test Utils',
        }

        progress = []
        for branch, name in phases.items():
            result = subprocess.run(
                ['git', 'branch', '--list', branch],
                capture_output=True,
                text=True
            )
            status = "✅ Complete" if "main" in self.get_git_status() and branch in str(result.stdout) else "📋 Pending"
            progress.append(f"  {name:20} {status}")

        return progress

    def display(self):
        """Display dashboard."""
        print("\n" + "=" * 70)
        print(f"CONSOLIDATION EXECUTION DASHBOARD")
        print(f"{self.date} ({self.day}) - 4 PM Standup")
        print("=" * 70)

        print(f"\n🌳 Git Status")
        print(f"  Current branch: {self.get_git_status()}")

        print(f"\n🧪 Test Status")
        print(f"  {self.get_test_status()}")

        print(f"\n📊 Phase Progress")
        for line in self.get_phase_progress():
            print(line)

        print("\n" + "=" * 70)
        print("💡 Tip: Check CONSOLIDATION_PARALLEL_EXECUTION_PLAN.md for schedule")
        print("=" * 70 + "\n")

if __name__ == '__main__':
    dashboard = ExecutionDashboard()
    dashboard.display()
```

---

## Script 3: Automated Import Migration

```python
#!/usr/bin/env python3
# scripts/consolidation/migrate_all_imports.py

"""
Auto-migrate imports for a phase.
Updates all references from old modules to shims.

Usage: python scripts/consolidation/migrate_all_imports.py --phase 22
"""

import re
import sys
from pathlib import Path
from typing import Dict, Tuple

class ImportMigrator:
    # Maps old imports to new shim imports
    MIGRATION_MAP = {
        22: {
            'from app.core.batchProcessor import': 'from app.core.batchingCore.shims.batchProcessor_shim import',
            'from app.core.batchExecutor import': 'from app.core.batchingCore.shims.batchExecutor_shim import',
            'from app.core.batchStats import': 'from app.core.batchingCore.shims.batchStats_shim import',
            'from app.core.batchAnalyzer import': 'from app.core.batchingCore.shims.batchAnalyzer_shim import',
        },
        24: {
            'from app.core.configCache import': 'from app.core.configManagement.shims.configCache_shim import',
            'from app.core.agentConfigCache import': 'from app.core.configManagement.shims.agentConfigCache_shim import',
            'from app.core.configUtils import': 'from app.core.configManagement.shims.configUtils_shim import',
        },
        27: {
            'from scripts.sync.syncDoc import': 'from scripts.sync.syncFramework.shims.syncDoc_shim import',
            'from scripts.sync.syncConfig import': 'from scripts.sync.syncFramework.shims.syncConfig_shim import',
            'from scripts.sync.base import': 'from scripts.sync.syncFramework.shims.base_shim import',
        }
    }

    def __init__(self, phase: int):
        self.phase = phase
        self.imports = self.MIGRATION_MAP.get(phase, {})
        self.files_modified = 0
        self.lines_changed = 0

    def migrate_file(self, filepath: Path) -> Tuple[bool, int]:
        """Migrate imports in a single file."""
        try:
            content = filepath.read_text()
            original = content

            for old, new in self.imports.items():
                if old in content:
                    content = content.replace(old, new)
                    self.lines_changed += content.count('\n') - original.count('\n')

            if content != original:
                filepath.write_text(content)
                return True, 1

            return False, 0

        except Exception as e:
            print(f"⚠️  Error in {filepath}: {e}")
            return False, 0

    def migrate_all(self) -> int:
        """Migrate all Python files."""
        print(f"\n🔄 Migrating Phase {self.phase} imports...\n")

        count = 0
        for py_file in Path('.').rglob('*.py'):
            if 'test' not in str(py_file) and '.git' not in str(py_file):
                modified, lines = self.migrate_file(py_file)
                if modified:
                    print(f"✅ {py_file}")
                    count += 1

        print(f"\n✅ Migrated {count} files")
        return count

if __name__ == '__main__':
    if len(sys.argv) < 2:
        print("Usage: python migrate_all_imports.py --phase 22")
        sys.exit(1)

    phase = int(sys.argv[2]) if '--phase' in sys.argv else 22

    migrator = ImportMigrator(phase)
    migrator.migrate_all()
```

---

## Script 4: Phase Completion Verification

```python
#!/usr/bin/env python3
# scripts/consolidation/verify_phase_complete.py

"""
Verify a phase is complete and ready to merge.

Usage: python scripts/consolidation/verify_phase_complete.py --phase 22
Checks: Tests, imports, files, metrics
"""

import subprocess
import sys
from pathlib import Path

class PhaseVerifier:
    def __init__(self, phase: int):
        self.phase = phase
        self.checks_passed = 0
        self.checks_failed = 0

    def check_tests(self):
        """Run phase-specific tests."""
        print(f"\n🧪 Running Phase {self.phase} tests...")

        result = subprocess.run(
            ['pytest', f'tests/test_phase_{self.phase}_*.py', '-v'],
            capture_output=True,
            text=True,
            timeout=120
        )

        if result.returncode == 0:
            # Count tests
            tests = result.stdout.count(' PASSED')
            print(f"✅ {tests} tests passing")
            self.checks_passed += 1
        else:
            print(f"❌ Test failures detected")
            print(result.stdout[-500:])  # Last 500 chars
            self.checks_failed += 1

    def check_no_regressions(self):
        """Verify no new test failures."""
        print(f"\n🔍 Running full test suite for regressions...")

        result = subprocess.run(
            ['pytest', 'tests/', '-x', '-q'],
            capture_output=True,
            text=True,
            timeout=300
        )

        if result.returncode == 0:
            print(f"✅ No regressions detected")
            self.checks_passed += 1
        else:
            print(f"❌ Regression detected: {result.stdout[:200]}")
            self.checks_failed += 1

    def check_imports(self):
        """Verify imports are migrated."""
        print(f"\n📦 Verifying imports migrated...")

        # Look for old imports in non-test files
        result = subprocess.run(
            ['grep', '-r', f'from app.core.batch', 'app/', '--include=*.py'],
            capture_output=True,
            text=True
        )

        if result.returncode == 1:  # Not found (good)
            print(f"✅ Old batch imports removed")
            self.checks_passed += 1
        else:
            print(f"⚠️  Old imports still present in:")
            print(result.stdout[:500])

    def check_loc_removal(self):
        """Estimate LOC removed."""
        print(f"\n📊 Checking LOC removal...")

        result = subprocess.run(
            ['git', 'diff', '--stat', f'phase-{self.phase}..main'],
            capture_output=True,
            text=True
        )

        if 'insertions' in result.stdout and 'deletions' in result.stdout:
            print(f"✅ Changes detected: {result.stdout.split(chr(10))[0]}")
            self.checks_passed += 1
        else:
            print(f"ℹ️  Phase not yet merged")

    def verify(self):
        """Run all verifications."""
        print("=" * 70)
        print(f"PHASE {self.phase} COMPLETION VERIFICATION")
        print("=" * 70)

        self.check_tests()
        self.check_no_regressions()
        self.check_imports()
        self.check_loc_removal()

        print("\n" + "=" * 70)
        print(f"RESULTS: {self.checks_passed} ✅ | {self.checks_failed} ❌")
        print("=" * 70)

        if self.checks_failed == 0:
            print(f"\n✅ Phase {self.phase} READY TO MERGE")
            return True
        else:
            print(f"\n❌ Fix {self.checks_failed} issues before merging")
            return False

if __name__ == '__main__':
    if len(sys.argv) < 2:
        print("Usage: python verify_phase_complete.py --phase 22")
        sys.exit(1)

    phase = int(sys.argv[2]) if '--phase' in sys.argv else 22

    verifier = PhaseVerifier(phase)
    success = verifier.verify()
    sys.exit(0 if success else 1)
```

---

## Script 5: Weekly Status Report

```python
#!/usr/bin/env python3
# scripts/consolidation/weekly_report.py

"""
Generate weekly consolidation status report.
Shows progress, blockers, and metrics.

Usage: python scripts/consolidation/weekly_report.py
"""

import subprocess
from datetime import datetime

class WeeklyReport:
    def __init__(self):
        self.week = datetime.now().strftime('Week of %Y-%m-%d')

    def get_commits(self):
        """Get commits this week."""
        result = subprocess.run(
            ['git', 'log', '--oneline', '--since=7 days ago'],
            capture_output=True,
            text=True
        )
        return result.stdout.count('\n')

    def get_tests(self):
        """Get test results."""
        result = subprocess.run(
            ['pytest', 'tests/', '-q', '--tb=no'],
            capture_output=True,
            text=True,
            timeout=180
        )

        for line in result.stdout.split('\n'):
            if 'passed' in line:
                return line.strip()
        return "Unknown"

    def get_branches(self):
        """Get phase branch status."""
        result = subprocess.run(
            ['git', 'branch', '-l', 'phase-*'],
            capture_output=True,
            text=True
        )
        return len(result.stdout.split('\n')) - 1

    def generate(self):
        """Generate report."""
        print("\n" + "=" * 70)
        print(f"WEEKLY CONSOLIDATION REPORT")
        print(f"{self.week}")
        print("=" * 70)

        print(f"\n📊 Metrics")
        print(f"  Commits: {self.get_commits()}")
        print(f"  Tests: {self.get_tests()}")
        print(f"  Phase branches: {self.get_branches()}")

        print(f"\n🎯 Completed This Week")
        print(f"  □ Phase 22: Batch Processing")
        print(f"  □ Phase 24: Configuration")
        print(f"  □ Phase 23: Analytics")
        print(f"  □ Phase 25: Validators")

        print(f"\n📋 Next Week")
        print(f"  □ Phase 26: CLI & Cache")
        print(f"  □ Phase 27: Sync Systems")
        print(f"  □ Phase 28: Performance")

        print(f"\n⚠️  Blockers (if any)")
        print(f"  None detected")

        print("\n" + "=" * 70 + "\n")

if __name__ == '__main__':
    report = WeeklyReport()
    report.generate()
```

---

## Using These Scripts

### Pre-Execution
```bash
# Monday 9 AM
python scripts/consolidation/health_check_complete.py

# If all GREEN → Proceed to Phase 22
```

### Daily Operations
```bash
# Every day at 4 PM standup
python scripts/consolidation/daily_dashboard.py
```

### After Each Phase
```bash
# After Phase 22 completes
python scripts/consolidation/migrate_all_imports.py --phase 22
python scripts/consolidation/verify_phase_complete.py --phase 22

# If verification passes → Merge to main
```

### Weekly
```bash
# Every Friday
python scripts/consolidation/weekly_report.py
```

---

## Script Output Examples

### Health Check
```
======================================================================
CONSOLIDATION HEALTH CHECK - 2026-09-03 09:00
======================================================================

🔧 Environment:
✅ Python 3.11

📁 Git:
✅ Git working directory clean

📚 Documentation:
✅ CONSOLIDATION_QUICK_REFERENCE.md
✅ CONSOLIDATION_COMPLETE.md
✅ CONSOLIDATION_PARALLEL_EXECUTION_PLAN.md
✅ CONSOLIDATION_IMPLEMENTATION_SPECS.md

🧪 Quality & Tests:
✅ Tests passing: 1611 passed

✅ HEALTH CHECK PASSED - Ready to execute!
======================================================================
```

### Daily Dashboard
```
======================================================================
CONSOLIDATION EXECUTION DASHBOARD
2026-09-05 (Friday) - 4 PM Standup
======================================================================

🌳 Git Status
  Current branch: phase-22

🧪 Test Status
  1611 passed in 45.23s

📊 Phase Progress
  Batch Processing     ✅ Complete
  Configuration        ✅ Complete
  Analytics            ✅ Complete
  Validators           ✅ Complete
  CLI & Cache          📋 Pending
  Sync Systems         📋 Pending
  Performance          📋 Pending
  Test Utils           📋 Pending

======================================================================
```

---

**Automation Scripts Ready ✅**
**Copy & execute during Phase 22-29 execution**
