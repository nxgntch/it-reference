# Phase 3.3: Skills Directory Reorganization

**Status**: 🟡 IN PROGRESS
**Date Started**: 2026-09-02
**Estimated Duration**: 2-3 days
**Branch**: `phase3-long-term-infrastructure`

---

## Overview

Phase 3.3 organizes 38+ flat skill directories into a functional hierarchy, making the codebase more maintainable and scalable.

### Current Structure (Flat)
```
skills/
├── analyticsEngine/
├── anomalyDetector/
├── autoScalingManager/
├── cacheManager/
├── codeGeneration/
├── codeReview/
├── costAwareLlmPipeline/
├── costDashboard/
├── costForecasting/
├── costIntelligence/
├── ... (38 total skills)
└── tenantRouter/
```

### Target Structure (Organized by Function)
```
skills/
├── core/                    # Base classes and utilities
│   ├── base.py             # (moved from skills/base.py)
│   ├── utils/
│   └── ...
│
├── cost/                    # Cost monitoring & optimization (5 skills)
│   ├── costAwareLlmPipeline/
│   ├── costDashboard/
│   ├── costForecasting/
│   ├── costIntelligence/
│   └── quotaEnforcer/
│
├── monitoring/              # Health & performance monitoring (4 skills)
│   ├── healthCheck/
│   ├── healthMonitoring/
│   ├── metricsCollector/
│   └── monitoring/
│
├── optimization/            # Performance & resource optimization (4 skills)
│   ├── autoScalingManager/
│   ├── cacheManager/
│   ├── intelligentOptimizer/
│   └── performance/
│
├── routing/                 # Request routing & orchestration (4 skills)
│   ├── geoRouterExtended/
│   ├── regionFailoverManager/
│   ├── routing/
│   └── tenantRouter/
│
├── security/                # Security & validation (3 skills)
│   ├── crossTeamSynthesis/
│   ├── tenantAudit/
│   └── codeReview/
│
├── orchestration/           # Task orchestration & planning (7 skills)
│   ├── taskIntake/
│   ├── decomposition/
│   ├── decisionMaking/
│   ├── routing/             # Duplicate? Check config
│   ├── docUpdater/
│   ├── planning/
│   └── phaseFileOrganizer/
│
├── analytics/               # Analytics & reporting (4 skills)
│   ├── analyticsEngine/
│   ├── anomalyDetector/
│   ├── rootCauseAnalyzer/
│   └── reportGenerator/
│
├── tracing/                 # Performance tracing & monitoring (2 skills)
│   ├── performanceTracing/
│   └── forecastingEngine/
│
└── integration/             # External integrations (1 skill)
    ├── integration/
    ├── dashboardConsumer/
    ├── dataLocalityOptimizer/
    └── remediation/
```

---

## Skills Mapping

### Analysis: Existing Skills & Categories

```
CURRENT SKILL INVENTORY (38 skills):

ORCHESTRATION & COORDINATION (7):
  • taskIntake - Task normalization
  • decomposition - Task breakdown
  • routing - Task routing (ORCHESTRATION, not networking)
  • decisionMaking - Result synthesis
  • docUpdater - Documentation updates
  • planning - Planning & scheduling
  • phaseFileOrganizer - Phase file management

COST & BUDGETING (5):
  • costAwareLlmPipeline - Model selection & routing
  • costDashboard - Cost display
  • costForecasting - Cost prediction
  • costIntelligence - Cost analysis
  • quotaEnforcer - Budget enforcement

MONITORING & HEALTH (4):
  • healthCheck - System health
  • healthMonitoring - Health monitoring
  • metricsCollector - Metrics collection
  • monitoring - General monitoring

OPTIMIZATION (4):
  • autoScalingManager - Auto-scaling
  • cacheManager - Caching optimization
  • intelligentOptimizer - Optimization engine
  • performance - Performance optimization

ANALYTICS (4):
  • analyticsEngine - Analytics processing
  • anomalyDetector - Anomaly detection
  • rootCauseAnalyzer - Root cause analysis
  • reportGenerator - Report generation

ROUTING & NETWORKING (4):
  • geoRouterExtended - Geographic routing
  • regionFailoverManager - Failover management
  • tenantRouter - Tenant-aware routing
  • dataLocalityOptimizer - Data locality

SECURITY & AUDIT (3):
  • crossTeamSynthesis - Team synthesis (or security related?)
  • tenantAudit - Audit logs
  • codeReview - Code quality

TRACING & DIAGNOSTICS (2):
  • performanceTracing - Performance traces
  • forecastingEngine - Forecasting

OTHER (1):
  • integration - Integration utilities
  • dashboardConsumer - Dashboard consumer
  • remediation - Issue remediation
  • cost - Cost utilities (unregistered)
  • monitoring - Monitoring utilities (unregistered, duplicate?)
  • performance - Performance utilities (unregistered, duplicate?)
  • remediation - Remediation utilities (unregistered, duplicate?)
```

---

## Reorganization Strategy

### Phase 3.3a: Planning & Mapping (0.5 hours)
- [x] Create skills inventory
- [x] Develop category schema
- [x] Create mapping of skills → new locations
- [ ] Review for dependencies
- [ ] Prepare import update list

### Phase 3.3b: Directory Structure (1 hour)
- [ ] Create new category directories
- [ ] Verify no naming conflicts
- [ ] Plan for shared utilities (core/)
- [ ] Test directory creation

### Phase 3.3c: Skill Migration (4 hours)
- [ ] Move skills to new locations
- [ ] Update __init__.py imports
- [ ] Update internal skill references
- [ ] Run validation checks
- [ ] Test skill registration

### Phase 3.3d: Config & References (2 hours)
- [ ] Update config/skills.yaml paths (if needed)
- [ ] Update internal import statements
- [ ] Update documentation links
- [ ] Update skill discovery logic
- [ ] Run pre-commit checks

### Phase 3.3e: Testing & Validation (1 hour)
- [ ] Run skill registry validator
- [ ] Run full test suite
- [ ] Test skill invocation
- [ ] Verify no broken imports
- [ ] Document changes

---

## Implementation Plan

### Step 1: Create Directory Structure
```bash
mkdir -p skills/core
mkdir -p skills/cost
mkdir -p skills/monitoring
mkdir -p skills/optimization
mkdir -p skills/routing
mkdir -p skills/security
mkdir -p skills/orchestration
mkdir -p skills/analytics
mkdir -p skills/tracing
mkdir -p skills/integration
```

### Step 2: Move Skills
```bash
# COST (5 skills)
mv skills/costAwareLlmPipeline skills/cost/
mv skills/costDashboard skills/cost/
mv skills/costForecasting skills/cost/
mv skills/costIntelligence skills/cost/
mv skills/quotaEnforcer skills/cost/

# MONITORING (4 skills)
mv skills/healthCheck skills/monitoring/
mv skills/healthMonitoring skills/monitoring/
mv skills/metricsCollector skills/monitoring/
mv skills/monitoring skills/monitoring/core  # Handle duplicate

# ... and so on for other categories
```

### Step 3: Update Imports

Current import pattern:
```python
from skills.costDashboard import CostDashboard
```

New import pattern:
```python
from skills.cost.costDashboard import CostDashboard
```

Files to update:
- `app/core/skillRegistry.py` - Skill loader
- `app/agents/*.py` - Agent skill definitions
- `config/skills.yaml` - Skill registration (if paths change)
- All skill `__init__.py` files - Internal imports

### Step 4: Update Configuration

Verify `config/skills.yaml` doesn't hardcode paths:
```yaml
# Should NOT have paths like:
#   path: skills/costDashboard

# Should only have:
  id: costDashboard
  agent: director
```

### Step 5: Validation

Run validators:
```bash
python scripts/validation/validate_skill_registry.py
pytest tests/ --cov=skills
```

---

## Risk Assessment

| Risk | Probability | Impact | Mitigation |
|------|---|---|---|
| Import failures | High | Critical | Comprehensive find/replace, test suite |
| Circular imports | Medium | High | Review import graph before move |
| Duplicate names | Low | High | Check for naming conflicts first |
| Config path issues | Medium | Medium | Config uses IDs, not paths (verify) |
| Skill discovery breaks | Medium | Medium | Test skill loading after moves |

---

## Success Criteria

- ✅ All 38 skills organized into 10 categories
- ✅ No orphaned skill directories
- ✅ All imports updated and working
- ✅ Skill registry validator passes
- ✅ All tests passing (≥85% coverage)
- ✅ No circular import dependencies
- ✅ Documentation updated with new structure
- ✅ Skill discovery still works
- ✅ Agent skill invocation still works

---

## Files to Update

### Python Imports
- [ ] `app/core/skillRegistry.py` - Main skill loader
- [ ] `app/agents/director.py` - Director agent skill assignments
- [ ] `app/agents/engineer.py` - Engineer agent skill assignments
- [ ] `app/agents/researcher.py` - Researcher agent skill assignments
- [ ] `app/agents/analyst.py` - Analyst agent skill assignments
- [ ] All individual skill `__init__.py` files
- [ ] All skill-to-skill cross-references

### Configuration
- [ ] `config/skills.yaml` - Verify no path dependencies
- [ ] `.claude/MCP_TOOLS_MANIFEST.md` - Update tool paths (if any)

### Documentation
- [ ] `docs/guides/reference/file-organization.md` - Update structure diagram
- [ ] `skills/DEPENDENCIES.md` - Update with new paths
- [ ] `skills/README.md` - Update structure
- [ ] Phase 3.3 implementation log

---

## Testing Strategy

### Unit Tests
```bash
pytest tests/ -m "skills" --tb=short
```

### Integration Tests
```bash
pytest tests/ -m "integration" --tb=short
```

### Skill Registry Validation
```bash
python scripts/validation/validate_skill_registry.py --strict
```

### Manual Testing
1. Start app: `python -m uvicorn app.main:app`
2. Test skill invocation: `curl http://localhost:8000/invoke/taskIntake`
3. Verify all agents can load skills
4. Check for import errors in logs

---

## Timeline

```
📅 ESTIMATED SCHEDULE

Day 1 (Sep 03):
  • Morning: Create directory structure (1h)
  • Mid: Move 20+ skills (2h)
  • Afternoon: Begin import updates (2h)

Day 2 (Sep 04):
  • Morning: Complete import updates (3h)
  • Afternoon: Run validators and tests (2h)
  • Evening: Fix issues from test run (2h)

Day 3 (Sep 05):
  • Morning: Final validation (1h)
  • Afternoon: Documentation updates (1h)
  • Close-out (0.5h)

Total Estimated: 15-17 hours
```

---

## Dependencies

- ✅ Phase 3.1 complete (config validation)
- ✅ Phase 3.2 complete (skill registry validator)
- ⚠️ No direct code dependencies (can be done independently)
- ⚠️ Must be done before Phase 3.4 (docs refactoring references this structure)

---

## Rollback Plan

If issues occur, rollback is simple (git handles directory moves):

```bash
git reset --hard <commit-before-moves>
```

Version control tracks all moves, so rollback is safe.

---

## Next Steps

1. **Immediately**:
   - [ ] Review this plan
   - [ ] Identify any missing skills or categories
   - [ ] Check for special cases (shared utilities, etc.)

2. **Then**:
   - [ ] Create directory structure
   - [ ] Start moving skills (can do in batches)
   - [ ] Update imports incrementally
   - [ ] Test after each batch

3. **Finally**:
   - [ ] Run full validation
   - [ ] Document all changes
   - [ ] Commit with clear message
   - [ ] Update Phase 3.3 implementation log

---

## Resources

- **Phase 3 Plan**: `docs/work/current/PHASE_3_KICKOFF_PLAN.md`
- **Skill Registry Validator**: `scripts/validation/validate_skill_registry.py`
- **Skill Inventory**: `config/skills.yaml`
- **File Organization**: `docs/guides/reference/file-organization.md`

---

**Document Created**: 2026-09-02
**Phase 3.3 Status**: 🟡 PLANNING
**Ready to Proceed**: 🟡 PENDING REVIEW
