# Consolidation Implementation Specifications

**Document Type**: Detailed phase-by-phase implementation guide with code templates
**Audience**: Developers executing Phases 22-29
**Status**: Complete specifications ready for immediate coding

---

## Phase 22: Batch Processing Implementation Spec

### Objective
Consolidate 9 batch modules (2,437 LOC) into unified framework using Strategy Factory pattern.

### Directory Structure
```
app/core/batchingCore/
├── __init__.py
├── framework.py              (200 LOC - main framework)
├── components/
│   ├── __init__.py
│   ├── analyzer_strategy.py  (80 LOC)
│   ├── optimizer_strategy.py (100 LOC)
│   ├── queue_strategy.py     (60 LOC)
│   └── executor_engine.py    (120 LOC)
├── shims/
│   ├── __init__.py
│   ├── batchProcessor_shim.py
│   ├── batchExecutor_shim.py
│   ├── batchStats_shim.py
│   ├── batchAnalyzer_shim.py
│   ├── batchExecution_shim.py
│   ├── batchQueueManager_shim.py
│   ├── batchSizeOptimizer_shim.py
│   └── batchFormationCache_shim.py
└── tests/
    ├── test_framework.py
    ├── test_strategies.py
    └── test_shims.py
```

### Framework Template
```python
# app/core/batchingCore/framework.py

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Dict, List, Optional, Any
from enum import Enum

class BatchStrategy(ABC):
    """Base strategy for batch operations."""

    @abstractmethod
    def analyze(self, tasks: List[Any]) -> Dict[str, Any]:
        """Analyze batch characteristics."""
        pass

class AnalyzerStrategy(BatchStrategy):
    """Analyze batches for optimization."""
    def analyze(self, tasks: List[Any]) -> Dict[str, Any]:
        return {
            'total_tasks': len(tasks),
            'estimated_cost': sum(t.get('cost', 0) for t in tasks),
            'complexity': 'medium'  # Placeholder
        }

class OptimizerStrategy(BatchStrategy):
    """Optimize batch size and composition."""
    def analyze(self, tasks: List[Any]) -> Dict[str, Any]:
        return {
            'optimal_size': max(2, len(tasks) // 3),
            'estimated_savings': len(tasks) * 0.15
        }

class BatchingFramework:
    """Unified batching framework with pluggable strategies."""

    def __init__(self):
        self.analyzer = AnalyzerStrategy()
        self.optimizer = OptimizerStrategy()
        self.metrics = BatchMetrics()

    def process_batch(self, tasks: List[Any]) -> Dict[str, Any]:
        """Process batch with strategies."""
        analysis = self.analyzer.analyze(tasks)
        optimization = self.optimizer.analyze(tasks)

        result = {
            'analysis': analysis,
            'optimization': optimization,
            'success': True
        }

        self.metrics.record(result)
        return result

@dataclass
class BatchMetrics:
    """Unified batch metrics."""
    total_processed: int = 0
    total_cost: float = 0.0
    success_count: int = 0
    failure_count: int = 0
```

### Shim Template (Example: batchProcessor_shim.py)
```python
# app/core/batchingCore/shims/batchProcessor_shim.py
"""
Backward compatibility shim for batchProcessor.py

This module maintains API compatibility with old batchProcessor imports
while delegating to the new BatchingFramework.

Usage (old code continues to work):
    from app.core.batchProcessor import BatchProcessor
    from app.core.batchProcessor import Batch, BatchTask

All calls are forwarded to the new framework.
"""

# Re-export from old location for compatibility
from app.core.batchingCore.framework import BatchingFramework

# Maintain old class names for backward compatibility
class BatchProcessor(BatchingFramework):
    """Backward-compatible BatchProcessor (delegates to framework)."""
    pass

# Re-export dataclasses from old modules
from app.core.batchProcessor import Batch, BatchTask

__all__ = ['BatchProcessor', 'Batch', 'BatchTask']
```

### Migration Script
```python
# scripts/consolidation/migrate_phase22_batch.py
"""
Auto-migration script for Phase 22: Batch Processing

Updates imports across codebase from old modules to shims/framework.
"""

import re
from pathlib import Path

REPLACEMENTS = {
    'from app.core.batchProcessor import': 'from app.core.batchingCore.shims.batchProcessor_shim import',
    'from app.core.batchExecutor import': 'from app.core.batchingCore.shims.batchExecutor_shim import',
    'from app.core.batchStats import': 'from app.core.batchingCore.shims.batchStats_shim import',
    'from app.core.batchAnalyzer import': 'from app.core.batchingCore.shims.batchAnalyzer_shim import',
}

def migrate_imports(source_file: Path) -> int:
    """Migrate imports in a single file."""
    content = source_file.read_text()
    original = content

    for old, new in REPLACEMENTS.items():
        content = content.replace(old, new)

    if content != original:
        source_file.write_text(content)
        return 1
    return 0

def main():
    """Migrate all Python files in app/ and scripts/."""
    count = 0
    for py_file in Path('.').rglob('*.py'):
        if 'test' not in str(py_file):
            count += migrate_imports(py_file)

    print(f"✅ Migrated {count} files")
    print("Next: Run pytest to verify")

if __name__ == '__main__':
    main()
```

### Testing Strategy
```python
# tests/test_phase22_batch_framework.py

import pytest
from app.core.batchingCore.framework import (
    BatchingFramework, AnalyzerStrategy, BatchMetrics
)
from app.core.batchingCore.shims.batchProcessor_shim import BatchProcessor

def test_framework_basic():
    """Test framework basic operation."""
    framework = BatchingFramework()
    tasks = [
        {'task_id': '1', 'cost': 10.0},
        {'task_id': '2', 'cost': 15.0},
    ]

    result = framework.process_batch(tasks)

    assert result['success'] is True
    assert result['analysis']['total_tasks'] == 2
    assert result['analysis']['estimated_cost'] == 25.0

def test_shim_compatibility():
    """Test backward compatibility shim."""
    processor = BatchProcessor()
    assert isinstance(processor, BatchingFramework)

    # Old code should still work
    from app.core.batchProcessor import BatchTask
    task = BatchTask(
        taskId='test1',
        agentId='agent1',
        description='Test',
        complexity='low',
        estimatedCost=10.0,
        model='gpt-4'
    )
    assert task.taskId == 'test1'

def test_metrics_tracking():
    """Test metrics collection."""
    framework = BatchingFramework()
    tasks = [{'task_id': f'{i}'} for i in range(5)]

    framework.process_batch(tasks)

    assert framework.metrics.total_processed == 0  # Initial state
    # Metrics updated via framework.metrics.record()
```

### Validation Checklist (Phase 22)
```
□ Create directory structure
□ Implement framework.py (200 LOC)
□ Implement component strategies (240 LOC)
□ Create 8 backward-compat shims (200 LOC)
□ Create migration script
□ Run migration: python scripts/consolidation/migrate_phase22_batch.py
□ Verify imports updated (expect 40+ files modified)
□ Run test suite: pytest tests/ -v
  Expected: 150+ batch tests passing
□ Check no regressions: pytest --tb=short
  Expected: All pass, 0 failed
□ Verify performance: benchmark critical paths
  Expected: < ±5% variance
□ Document changes: Create PHASE_22_MIGRATION.md
□ Commit with message: "feat(consolidation): batch processing framework - phase 22"
```

---

## Phase 24: Configuration Implementation Spec

### Objective
Unify 4 config modules (929 LOC) into ConfigurationManager with consolidated caching.

### New Files
```
app/core/configManagement/
├── __init__.py
├── manager.py              (250 LOC - unified manager)
├── cache.py                (100 LOC - uses cacheFramework)
├── exceptions.py           (50 LOC - config-specific errors)
└── shims/
    ├── configCache_shim.py
    ├── agentConfigCache_shim.py
    └── configUtils_shim.py
```

### Manager Implementation Template
```python
# app/core/configManagement/manager.py

from pathlib import Path
from typing import Dict, Any, Optional
import yaml

class ConfigurationManager:
    """Unified configuration management."""

    def __init__(self, config_path: Optional[Path] = None):
        self.config_path = config_path or Path('config/unified.yaml')
        self._cache = {}
        self._load_config()

    def _load_config(self):
        """Load configuration from YAML."""
        try:
            with open(self.config_path, 'r') as f:
                self._cache = yaml.safe_load(f) or {}
        except FileNotFoundError:
            self._cache = {}

    def get_agent_config(self, agent_id: str) -> Dict[str, Any]:
        """Get agent-specific configuration."""
        agents = self._cache.get('agents', {})
        return agents.get(agent_id, {})

    def get_section(self, section: str) -> Dict[str, Any]:
        """Get config section."""
        return self._cache.get(section, {})

    def validate(self) -> bool:
        """Validate configuration consistency."""
        # Validation logic
        return True

# Global instance
_manager: Optional[ConfigurationManager] = None

def get_config_manager() -> ConfigurationManager:
    """Get or create singleton configuration manager."""
    global _manager
    if _manager is None:
        _manager = ConfigurationManager()
    return _manager
```

### Migration Steps
1. Create configManagement directory
2. Implement manager.py with cache integration
3. Create shims for old modules
4. Run migration script to update imports
5. Test all config loading paths
6. Verify agent-specific configs work

---

## Phase 25: Validators Implementation Spec

### Objective
Enhance BaseValidator and organize 12 validators into domain groups.

### New Structure
```
scripts/validate/
├── base.py (extend from 74 to 250 LOC)
│   ├── BaseValidator (enhanced)
│   ├── ResultFormatter
│   ├── SeverityLevel
│   └── StandardResult
├── validators/
│   ├── __init__.py
│   ├── config_validators.py
│   ├── doc_validators.py
│   ├── security_validators.py
│   └── skill_validators.py
└── orchestrator.py (batch validation)
```

### Enhanced BaseValidator Template
```python
# scripts/validate/base.py (extended)

from abc import ABC, abstractmethod
from dataclasses import dataclass
from enum import Enum
from typing import List, Dict, Any
from datetime import datetime

class SeverityLevel(Enum):
    """Standard severity levels."""
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"

@dataclass
class StandardResult:
    """Standardized validation result."""
    title: str
    severity: SeverityLevel
    description: str
    file: Optional[str] = None
    line: Optional[int] = None
    details: Dict[str, Any] = None

class ResultFormatter:
    """Unified result formatting for all validators."""

    @staticmethod
    def format_results(findings: List[StandardResult],
                      title: str = "Validation Results") -> Dict:
        """Format findings into standard output."""
        severity_counts = {
            'critical': 0,
            'high': 0,
            'medium': 0,
            'low': 0,
            'info': 0,
        }

        for finding in findings:
            severity_counts[finding.severity.value] += 1

        return {
            'title': title,
            'timestamp': datetime.now().isoformat(),
            'total_findings': len(findings),
            'by_severity': severity_counts,
            'findings': [f.__dict__ for f in findings]
        }

class BaseValidator(ABC):
    """Enhanced base validator with standard patterns."""

    def __init__(self):
        self.formatter = ResultFormatter()
        self.findings: List[StandardResult] = []

    @abstractmethod
    def validate(self) -> List[StandardResult]:
        """Run validation. Override in subclass."""
        pass

    def get_results(self) -> Dict:
        """Get formatted results."""
        return self.formatter.format_results(self.findings)
```

### Validator Groups Template
```python
# scripts/validate/validators/config_validators.py

from scripts.validate.base import BaseValidator, StandardResult, SeverityLevel
from pathlib import Path
import yaml

class ConfigValidator(BaseValidator):
    """Validate YAML configuration syntax."""

    def __init__(self, config_path: Path = None):
        super().__init__()
        self.config_path = config_path or Path('config/unified.yaml')

    def validate(self) -> List[StandardResult]:
        """Check YAML syntax and structure."""
        try:
            with open(self.config_path) as f:
                yaml.safe_load(f)
        except yaml.YAMLError as e:
            self.findings.append(StandardResult(
                title="Invalid YAML syntax",
                severity=SeverityLevel.CRITICAL,
                description=f"YAML parsing error: {e}",
                file=str(self.config_path)
            ))

        return self.findings

class ConfigConsistencyValidator(BaseValidator):
    """Validate configuration consistency."""

    def validate(self) -> List[StandardResult]:
        # Implementation
        return self.findings
```

---

## Phase 27: Sync Systems Implementation Spec

### Objective
Create SyncFramework + RepoSyncOrchestrator + unified GitOperations.

### Directory Structure
```
scripts/sync/syncFramework/
├── __init__.py
├── framework.py           (150 LOC)
├── strategies/
│   ├── __init__.py
│   ├── base_strategy.py   (80 LOC)
│   ├── doc_strategy.py    (60 LOC)
│   ├── config_strategy.py (60 LOC)
│   ├── mobile_strategy.py (50 LOC)
│   └── archive_strategy.py(50 LOC)
├── git_operations.py      (100 LOC)
└── orchestrator.py        (150 LOC)

scripts/sync/repos/repoSync/
├── __init__.py
├── orchestrator.py        (200 LOC)
├── handlers/
│   ├── __init__.py
│   ├── nxgntch_handler.py (100 LOC)
│   ├── logs_handler.py    (100 LOC)
│   ├── archive_handler.py (100 LOC)
│   └── reference_handler.py(100 LOC)
└── shims/
    ├── daily_sync_shim.py
    ├── logs_sync_shim.py
    └── (3 more shims)
```

### GitOperations Template
```python
# scripts/sync/syncFramework/git_operations.py

import subprocess
from pathlib import Path
from typing import List, Tuple, Optional
from dataclasses import dataclass

@dataclass
class GitResult:
    """Git operation result."""
    returncode: int
    stdout: str
    stderr: str

    @property
    def success(self) -> bool:
        return self.returncode == 0

class GitOperations:
    """Unified git operations - single source of truth."""

    @staticmethod
    def run(cmd: List[str], repo_path: Path,
            timeout: int = 30) -> GitResult:
        """Execute git command."""
        try:
            result = subprocess.run(
                ["git"] + cmd,
                cwd=repo_path,
                capture_output=True,
                text=True,
                timeout=timeout
            )
            return GitResult(
                returncode=result.returncode,
                stdout=result.stdout.strip(),
                stderr=result.stderr.strip()
            )
        except subprocess.TimeoutExpired:
            return GitResult(1, "", "Command timed out")

    @staticmethod
    def status(repo_path: Path) -> GitResult:
        """Check repo status."""
        return GitOperations.run(["status", "--porcelain"], repo_path)

    @staticmethod
    def commit(repo_path: Path, message: str) -> GitResult:
        """Commit changes."""
        return GitOperations.run(
            ["commit", "-m", message],
            repo_path
        )

    @staticmethod
    def push(repo_path: Path, branch: str = "main") -> GitResult:
        """Push to remote."""
        return GitOperations.run(["push", "origin", branch], repo_path)

# Usage replaces 45+ subprocess.run() calls across codebase
```

### SyncFramework Template
```python
# scripts/sync/syncFramework/framework.py

from abc import ABC, abstractmethod
from typing import Dict, Any, List
from pathlib import Path

class SyncStrategy(ABC):
    """Base sync strategy."""

    @abstractmethod
    def sync(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """Execute sync operation."""
        pass

class DocSyncStrategy(SyncStrategy):
    """Sync documentation."""
    def sync(self, config: Dict[str, Any]) -> Dict[str, Any]:
        # Implementation
        return {'success': True, 'items': 0}

class SyncFramework:
    """Unified sync framework."""

    def __init__(self):
        self.strategies: Dict[str, SyncStrategy] = {}

    def register_strategy(self, name: str, strategy: SyncStrategy):
        """Register a sync strategy."""
        self.strategies[name] = strategy

    def execute_sync(self, sync_type: str,
                    config: Dict[str, Any]) -> Dict[str, Any]:
        """Execute registered sync."""
        strategy = self.strategies.get(sync_type)
        if not strategy:
            return {'success': False, 'error': f'Unknown sync: {sync_type}'}

        return strategy.sync(config)
```

---

## Meta-Pattern Implementation: CommonArguments

### Template
```python
# scripts/utils/cli_common.py

import argparse
from typing import List

class CommonArguments:
    """Centralized CLI argument definitions."""

    # Standard argument definitions
    VERBOSE = {
        'action': 'store_true',
        'help': 'Enable verbose output'
    }

    DRY_RUN = {
        'action': 'store_true',
        'help': 'Show what would happen without making changes'
    }

    CONFIG = {
        'type': str,
        'default': 'config/unified.yaml',
        'help': 'Path to configuration file'
    }

    FORMAT = {
        'choices': ['json', 'yaml', 'text'],
        'default': 'text',
        'help': 'Output format'
    }

    OUTPUT = {
        'type': str,
        'help': 'Output file path (default: stdout)'
    }

    @staticmethod
    def apply_to_parser(parser: argparse.ArgumentParser,
                       *arg_names: str) -> None:
        """Apply standard arguments to parser."""
        args_map = {
            'verbose': ('--verbose', CommonArguments.VERBOSE),
            'dry_run': ('--dry-run', CommonArguments.DRY_RUN),
            'config': ('--config', CommonArguments.CONFIG),
            'format': ('--format', CommonArguments.FORMAT),
            'output': ('--output', CommonArguments.OUTPUT),
        }

        for arg_name in arg_names:
            if arg_name in args_map:
                flag, config = args_map[arg_name]
                parser.add_argument(flag, **config)

# Usage (replaces 30+ add_argument calls):
# parser = argparse.ArgumentParser()
# CommonArguments.apply_to_parser(parser, 'verbose', 'dry_run', 'config')
```

---

## Pre-Execution Validation Checklist

### Week 1 Pre-Flight (Monday Morning)

**Code Review**:
- [ ] All developers reviewed Phase 22-26 specs
- [ ] All developers reviewed dependency graph
- [ ] Team discussed any ambiguities
- [ ] Git branches created for each phase

**Environment Setup**:
- [ ] All 3 developers have latest main branch
- [ ] All have clean working directory
- [ ] pytest running with 100% pass rate
- [ ] Virtual environments configured identically

**Process Setup**:
- [ ] Slack/Discord channel created for team
- [ ] Standup meeting scheduled (10 AM & 4 PM)
- [ ] Git merge process documented
- [ ] Rollback procedure documented

**Dry Run**:
- [ ] Try migration script on test repo
- [ ] Verify shim import paths work
- [ ] Confirm git branch/merge workflow

---

## Post-Phase Verification Procedures

### After Each Phase (15 min process)

```
1. Developer runs tests (5 min):
   pytest tests/test_phase_XX_*.py -v
   Expected: All pass, 0 failures

2. Lead reviews code (5 min):
   git diff main..phase-XX
   Check: Shims created, imports updated, LOC count

3. All run regression test (3 min):
   pytest tests/ -x (stop on first failure)
   Expected: No new failures

4. Merge to main:
   git checkout main
   git merge phase-XX --no-ff -m "phase XX complete"
   git push origin main
```

### End-of-Week 1 Verification (Day 5)

```
□ All Phases 22, 24, 25 merged to main
□ pytest tests/ --cov=app --cov=scripts
  Expected: ≥85% coverage, 1,611+ tests passing
□ Performance benchmark (critical paths)
  Expected: < ±5% variance from baseline
□ Code quality check: ruff check app/ scripts/
  Expected: 0 errors
□ Type check: mypy app/
  Expected: 0 errors
□ LOC removal verification:
  Expected: ~4,100 LOC removed
```

---

## Metrics Dashboard (Daily Tracking)

### Track Per Phase
```
Phase | Date | Dev | Status | Tests | LOC | Issues
------|------|-----|--------|-------|-----|--------
22    | D2-3 | B   | ✅ Done| 150+  | -1.4k | None
24    | D2   | L   | ✅ Done| 40+   | -400  | None
23    | D4   | B   | ✅ Done| 85+   | -1.2k | None
25    | D4   | L   | ✅ Done| 145+  | -1.5k | None
26    | D6   | L   | ✅ Done| 100+  | -800  | None
27    | D6   | C   | ✅ Done| 120+  | -1.8k | None
28    | D8   | B   | ✅ Done| 110+  | -1.2k | None
29    | D8   | L   | ✅ Done| 90+   | -400  | None
```

### Aggregate Metrics
```
Day 1: 0 LOC removed, 0 frameworks
Day 2-3: 1,400 LOC removed, 1 framework (Batch)
Day 4: 2,500 LOC removed, 2 frameworks (Add Analytics)
Day 5: 4,100 LOC removed, 4 frameworks
Day 6: 5,900 LOC removed, 5 frameworks
Day 7: 7,100 LOC removed, 6 frameworks
Day 8: 8,300 LOC removed, 7 frameworks
Day 9-10: 9,300+ LOC removed, 13 frameworks ✅
```

---

## Documentation Templates

### Phase Completion Report Template
```markdown
# Phase XX Completion Report

## Summary
- **Consolidations**: X modules merged
- **LOC Removed**: -XXX LOC
- **New Framework**: Framework name
- **Execution Time**: X hours
- **Status**: ✅ COMPLETE

## Changes Made
- Created: X new files
- Modified: X files
- Deleted: X files (via shims)

## Testing
- Tests passing: XXX+
- Coverage: ≥85%
- Regressions: 0

## Lessons Learned
- Key learnings
- Improvements for next phase

## Sign-off
- Developer: [Name]
- Date: [Date]
- Lead approval: [Name]
```

### Migration Guide Template
```markdown
# Phase XX Migration Guide

## For End Users
No action required. All changes are backward compatible.

## For Developers
If you import from old modules, imports continue to work via shims.

### Old Code (Still Works)
```python
from app.core.oldModule import OldClass
```

### New Code (Preferred)
```python
from app.core.newFramework.shims.oldModule_shim import OldClass
```

## Migration Path
1. Old imports work via shims (no change needed)
2. Gradually migrate to new framework imports
3. Eventually remove shim layer

## Questions?
See: docs/guides/consolidation/phase-XX-guide.md
```

---

## Execution Command Checklists

### Phase 22 (Batch Processing)
```bash
# 1. Create structure
mkdir -p app/core/batchingCore/{components,shims,tests}

# 2. Implement framework
# Edit: app/core/batchingCore/framework.py (use template)

# 3. Create shims
# Edit: app/core/batchingCore/shims/*.py (use shim template)

# 4. Create tests
# Edit: tests/test_phase22_batch_framework.py

# 5. Migrate imports
python scripts/consolidation/migrate_phase22_batch.py

# 6. Verify
pytest tests/test_phase22_batch_framework.py -v
pytest tests/ -x  # No new failures

# 7. Commit
git add -A
git commit -m "feat(consolidation): batch processing framework - phase 22"

# 8. Merge
git checkout main && git merge phase-22 --no-ff
```

### Phase 24 (Configuration)
```bash
# 1. Create structure
mkdir -p app/core/configManagement/{shims}

# 2. Implement manager
# Edit: app/core/configManagement/manager.py (use template)

# 3. Create shims
# Edit: app/core/configManagement/shims/*.py

# 4. Migrate imports
python scripts/consolidation/migrate_phase24_config.py

# 5. Test
pytest tests/test_phase24_config_framework.py -v

# 6. Commit & merge
git add -A && git commit -m "feat(consolidation): configuration manager - phase 24"
git checkout main && git merge phase-24 --no-ff
```

---

## Troubleshooting Guide

### Problem: Circular Import
**Symptom**: ImportError when importing framework

**Solution**:
```python
# Move common definitions to separate file
# __init__.py imports from framework.py
# Then from module import class works
```

### Problem: Test Fixtures Incompatible
**Symptom**: Old tests fail with new framework

**Solution**:
```python
# Create fixture adapter in conftest.py
@pytest.fixture
def old_style_batch():
    """Compatibility fixture for old tests."""
    from app.core.batchingCore.shims import batchProcessor_shim
    return batchProcessor_shim.BatchProcessor()
```

### Problem: Performance Regression
**Symptom**: Tests pass but operations slower

**Solution**:
1. Profile with: `python -m cProfile -s cumtime script.py`
2. Identify bottleneck
3. Optimize framework component
4. Rebench to verify improvement

### Problem: Merge Conflicts
**Symptom**: git merge reports conflicts

**Solution**:
```bash
git merge --abort  # Start over
git rebase main    # Rebase instead of merge
# Or manually resolve conflicts in editor
```

---

**Implementation Specs Complete ✅**
**Ready for Phase 22 Execution**
**All Templates & Procedures Provided**
