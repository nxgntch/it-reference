# Phase 2: Test Migration Guide

## What Changed?

Heavy fixtures now use `autouse=False`, meaning they won't automatically initialize for every test. Instead, they're only initialized when:

1. **Explicitly requested as parameter**: `def testSomething(cacheFactory):`
2. **As a dependency**: Another fixture depends on it
3. **Explicitly requested**: Using `request.getfixturevalue()`

## For Test Authors

### Before (still works)
```python
def testCacheFactory(cacheFactory):
    # cacheFactory auto-initialized when needed
    result = cacheFactory.createCache()
    assert result is not None
```

### After (same code works)
```python
def testCacheFactory(cacheFactory):
    # cacheFactory still initialized when requested
    result = cacheFactory.createCache()
    assert result is not None
```

**No changes needed to test code!**

## For New Tests

Use heavy fixtures only when you need them:

```python
# ✓ Good: Only loads factory when test uses it
def testWithFactory(cacheFactory):
    return cacheFactory.create()

# ✓ Good: Light fixtures always loaded
def testWithConfig(tempConfigDir):
    return tempConfigDir / "agents.yaml"

# ✓ Good: Mixed heavy and light
def testBothFixtures(cacheFactory, tempConfigDir):
    cache = cacheFactory.create()
    config = tempConfigDir / "agents.yaml"
    return cache, config
```

## Lazy-Loading Benefits

| Aspect | Before | After |
|--------|--------|-------|
| Heavy fixtures always loaded | Yes | Only when used |
| Memory usage | Higher | Lower |
| Context window | Larger | Smaller |
| Test startup time | Slower | Faster |
| Code changes needed | None | None |

## Testing the Changes

Run the full test suite to verify everything still works:

```bash
# Run all tests
pytest tests/ -v

# Run only tests using heavy fixtures
pytest tests/ -k "Cache or Factory or Mock" -v

# Run light-fixture tests only
pytest tests/ -k "not Cache and not Factory and not Mock" -v
```

## Questions?

If a test fails after Phase 2, it's likely because:

1. **Missing fixture parameter**: Add it to test signature
2. **Fixture dependency chain broken**: Verify dependent fixtures exist
3. **Fixture scope mismatch**: Check fixture scope vs. usage

All 2576 tests should pass. If not, investigate the specific failure.
