#!/bin/bash
# Phase 20 Script 5: Master Orchestrator
#
# Orchestrates full Phase 20 consolidation across all categories.
# Runs all scripts in proper sequence with validation gates.
#
# Usage:
#   bash scripts/phase20/05-orchestrate.sh [--category monitoring] [--dry-run] [--skip-tests]

set -euo pipefail

# Configuration
PHASE20_DIR="scripts/phase20"
SKILLS_ROOT="skills"
TESTS_ROOT="tests"
PATTERN_REPORT="$PHASE20_DIR/patterns-report.json"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Default options
CATEGORY=""
DRY_RUN=false
SKIP_TESTS=false
PILOT_MODE=false

# Parse arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --category)
            CATEGORY="$2"
            shift 2
            ;;
        --dry-run)
            DRY_RUN=true
            shift
            ;;
        --skip-tests)
            SKIP_TESTS=true
            shift
            ;;
        --pilot)
            PILOT_MODE=true
            CATEGORY="monitoring"
            shift
            ;;
        *)
            echo "Unknown option: $1"
            exit 1
            ;;
    esac
done

# Logging functions
log_step() {
    echo -e "${BLUE}=== $1 ===${NC}"
}

log_success() {
    echo -e "${GREEN}✓ $1${NC}"
}

log_error() {
    echo -e "${RED}✗ $1${NC}"
}

log_warning() {
    echo -e "${YELLOW}⚠ $1${NC}"
}

# Main orchestration
main() {
    echo -e "${BLUE}╔════════════════════════════════════════════════════════╗${NC}"
    echo -e "${BLUE}║   Phase 20: Duplication Consolidation Orchestrator   ║${NC}"
    echo -e "${BLUE}╚════════════════════════════════════════════════════════╝${NC}"
    echo ""

    # Parse mode
    if [ -n "$CATEGORY" ]; then
        log_step "CATEGORY MODE: $CATEGORY"
    else
        log_step "FULL CONSOLIDATION MODE"
    fi

    if [ "$DRY_RUN" = true ]; then
        log_warning "DRY RUN MODE - No files will be modified"
    fi

    echo ""

    # Phase 1: Pattern Analysis
    log_step "Phase 1: Pattern Analysis"

    if [ ! -f "$PATTERN_REPORT" ]; then
        echo "Running pattern analysis..."
        python3 "$PHASE20_DIR/01-pattern-analysis.py" \
            --skills-root "$SKILLS_ROOT" \
            --output "$PATTERN_REPORT"
        log_success "Pattern analysis complete"
    else
        log_success "Pattern report already exists"
    fi

    # Validate pattern report
    PATTERN_COUNT=$(python3 -c "import json; print(json.load(open('$PATTERN_REPORT'))['total_patterns'])")
    echo "Found $PATTERN_COUNT patterns to consolidate"
    echo ""

    # Phase 2: Generate Shims
    log_step "Phase 2: Generate Backward-Compatible Shims"

    DRY_FLAG=""
    [ "$DRY_RUN" = true ] && DRY_FLAG="--dry-run"

    python3 "$PHASE20_DIR/02-generate-shims.py" \
        --pattern-report "$PATTERN_REPORT" \
        --skills-root "$SKILLS_ROOT" \
        --category "$CATEGORY" \
        $DRY_FLAG

    log_success "Shims generated"
    echo ""

    # Phase 3: Migrate Imports
    log_step "Phase 3: Migrate Imports"

    python3 "$PHASE20_DIR/03-migrate-imports.py" \
        --skills-root "$SKILLS_ROOT" \
        --category "$CATEGORY" \
        $DRY_FLAG

    log_success "Imports migrated"
    echo ""

    # Phase 4: Migrate Tests
    log_step "Phase 4: Migrate Test Files"

    python3 "$PHASE20_DIR/04-migrate-tests.py" \
        --tests-root "$TESTS_ROOT" \
        --category "$CATEGORY" \
        $DRY_FLAG

    log_success "Tests migrated"
    echo ""

    # Phase 5: Validation
    log_step "Phase 5: Validation"

    if [ "$DRY_RUN" = false ]; then
        echo "Validating imports..."
        python3 "$PHASE20_DIR/03-migrate-imports.py" \
            --skills-root "$SKILLS_ROOT" \
            --category "$CATEGORY" \
            --validate || {
            log_error "Import validation failed!"
            return 1
        }
        log_success "Imports validated"

        echo "Validating test files..."
        python3 "$PHASE20_DIR/04-migrate-tests.py" \
            --tests-root "$TESTS_ROOT" \
            --category "$CATEGORY" \
            --validate || {
            log_warning "Some test issues detected (may be expected)"
        }
        log_success "Tests validated"
        echo ""
    fi

    # Phase 6: Run Tests
    log_step "Phase 6: Test Suite"

    if [ "$SKIP_TESTS" = false ] && [ "$DRY_RUN" = false ]; then
        echo "Running test suite..."

        if [ -n "$CATEGORY" ]; then
            pytest "tests/skills/$CATEGORY/" -v --tb=short 2>&1 | head -50
        else
            pytest tests/ -q --tb=line 2>&1 | tail -20
        fi

        log_success "Test suite complete"
        echo ""
    else
        log_warning "Test suite skipped"
        echo ""
    fi

    # Summary
    echo -e "${BLUE}╔════════════════════════════════════════════════════════╗${NC}"
    echo -e "${BLUE}║                  CONSOLIDATION COMPLETE                 ║${NC}"
    echo -e "${BLUE}╚════════════════════════════════════════════════════════╝${NC}"
    echo ""

    if [ "$DRY_RUN" = true ]; then
        log_warning "This was a DRY RUN. No files were modified."
        echo "Run again without --dry-run to apply changes."
    else
        log_success "All changes applied successfully!"

        if [ -n "$CATEGORY" ]; then
            echo "Category: $CATEGORY"
        else
            echo "Consolidated all patterns across full codebase"
        fi

        echo ""
        echo "Next steps:"
        echo "  1. Review changes: git diff"
        echo "  2. Run full test suite: pytest tests/"
        echo "  3. Commit changes: git commit -m 'consolidation: complete Phase 20'"
    fi

    return 0
}

# Execute main
if main; then
    exit 0
else
    log_error "Orchestration failed!"
    exit 1
fi
