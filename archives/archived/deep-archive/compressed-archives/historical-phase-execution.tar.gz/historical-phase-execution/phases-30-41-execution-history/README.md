# Phase 20: Automated Duplication Consolidation

Phase 20 eliminates 10,400+ LOC of duplication across 4 consolidation types using parallel work streams and AST-based automation.

## Overview

- **Duration**: 8 weeks (Weeks 1-8)
- **Scope**: 34 skills across 7 categories
- **Automation**: 5 AST-based scripts (80% automation coverage)
- **Expected Reduction**: 20-25% codebase reduction
- **Test Coverage**: 1,576 tests (100% backward compatible, zero regressions)

## Consolidation Types

| Type | Files | Pattern | Target Reduction |
|------|-------|---------|-----------------|
| Request/Result templates | 17 skills | Unified BaseRequest/BaseResult | 2,000+ LOC |
| Pipeline boilerplate | 17 skills | Unified BasePipeline | 3,400+ LOC |
| Engine implementations | 14+ files | Unified BaseEngine | 2,800+ LOC |
| Exception hierarchies | 4+ files | Consolidated hierarchy | 500+ LOC |
| Other (analyzers, validators, logging) | Multiple | Category-specific | 1,700+ LOC |

## Timeline & Phases

### Phase 1: Foundation (Weeks 1-2)
- Pattern analysis and reporting
- Base class design and implementation
- Exception hierarchy consolidation
- Build 5 automation scripts
- Pilot consolidation on 3 skills

**Gate 1**: Base classes tested, automation tools functional, 0 regressions

### Phase 2: Skill Consolidation (Weeks 3-6)
- Week 3: Monitoring (2 skills) + Routing (4 skills)
- Week 4: Cache/Optimization (4 skills) + Analytics begins
- Week 5: Analytics complete + Cost (5 skills) + Orchestration (6 skills)
- Week 6: Remaining skills (8 skills)

**Gate 2**: All 34 skills consolidated, 1,200+ tests passing, ±5% latency

### Phase 3: Validation & Rollout (Weeks 7-8)
- Integration testing (1,576 tests)
- Performance benchmarking
- Deprecation warnings deployment
- Main branch merge, release v1.2.0

**Gate 3**: Production ready, zero regressions, ≥85% coverage

## Automation Scripts

**5 scripts with ~200 lines each, AST-based, 80%+ automation**:

1. **01-pattern-analysis.py** - Catalog all duplicate patterns
2. **02-generate-shims.py** - Create backward-compatible shims
3. **03-migrate-imports.py** - Update imports across codebase
4. **04-migrate-tests.py** - Update test fixtures
5. **05-orchestrate.sh** - Master orchestrator (runs all phases)

See individual script files for implementation.

## Base Classes (Phase 20 Foundation)

Located in `skills/core/patterns/`:

- **BaseRequest** (`request.py`) - Consolidates 17 duplicate Request classes
- **BaseResult** (`result.py`) - Consolidates 17 duplicate Result classes
- **BasePipeline** (`pipeline.py`) - Consolidates 17 duplicate Pipeline implementations
- **BaseEngine** (`engine.py`) - Consolidates 14+ duplicate Engine implementations

Plus consolidated exception hierarchy in `skills/core/exceptions.py`.

## Quick Start

```bash
# Phase 1: Foundation work
python3 scripts/phase20/01-pattern-analysis.py \
    --skills-root skills \
    --output scripts/phase20/patterns-report.json

# Phase 2: Category consolidation (example: monitoring)
python3 scripts/phase20/02-generate-shims.py \
    --category monitoring \
    --output-dir skills

python3 scripts/phase20/03-migrate-imports.py \
    --category monitoring \
    --root skills

# Run tests
pytest tests/ -v --tb=short

# Full orchestration (all phases)
bash scripts/phase20/05-orchestrate.sh
```

## Success Metrics

- [ ] 20-25% codebase reduction (10,400+ LOC)
- [ ] 1,576 tests passing (100% backward compatible)
- [ ] Zero regressions
- [ ] Performance: ±5% latency vs baseline
- [ ] Coverage: ≥85% on consolidated modules
- [ ] All imports resolve (0 broken references)

## Rollback & Risk Mitigation

- Backward-compatible shims keep old code working during migration
- 8-week deprecation period before removing shims (Phase 21)
- Comprehensive regression detection suite
- Performance baseline comparison
- Each category validated independently before integration

## Next Steps

1. Implement 5 automation scripts (Week 1-2)
2. Run pattern analysis (Week 1)
3. Begin skill consolidation by category (Week 3)
4. Validate with full test suite (Week 7)
5. Merge to main branch (Week 8)

See `.claude/rules/INDEX.md` for general coding standards.
