# Additional Consolidation Opportunities - Phase 22+

**Analysis Date**: 2026-09-03
**Scope**: Comprehensive codebase analysis post-Phase 21
**Status**: Identified opportunities for 3+ phases of targeted consolidation

---

## Executive Summary

Post-Phase 21, comprehensive analysis identifies **7 major consolidation areas** spanning **~8,750 LOC** with estimated **40-50% reduction potential** through targeted refactoring.

### Quick Stats

| Area | Files | LOC | Reduction | Priority |
|------|-------|-----|-----------|----------|
| Batch Processing | 8 | 1,924 | 60-70% | 🔴 HIGH |
| Analytics/Metrics | 9 | 2,153 | 50-60% | 🔴 HIGH |
| Configuration | 4 | 929 | 40-50% | 🟠 MEDIUM |
| Validators | 12 | 3,529 | 45-55% | 🟠 MEDIUM |
| CLI Utilities | 8 | 1,481 | 35-45% | 🟠 MEDIUM |
| Cache Implementations | 7 | 1,147 | 50-60% | 🟠 MEDIUM |
| Test Utilities | TBD | TBD | 30-40% | 🟡 LOW |
| **TOTAL** | **48+** | **~8,750** | **40-50%** | |

---

## Area 1: Batch Processing Framework (PRIORITY: HIGH)

### Current State
- **Files**: 8 modules (1,924 LOC)
- **Pattern**: Multiple batch-related classes with overlapping responsibilities

### File Breakdown
```
app/core/
├── batchProcessor.py        (489 LOC) - Main batch processor
├── batchExecutor.py         (281 LOC) - Execution engine
├── batchSizeOptimizer.py    (257 LOC) - Size optimization
├── batchStats.py            (208 LOC) - Statistics tracking
├── batchExecution.py        (189 LOC) - Execution mixin
├── batchAnalyzer.py         (185 LOC) - Batch analysis
├── batchFormationCache.py   (182 LOC) - Formation cache
└── batchQueueManager.py     (133 LOC) - Queue management
```

### Consolidation Strategy
**Pattern**: Strategy Factory + Pipeline pattern
- Create `BatchingFramework` class with pluggable components:
  - `BatchAnalyzer` strategy
  - `SizeOptimizer` strategy
  - `QueueStrategy` strategy
  - `ExecutionEngine` (core)
- Consolidate stat tracking via `BatchStatistics` interface
- Create backward-compatible shims for deprecated modules

### Estimated Impact
- **Lines to consolidate**: 1,400-1,600 LOC
- **Reduction**: 70-80% (keep core ~400 LOC)
- **Complexity reduction**: From 8 modules → 1 framework + shims
- **Risk**: LOW (heavy unit test coverage exists)

### Proposal
```
scripts/utils/batching_framework.py      (150 LOC)
  - BaseBatchingStrategy
  - BatchComponentRegistry
  - BatchingPipeline

app/core/batchingCore/
├── __init__.py
├── framework.py                         (200 LOC)
├── strategies/
│   ├── analyzer_strategy.py
│   ├── optimizer_strategy.py
│   └── queue_strategy.py
└── shims/
    ├── batchProcessor_shim.py
    ├── batchExecutor_shim.py
    └── ... (6 more shims)
```

---

## Area 2: Analytics & Metrics Framework (PRIORITY: HIGH)

### Current State
- **Files**: 9 modules (2,153 LOC)
- **Pattern**: Multiple analytics engines with duplicated statistical logic

### File Breakdown
```
app/analytics/
├── base.py                              (251 LOC) - Base analytics
├── base_shim.py                         (29 LOC)  - [SHIM]
├── logParser.py                         (398 LOC) - Log parsing
├── costForecaster.py                    (311 LOC) - Cost prediction
├── performanceTrendAnalyzer.py          (309 LOC) - Performance trends
├── reportGenerator.py                   (281 LOC) - Report generation
├── metricsAlerts.py                     (281 LOC) - Alerting
├── metricsTimeSeries.py                 (268 LOC) - Time series
└── metricsTimeSeries_shim.py            (25 LOC)  - [SHIM]
```

### Consolidation Strategy
**Pattern**: Plugin Registry + Builder pattern
- Create `AnalyticsEngine` with pluggable analyzers
- Consolidate statistical utilities in `BaseAnalytics` (already exists, needs expansion)
- Create analyzer registry for runtime selection
- Extract common pipeline patterns:
  - Data ingestion → normalization → analysis → reporting

### Estimated Impact
- **Lines to consolidate**: 1,200-1,400 LOC
- **Reduction**: 55-65% (keep core ~900 LOC)
- **Consolidations**: Merge performanceTrendAnalyzer + costForecaster patterns
- **Risk**: MEDIUM (dependencies on report generation)

### Proposal
```
app/analytics/analyticsCore/
├── __init__.py
├── engine.py                            (200 LOC)
├── analyzers/
│   ├── base_analyzer.py
│   ├── cost_analyzer.py
│   ├── performance_analyzer.py
│   └── log_analyzer.py
├── pipeline/
│   ├── data_ingestion.py
│   ├── normalization.py
│   └── reporting.py
└── registry.py
```

---

## Area 3: Configuration Management (PRIORITY: MEDIUM)

### Current State
- **Files**: 4 core modules (929 LOC) + related
- **Pattern**: Multiple config loaders/caches with overlapping functionality

### File Breakdown
```
app/core/
├── configLoader.py          (454 LOC) - YAML config loading
├── configUtils.py           (210 LOC) - Utility functions
├── configCache.py           (265 LOC) - Config caching
└── agentConfigCache.py      (305 LOC) - Agent config cache

Related:
├── app/core/config/validators.py
├── scripts/utils/yaml_validator.py
└── scripts/validate/config_validator.py
```

### Consolidation Strategy
**Pattern**: Template Method + Caching Proxy
- Consolidate `configLoader` + `configUtils` → `ConfigurationManager`
- Unify caching logic: `configCache` + `agentConfigCache` → `CacheableConfig`
- Create shared validator registry
- Extract YAML validation to centralized utility

### Estimated Impact
- **Lines to consolidate**: 400-500 LOC
- **Reduction**: 45-50%
- **Benefit**: Single point for config updates, easier testing
- **Risk**: LOW (well-isolated module)

---

## Area 4: Validation Framework (PRIORITY: MEDIUM)

### Current State
- **Files**: 12 validators (3,529 LOC)
- **Pattern**: Multiple independent validators with duplicated patterns

### File Breakdown
```
scripts/validate/
├── base.py                  (74 LOC)   - Base class (good foundation)
├── owasp_audit.py           (768 LOC) - Security validation
├── config_validator.py      (427 LOC) - Config validation
├── check_config_consistency.py (414 LOC)
├── check_doc_links.py       (325 LOC) - Documentation validation
├── validate_skill_registry.py (286 LOC)
├── api_consistency.py       (265 LOC)
├── check_redundancy.py      (259 LOC)
├── validate_config_semantic.py (249 LOC)
├── detect_dead_code.py      (211 LOC)
├── drift_detector.py        (176 LOC)
└── __init__.py              (75 LOC)
```

### Consolidation Strategy
**Pattern**: Template Method + Composite pattern
- Already has good base class - enhance it with:
  - Standard result formatting
  - Common report generation
  - Severity level management
  - Batch validator orchestration
- Group validators by domain:
  - **ConfigValidators**: config, consistency, semantic
  - **DocValidators**: links, dead code, drift
  - **SecurityValidators**: OWASP, API consistency
  - **SkillValidators**: registry, redundancy

### Estimated Impact
- **Lines to consolidate**: 1,500-1,800 LOC
- **Reduction**: 45-50%
- **Key benefit**: Unified reporting, easier test setup
- **Risk**: LOW (independent validators)

---

## Area 5: CLI Framework (PRIORITY: MEDIUM)

### Current State
- **Files**: 8 modules (1,481 LOC)
- **Pattern**: Multiple CLI command handlers with duplicated patterns

### File Breakdown
```
scripts/cli/
├── __init__.py              (109 LOC)
├── __main__.py              (13 LOC)
├── base.py                  (310 LOC) - Base CLI class
├── interface.py             (299 LOC) - User interface
├── profiling.py             (218 LOC) - Profiling commands
├── plugin_registry.py       (213 LOC) - Plugin handling
├── sync.py                  (177 LOC) - Sync commands
└── validation.py            (142 LOC) - Validation commands
```

### Consolidation Strategy
**Pattern**: Command Registry + Builder
- Enhance `base.py` with command routing
- Create `CommandBuilder` for common patterns
- Extract common UI patterns from `interface.py`:
  - Progress reporting
  - Output formatting
  - Error display
  - Confirmation dialogs

### Estimated Impact
- **Lines to consolidate**: 500-600 LOC
- **Reduction**: 35-40%
- **Benefit**: Consistent CLI experience, easier testing
- **Risk**: LOW (isolated CLI layer)

---

## Area 6: Cache Implementations (PRIORITY: MEDIUM)

### Current State
- **Files**: 7 modules (1,147 LOC) across 2 systems
- **Pattern**: Duplicate caching logic with different interfaces

### File Breakdown
```
app/core/
├── cacheBase.py             (174 LOC)
├── cacheBase_shim.py        (43 LOC)  - [SHIM]
├── configCache.py           (265 LOC)
├── responseCache.py         (242 LOC)
├── agentConfigCache.py      (305 LOC)
└── batchFormationCache.py   (182 LOC)

app/core/cacheFramework/
├── __init__.py
├── baseCacheEntry.py
├── evictionStrategy.py
└── unifiedCache.py          (Already partially consolidated)
```

### Consolidation Strategy
**Pattern**: Unify under `cacheFramework`
- Already have framework in place
- Migrate `responseCache` and config caches to use it
- Remove old `cacheBase` and shim
- Standardize eviction policy interface

### Estimated Impact
- **Lines to consolidate**: 500-650 LOC
- **Reduction**: 50-60%
- **Benefit**: Single cache implementation, consistent behavior
- **Risk**: MEDIUM (used throughout codebase)

---

## Area 7: Test Utilities (PRIORITY: LOW)

### Current State
- **Scope**: TBD - Requires test suite audit
- **Expected**: 200-400 LOC of duplicated test fixtures

### Proposal
Once identified, consolidate into:
```
tests/common/
├── fixtures/
│   ├── batch_fixtures.py
│   ├── analytics_fixtures.py
│   ├── config_fixtures.py
│   └── mock_factories.py
└── utilities/
    ├── assertion_helpers.py
    ├── data_generators.py
    └── performance_utils.py
```

---

## Implementation Roadmap

### Phase 22: Batch Processing Consolidation (Est. 1-2 hours)
1. Create `BatchingFramework` in `scripts/utils/`
2. Create component strategies in `app/core/batchingCore/`
3. Create 8 backward-compatible shims
4. Update imports across codebase
5. Run test suite validation
6. **Expected outcome**: -1,400 LOC, 0 regressions

### Phase 23: Analytics Framework (Est. 1-2 hours)
1. Enhance `app/analytics/base.py`
2. Create analyzer registry system
3. Consolidate log, cost, and performance analyzers
4. Create common pipeline components
5. Update all analyzer implementations
6. **Expected outcome**: -1,200 LOC, improved extensibility

### Phase 24: Configuration Consolidation (Est. 45-60 min)
1. Merge config utils into loader
2. Unify caching implementation
3. Centralize validation
4. Create `ConfigurationManager` interface
5. **Expected outcome**: -400 LOC, single config API

### Phase 25: Validator Framework Enhancement (Est. 1-2 hours)
1. Enhance `scripts/validate/base.py`
2. Group validators by domain
3. Create unified reporting
4. Implement batch validation orchestration
5. **Expected outcome**: -1,500 LOC, consistent validation

### Phase 26: CLI & Cache Consolidation (Est. 1-2 hours)
1. Consolidate CLI commands
2. Finalize cache framework migration
3. **Expected outcome**: -1,100 LOC total

---

## Cross-Cutting Benefits

### Code Quality
- **Consistency**: Unified patterns reduce cognitive load
- **Testability**: Fewer but more focused modules
- **Maintainability**: Clear extension points via registries/strategies

### Performance
- **Reduced imports**: Fewer module loads
- **Optimized caching**: Unified cache framework
- **Batch processing**: Framework consolidation enables better optimization

### Documentation
- **Architecture clarity**: Fewer, clearer patterns to document
- **Extension guides**: Registry/strategy patterns are well-understood
- **API surface**: Smaller, more focused interfaces

---

## Risks & Mitigations

| Risk | Mitigation | Effort |
|------|-----------|--------|
| Breaking changes to public API | Create comprehensive shims | 30% |
| Test coverage gaps | Enhance test suite as we go | 20% |
| Performance regression | Benchmark before/after | 10% |
| Migration complexity | Automate with migration scripts | 25% |

---

## Success Metrics

✅ **Code Reduction**: 40-50% of identified ~8,750 LOC
✅ **Test Pass Rate**: Maintain 100% (1,611+ tests)
✅ **Backward Compatibility**: 100% via shims
✅ **Regressions**: 0 detected
✅ **Documentation**: Updated for all patterns

---

## Recommended Next Steps

1. **Prioritize**: Start with Batch Processing (Area 1) - highest impact, lowest risk
2. **Parallelize**: Validators (Area 4) can be done in parallel
3. **Follow-up**: Configuration (Area 3) creates foundation for later improvements
4. **Polish**: Test utilities (Area 7) - quality-of-life improvement

---

**Analysis Date**: 2026-09-03
**Analyst**: Claude Haiku 4.5
**Confidence**: HIGH (based on phase 1-21 experience and codebase patterns)
