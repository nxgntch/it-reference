# Phase 2 Optimization Recommendations

## Lazy-Loading Strategy

### Heavy Fixtures to Optimize
- `agentLoaderFixture`: Mark with `@lazy_fixture` or use `pytest.fixture(autouse=False)`
- `apiResponseFactory`: Mark with `@lazy_fixture` or use `pytest.fixture(autouse=False)`
- `cacheFactory`: Mark with `@lazy_fixture` or use `pytest.fixture(autouse=False)`
- `capturedOutput`: Mark with `@lazy_fixture` or use `pytest.fixture(autouse=False)`
- `clearResponseCache`: Mark with `@lazy_fixture` or use `pytest.fixture(autouse=False)`
- `configData`: Mark with `@lazy_fixture` or use `pytest.fixture(autouse=False)`
- `dbInterface`: Mark with `@lazy_fixture` or use `pytest.fixture(autouse=False)`
- `featureFlag`: Mark with `@lazy_fixture` or use `pytest.fixture(autouse=False)`
- `hookOptimizer`: Mark with `@lazy_fixture` or use `pytest.fixture(autouse=False)`
- `loaderWithAgents`: Mark with `@lazy_fixture` or use `pytest.fixture(autouse=False)`

### Async Fixtures
Use `@pytest_asyncio.fixture` with proper scope or defer with `autouse=False`

### Implementation Steps
1. Add `tests/_fixtures/lazyLoadHelper.py` with LazyFixture class
2. Mark heavy fixtures with `@lazy_fixture` decorator
3. Update test imports to use lazy fixtures
4. Measure context reduction with `pytest --collect-only`
5. Run full test suite to verify zero breaking changes

### Expected Results
- 38 heavy fixtures lazy-loaded
- Additional 15-20% context reduction
- All 2576 tests passing
- Zero breaking changes
