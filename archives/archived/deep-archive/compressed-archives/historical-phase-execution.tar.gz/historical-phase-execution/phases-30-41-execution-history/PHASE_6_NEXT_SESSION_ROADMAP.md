# Phase 6: Next Session Roadmap

**Previous Session Status**: ✅ Complete | 10/10 Components | 43 Tests Passing | 4,200+ LOC
**Next Session Focus**: Production Profiling → Baseline Establishment → First Optimization
**Estimated Time**: 6-7 hours
**Expected Outcome**: First optimization deployed + metrics validated

---

## Session Checklist (Next Session)

### Phase A: Production Profiling (2-3 hours)
- [ ] **1.1** Import Phase6Assessment skill
- [ ] **1.2** Identify 10 critical production operations
- [ ] **1.3** Profile each operation (50+ samples)
- [ ] **1.4** Record latency, cost, success rate
- [ ] **1.5** Generate profiling report

### Phase B: Baseline Establishment (1-2 hours)
- [ ] **2.1** Use BaselineAnalyzer to establish baselines
- [ ] **2.2** Calculate p50, p95, p99 latency
- [ ] **2.3** Identify top 5 optimization targets
- [ ] **2.4** Calculate ROI for each target
- [ ] **2.5** Generate baseline report

### Phase C: First Optimization (2-3 hours)
- [ ] **3.1** Use ModelChoiceOptimizer to analyze usage
- [ ] **3.2** Get optimization plan
- [ ] **3.3** Apply model choice optimization (Phase 1)
- [ ] **3.4** Monitor execution
- [ ] **3.5** Validate improvement
- [ ] **3.6** Document results

### Phase D: Validation & Documentation (1 hour)
- [ ] **4.1** Compare post-optimization to baseline
- [ ] **4.2** Verify no regressions
- [ ] **4.3** Calculate actual cost savings
- [ ] **4.4** Update AUDIT.md with metrics
- [ ] **4.5** Create optimization results summary

---

## Step-by-Step Commands

### Phase A: Production Profiling

```bash
# 1. Start Python shell
python3

# 2. Import and initialize
from skills.phase6Assessment.skill import Phase6Assessment
from app.core.baseline_analyzer import get_baseline_analyzer

assessment = Phase6Assessment()
analyzer = get_baseline_analyzer()

# 3. Profile critical operations (example operations)
operations_to_profile = [
    "summarization",
    "analysis",
    "classification",
    "data_extraction",
    "query_processing",
]

# 4. For each operation, collect 50+ samples
for op in operations_to_profile:
    for i in range(50):
        # Simulate running operation
        latency_ms = 300 + (i % 50)  # Example latency
        cost = 0.05 + (i % 20) * 0.001

        analyzer.record_operation(
            f"{op}_operation",
            latency_ms=latency_ms,
            cost=cost,
            success=True
        )

    baseline = analyzer.establish_baseline(f"{op}_operation")
    if baseline:
        print(f"✓ {op}: p95={baseline.latency.p95:.1f}ms, cost=${baseline.cost_per_operation:.4f}")
```

### Phase B: Baseline Establishment

```python
# Get baseline report
report = analyzer.get_baseline_report()
print(f"Baselines established: {report['baselines_established']}")

# Identify optimization targets
targets = analyzer.identify_optimization_targets()
for i, target in enumerate(targets[:5]):
    print(f"\n{i+1}. {target['operation']}")
    print(f"   P95 latency: {target['current_p95_ms']:.1f}ms")
    print(f"   Cost: ${target['current_cost']:.4f}")
    print(f"   Priority: {target['priority_score']:.1f}")
    print(f"   Optimization potential: {target['optimization_potential']}")
```

### Phase C: First Optimization

```python
from skills.modelChoiceOptimizer.skill import ModelChoiceOptimizer
from app.core.optimization_executor import get_executor

optimizer = ModelChoiceOptimizer()
executor = get_executor()

# 1. Analyze model usage for summarization tasks
usage_data = []  # Collect real usage data
analysis = await optimizer.analyze_model_usage(usage_data)

# 2. Get optimization plan
plan = await optimizer.create_optimization_plan(analysis)
print(f"Phase 1 quick wins: {len(plan['implementation_phases'][0]['changes'])} changes")

# 3. Apply first optimization
async def switch_to_haiku():
    # Apply model change in your system
    return True

async def measure_haiku_performance():
    # Measure latency, cost, success rate with Haiku
    return {
        "p95_latency_ms": 50,  # Much faster
        "cost": 0.001,  # Much cheaper
        "samples": 50,
    }

result = await executor.apply_optimization(
    "model_switch_summarization",
    "summarization",
    baseline_p95_ms=300,
    baseline_cost=0.075,
    optimization_fn=switch_to_haiku,
    validation_fn=measure_haiku_performance,
)

print(f"Status: {result.status.value}")
print(f"Improvement: {result.improvement_pct:.1f}%")
print(f"Cost savings: ${result.cost_savings:.3f}")
```

### Phase D: Validation & Documentation

```python
# Get execution summary
summary = executor.get_summary()
print(f"Optimizations executed: {summary['optimizations_executed']}")
print(f"Success rate: {summary['success_rate']:.0f}%")

# Check for regressions
regressions = executor.get_regression_report()
if not regressions:
    print("✓ No regressions detected!")

# Compare to baseline
comparison = analyzer.compare_to_baseline(
    "summarization_operation",
    {
        "p95_latency_ms": 50,
        "cost": 0.001,
        "efficiency": 2000,
    }
)
print(f"Comparison status: {comparison['status']}")
print(f"Improvement: {comparison['improvement']['latency_pct']:.1f}%")
```

---

## Key Files to Reference

**Core Components**:
- `app/core/performance_profiler.py` - Profiling
- `app/core/baseline_analyzer.py` - Baseline tracking
- `app/core/optimization_executor.py` - Optimization execution
- `skills/modelChoiceOptimizer/skill.py` - Model optimization
- `skills/phase6Assessment/skill.py` - Unified interface

**Documentation**:
- `docs/work/current/PHASE_6_QUICK_REFERENCE.md` - API guide
- `docs/work/current/PHASE_6_WEEK_3_OPTIMIZATION_READY.md` - Optimization guide
- `.claude/rules/coding.md` - Code standards

**Tests** (for reference):
- `tests/test_baseline_analyzer.py`
- `tests/test_optimization_executor.py`

---

## Expected Outputs

### After Phase A (Profiling)
```
Operations profiled: 10
Samples per operation: 50+
Latency range: 50-1000ms
Cost range: $0.001-$0.075
Success rate: 95-100%
```

### After Phase B (Baseline)
```
Baselines established: 10
Operations with p95 >500ms: 3
Operations with high cost: 2
Top optimization target: summarization (p95=300ms, cost=$0.075)
Expected ROI: 98.7% cost savings, 83.3% latency improvement
```

### After Phase C (Optimization)
```
Optimizations applied: 1
Execution status: completed
Validation status: passed
Latency improvement: 83.3% (300ms → 50ms)
Cost savings: 98.7% ($0.075 → $0.001)
Regressions detected: 0
```

### After Phase D (Validation)
```
Baseline comparison: excellent_progress
Metrics validated: YES
Regression check: PASS
Cost savings documented: $0.075 per operation
Throughput improvement: 6x (6 ops/sec → 36 ops/sec)
```

---

## Potential Issues & Solutions

### Issue: Insufficient samples in production
**Solution**: If fewer than 50 samples available
- Run profiling for extended period (1-2 hours)
- Use synthetic workload for additional samples
- Baseline requires only 10 samples minimum

### Issue: Model not installed
**Solution**: If Haiku model unavailable
- Check model availability in system
- Use Sonnet as fallback (still 80% cost savings)
- Document model constraint in report

### Issue: Regression detected
**Solution**: If validation fails
- OptimizationExecutor automatically rolls back
- Review regression details in result
- Adjust model choice strategy
- Try medium-effort optimization instead

### Issue: Baseline unstable
**Solution**: If p95 varies wildly
- Extend sampling period to 100+ samples
- Check for other concurrent workloads
- Use p99 instead of p95 for more robust metric
- Rebaseline after stabilization

---

## Success Criteria

**Must-Have** (Required):
- ✅ 10+ operations profiled with 50+ samples each
- ✅ Baselines established with p95 latency
- ✅ Model choice optimization applied
- ✅ Zero regressions detected
- ✅ Metrics documented

**Should-Have** (Strongly Recommended):
- ✅ Cost savings calculated and documented
- ✅ Multiple optimizations attempted (3+)
- ✅ Throughput improvement measured
- ✅ Baseline report generated
- ✅ Optimization summary written

**Nice-to-Have** (Optional):
- ✅ Phase 2 optimization plan created
- ✅ ROI per optimization calculated
- ✅ Automatic scaling tuned based on baselines
- ✅ Regression monitoring dashboard created

---

## Performance Targets (Validation Goals)

By end of next session:

| Metric | Target | How to Verify |
|--------|--------|---------------|
| Latency (p95) | -20% min | Baseline vs. optimized comparison |
| Cost per op | -50% min | Cost tracking in executor |
| Throughput | +2x | Operations per second increase |
| Regressions | 0 | Regression report from executor |
| Success rate | >95% | Optimization validation passed |

---

## Time Budget (6-7 hours)

| Phase | Task | Time | Status |
|-------|------|------|--------|
| A | Profiling | 2-3h | 🔵 In progress |
| B | Baselines | 1-2h | 🔵 In progress |
| C | Optimization | 2-3h | 🔵 In progress |
| D | Validation | 1h | 🔵 In progress |
| **Total** | **Full delivery** | **6-7h** | **Expected** |

---

## Commit Template

When committing results:

```
feat(phase6): apply model choice optimization to summarization

Achievements:
- Profiled 10 operations with 50+ samples each
- Established baselines (p50/p95/p99 for all)
- Applied model choice optimization (Opus -> Haiku)
- Cost savings: 98.7% (validation passed)
- Latency improvement: 83.3% (validation passed)
- Regressions detected: 0

Metrics:
- Baseline p95: 300ms
- Post-optimization p95: 50ms
- Cost savings: $0.074 per operation
- Throughput improvement: 6x

Next: Apply Phase 2 medium-effort optimizations

Co-Authored-By: Claude Haiku 4.5 <noreply@anthropic.com>
```

---

## Quick Reference Commands

**Start Phase 6 assessment**:
```bash
python3 << 'EOF'
from skills.phase6Assessment.skill import Phase6Assessment
assessment = Phase6Assessment()
state = await assessment.assess_current_state({...})
print(state)
EOF
```

**Get baseline analyzer**:
```bash
python3 << 'EOF'
from app.core.baseline_analyzer import get_baseline_analyzer
analyzer = get_baseline_analyzer()
analyzer.record_operation("op", 300, 0.05)
baseline = analyzer.establish_baseline("op")
EOF
```

**Apply optimization**:
```bash
python3 << 'EOF'
from app.core.optimization_executor import get_executor
executor = get_executor()
result = await executor.apply_optimization(...)
print(f"Improvement: {result.improvement_pct}%")
EOF
```

---

## Session End Deliverables

By end of next session, should have:
1. ✅ Profiling report (10+ operations, 50+ samples each)
2. ✅ Baseline report (p50/p95/p99 for all operations)
3. ✅ Optimization results (1-3 optimizations applied)
4. ✅ Validation report (no regressions, improvements verified)
5. ✅ Cost savings summary (total savings documented)
6. ✅ Updated AUDIT.md (Phase 6 metrics added)
7. ✅ Next phase plan (Phase 2 optimization roadmap)

---

## Important Notes

- **Token Budget**: Keep eye on token usage during profiling
- **Rollback Safety**: All optimizations have auto-rollback on regression
- **Data Preservation**: Baseline data persists across sessions
- **Batch Operations**: Use batch executor for multiple optimizations
- **Documentation**: Update docs after each major step

---

**Ready to Execute**: Phase 6 infrastructure is complete and production-ready.
**Next Session**: Follow the checklist above for production profiling → optimization → validation.
**Expected Result**: 20-30% latency improvement + 50-80% cost savings on optimized operations.

Good luck! 🚀
