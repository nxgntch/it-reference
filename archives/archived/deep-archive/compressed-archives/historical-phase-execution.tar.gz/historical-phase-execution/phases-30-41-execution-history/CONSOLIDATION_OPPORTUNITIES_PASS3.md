# Consolidation Analysis - Pass 3: Deep Patterns & Automation

**Analysis Date**: 2026-09-03 (Third Pass)
**Focus**: Cross-cutting patterns, automation opportunities, and hidden duplication
**Status**: Identified 5 major meta-patterns + automation shortcuts

---

## Meta-Pattern Analysis (Cross-Area Duplication)

### Meta-Pattern 1: CLI Argument Parsing (15 instances in cli/ alone)

**Location**: scripts/cli/ modules with high duplication
- cli/base.py: 15 add_argument() calls
- cli/interface.py: 15 argument handling patterns
- cli/sync.py: 13 argument definitions
- cli/validation.py: 7 argument patterns
- cli/profiling.py: 9 argument patterns

**Duplication Example**:
```python
# cli/base.py
parser.add_argument('--verbose', action='store_true', help='...')
parser.add_argument('--dry-run', action='store_true', help='...')
parser.add_argument('--config', type=str, required=False, help='...')

# cli/sync.py (identical structure, repeated)
parser.add_argument('--verbose', action='store_true', help='...')
parser.add_argument('--dry-run', action='store_true', help='...')

# cli/validation.py (similar)
parser.add_argument('--verbose', action='store_true', help='...')

# REPEATED in 7+ files: --verbose, --dry-run, --config, --format, --output
```

**Impact**: 100-150 LOC of duplicated argument setup

**Solution**: Create `CommonArguments` registry
```python
class CommonArguments:
    VERBOSE = {'action': 'store_true', 'help': 'Enable verbose output'}
    DRY_RUN = {'action': 'store_true', 'help': 'Show what would happen'}
    CONFIG = {'type': str, 'required': False, 'help': 'Config file path'}
    FORMAT = {'choices': ['json', 'yaml', 'text'], 'help': 'Output format'}

    @staticmethod
    def apply_to_parser(parser, *arg_names):
        """Apply standard arguments to parser."""
        args_map = {
            'verbose': CommonArguments.VERBOSE,
            'dry_run': CommonArguments.DRY_RUN,
            # ...
        }
        for name in arg_names:
            parser.add_argument(f'--{name.replace("_", "-")}', **args_map[name])
```

**Savings**: 100-150 LOC across CLI modules

---

### Meta-Pattern 2: Subprocess Execution Wrapper (45+ instances)

**Location**: Scattered across scripts/ (sync_helpers, nxgntch_sync, reference_sync, etc.)

**Duplication Example**:
```python
# Pattern 1: In sync_helpers.py (6 functions)
def run_command(cmd, cwd=None, capture=False):
    try:
        result = subprocess.run(cmd, cwd=cwd, capture_output=capture, ...)
    except Exception as e:
        logger.error(f"Command failed: {e}")
        raise

# Pattern 2: In nxgntch_sync.py (6+ similar implementations)
def execute_git_command(cmd, repo_path):
    try:
        result = subprocess.run(["git"] + cmd, cwd=repo_path, ...)
    except Exception as e:
        handle_error(e)

# Pattern 3: In reference_sync.py (5+ similar)
def run_subprocess(args, working_dir):
    try:
        subprocess.run(args, cwd=working_dir, ...)
    except Exception as e:
        log_and_fail(e)

# Pattern 4: In logs_sync.py (2+ similar)
def execute_command(command_list, path):
    try:
        subprocess.run(command_list, cwd=path, ...)
    except Exception as e:
        handle_error_quietly(e)
```

**Impact**: 200-250 LOC of similar subprocess handling

**Solution**: Centralize subprocess execution (already partially done)
```python
# Enhance scripts/utils/sync_helpers.py or create unified wrapper
class ProcessRunner:
    @staticmethod
    def run(cmd: List[str], cwd: Optional[Path] = None,
            timeout: int = 30, capture: bool = False) -> ProcessResult:
        """Single source for all subprocess execution."""
        try:
            result = subprocess.run(
                cmd,
                cwd=cwd,
                capture_output=capture,
                timeout=timeout,
                text=True
            )
            return ProcessResult(
                returncode=result.returncode,
                stdout=result.stdout,
                stderr=result.stderr,
                success=result.returncode == 0
            )
        except subprocess.TimeoutExpired:
            raise ProcessTimeoutError(cmd)
        except Exception as e:
            raise ProcessExecutionError(cmd, str(e))

    @staticmethod
    def run_git(cmd: List[str], repo_path: Path, **kwargs) -> ProcessResult:
        """Git operations specifically."""
        return ProcessRunner.run(["git"] + cmd, cwd=repo_path, **kwargs)
```

**Savings**: 200-250 LOC consolidated

**Automation**: Migration script can auto-update 45+ subprocess calls

---

### Meta-Pattern 3: JSON/YAML File Handling (30+ instances)

**Location**: Scattered across scripts/docs/, scripts/validate/, app/core/

**Duplication Example**:
```python
# Pattern 1: In multiple validators
with open(filepath, 'r') as f:
    data = json.load(f)
# Process data
with open(output, 'w') as f:
    json.dump(result, f, indent=2)

# Pattern 2: In config validator
try:
    with open(config_path, 'r') as f:
        config = yaml.safe_load(f)
except yaml.YAMLError as e:
    handle_yaml_error(e)

# Pattern 3: In multiple generators
config = {}
try:
    with open(file, 'r') as f:
        config = yaml.load(f, Loader=yaml.SafeLoader)
except Exception:
    config = {}
finally:
    process(config)

# Pattern 4: In profiling (multiple times)
def save_metrics(metrics, filename):
    with open(filename, 'w') as f:
        json.dump(metrics, f, indent=2)
```

**Impact**: 150-200 LOC of duplicated file I/O patterns

**Solution**: Create file format utility (already partially done: scripts/utils/file_format.py)
```python
class FileFormat:
    @staticmethod
    def read_json(filepath: Path) -> dict:
        """Unified JSON reading with error handling."""
        with open(filepath, 'r') as f:
            return json.load(f)

    @staticmethod
    def write_json(filepath: Path, data: dict, indent: int = 2):
        """Unified JSON writing."""
        filepath.parent.mkdir(parents=True, exist_ok=True)
        with open(filepath, 'w') as f:
            json.dump(data, f, indent=indent)

    @staticmethod
    def read_yaml(filepath: Path) -> dict:
        """Unified YAML reading with defaults."""
        try:
            with open(filepath, 'r') as f:
                return yaml.safe_load(f) or {}
        except FileNotFoundError:
            return {}

    @staticmethod
    def write_yaml(filepath: Path, data: dict):
        """Unified YAML writing."""
        filepath.parent.mkdir(parents=True, exist_ok=True)
        with open(filepath, 'w') as f:
            yaml.dump(data, f, default_flow_style=False)
```

**Savings**: 150-200 LOC consolidated

---

### Meta-Pattern 4: Generator/Builder Pattern Duplication (20+ instances)

**Location**: Documentation generators, report builders, profiling reports

**Duplication Example**:
```python
# Pattern 1: In html_generator.py
class HtmlGenerator:
    def __init__(self):
        self.content = ""
        self.sections = []

    def add_section(self, title, content):
        self.sections.append({'title': title, 'content': content})

    def build(self):
        html = '<html><body>'
        for section in self.sections:
            html += f'<h2>{section["title"]}</h2>'
            html += f'{section["content"]}'
        html += '</body></html>'
        return html

# Pattern 2: In reportGenerator.py (similar structure)
class ReportBuilder:
    def __init__(self):
        self.report = {}
        self.sections = {}

    def add_section(self, name, data):
        self.sections[name] = data

    def build(self):
        self.report['sections'] = self.sections
        return self.report

# Pattern 3: In parametrization_dashboard.py
class DashboardBuilder:
    def __init__(self):
        self.charts = []
        self.metadata = {}

    def add_chart(self, chart_data):
        self.charts.append(chart_data)

    def build(self):
        return {'charts': self.charts, 'meta': self.metadata}
```

**Impact**: 100-150 LOC of similar builder patterns

**Solution**: Create abstract Builder base class
```python
class ContentBuilder:
    """Base builder for structured content generation."""

    def __init__(self, content_type: str):
        self.content_type = content_type
        self.sections = []
        self.metadata = {}

    def add_section(self, title: str, content: Any) -> 'ContentBuilder':
        self.sections.append({'title': title, 'content': content})
        return self  # For chaining

    def set_metadata(self, **kwargs) -> 'ContentBuilder':
        self.metadata.update(kwargs)
        return self

    def build(self) -> dict:
        """Override in subclasses for specific formats."""
        return {
            'type': self.content_type,
            'sections': self.sections,
            'metadata': self.metadata
        }

class HtmlBuilder(ContentBuilder):
    def build(self) -> str:
        html = '<html><body>'
        for section in self.sections:
            html += f'<h2>{section["title"]}</h2>'
            html += f'<div>{section["content"]}</div>'
        html += '</body></html>'
        return html
```

**Savings**: 100-150 LOC consolidated + reusable pattern

---

### Meta-Pattern 5: Result/Status Formatting (30+ instances)

**Location**: Across all validation, profiling, and sync modules

**Duplication**: Already identified in Pass 1/2, but with additional instances
- Validators: 12+ result formatting implementations
- Sync modules: 8+ status formatting implementations
- Profiling: 4+ report formatting implementations

**Total duplication**: 150-200 LOC (refined estimate)

**Solution**: Already partially addressed in Pass 1, but needs expansion
```python
class ResultFormatter:
    """Universal result formatting for all domains."""

    @staticmethod
    def format_validation_result(findings: List[dict],
                                 categories: dict = None) -> dict:
        """Format validation findings."""
        return {
            'timestamp': datetime.now().isoformat(),
            'total': len(findings),
            'categories': categories or {},
            'findings': findings
        }

    @staticmethod
    def format_sync_result(status: str, items: int, errors: List[str]) -> dict:
        """Format sync operation results."""
        return {
            'status': status,
            'items_processed': items,
            'errors': errors,
            'success': len(errors) == 0
        }

    @staticmethod
    def format_report(title: str, metrics: dict,
                     timestamp: Optional[str] = None) -> dict:
        """Format generic report."""
        return {
            'title': title,
            'timestamp': timestamp or datetime.now().isoformat(),
            'metrics': metrics
        }
```

**Savings**: 150-200 LOC (already counted in Pass 1, but more thorough consolidation)

---

## Automation Opportunities

### Opportunity A: Auto-Migration Script for Subprocess Calls

**Target**: 45+ subprocess.run() calls across codebase

**Script**: Create `migrate_subprocess_unified.py`
```python
def migrate_subprocess_calls(source_file):
    """Convert all subprocess.run calls to ProcessRunner."""
    # Pattern 1: subprocess.run([...], cwd=..., ...)
    #    → ProcessRunner.run([...], cwd=...)
    # Pattern 2: subprocess.run(["git", ...], cwd=...)
    #    → ProcessRunner.run_git([...], ...)
    # Auto-conversion + verification
```

**Time savings**: 2-3 hours manual migration → 30 minutes automation

**Risk**: LOW (ProcessRunner wrapper validates compatibility)

---

### Opportunity B: Auto-Migration for File I/O Patterns

**Target**: 30+ JSON/YAML file operations

**Script**: Create `migrate_file_operations.py`
```python
def migrate_file_io(source_file):
    """Convert file operations to FileFormat utilities."""
    # Pattern 1: with open(...) json.load(...)
    #    → FileFormat.read_json(...)
    # Pattern 2: with open(...) json.dump(...)
    #    → FileFormat.write_json(...)
```

**Time savings**: 1-2 hours manual → 20 minutes automation

---

### Opportunity C: Argument Parser Generator

**Target**: 15+ CLI argument definitions

**Script**: Create `generate_cli_arguments.py`
```python
def generate_cli_setup(cli_module):
    """Generate unified CLI argument setup."""
    # Extract CommonArguments usage patterns
    # Generate appropriate apply_to_parser() calls
    # Remove redundant add_argument() calls
```

**Time savings**: 1 hour manual → 15 minutes automation

---

## Consolidated Summary: All Three Passes

### Areas Identified

**Pass 1** (Application Core):
1. Batch Processing (9 files, 2,437 LOC)
2. Analytics (9 files, 2,153 LOC)
3. Configuration (4 files, 929 LOC)
4. Validators (12 files, 3,529 LOC)
5. CLI (8 files, 1,481 LOC)
6. Cache (7 files, 1,147 LOC)

**Pass 2** (Scripting/Infrastructure):
7. Sync Orchestration (8 files, 1,464 LOC)
8. Repo Sync (5 files, 1,888 LOC)
9. Profiling (4 files, 1,283 LOC)
10. Optimization (5 files, 1,333 LOC)
11. Test Utils (5+ files, 1,678 LOC)

**Pass 3** (Meta-Patterns):
- CLI Argument Parsing: 100-150 LOC (affects areas 5, 7, 8, 27)
- Subprocess Execution: 200-250 LOC (affects areas 7, 8, 27)
- JSON/YAML File Handling: 150-200 LOC (affects areas 4, 7, 9, 25, 28)
- Generator/Builder: 100-150 LOC (affects areas 9, 23, 28)
- Result Formatting: 150-200 LOC (affects areas 4, 5, 7, 25, 27)

### Total Duplication (3 Passes)

| Category | Distinct Areas | Total LOC | % of Codebase |
|----------|----------------|-----------|---------------|
| Application | 6 | 10,276 | 14.1% |
| Scripting | 5 | 7,646 | 10.5% |
| Meta-Patterns | 5 | ~700-850 | 1.0% |
| **TOTAL** | **11-16** | **~18,600-19,000** | **~25-26%** |

---

## Phased Implementation with Automation

### Phase Strategy

**Early Phases (22-26)**: Manual but stable consolidations
- These areas have clear dependencies and structures
- Automation prep work (migration scripts created)

**Mid Phases (27-29)**: Automation-assisted consolidations
- Use prepared migration scripts to accelerate
- Higher parallelization possible

**Optimization Phase**: Cross-cutting meta-pattern consolidation
- After frameworks in place, tackle meta-patterns
- Apply lessons learned from earlier phases

### Timeline with Automation

**Without Automation** (original estimate): 13-16 hours
**With Automation** (Pass 3 shortcuts): 10-12 hours
**Savings**: 20-25% (2-4 hours)

### Recommended Execution Order (Optimized)

1. **Phase 22**: Batch Processing (1.5h) - No dependencies
2. **Phase 24**: Configuration (1h) - No dependencies
3. **Phase 23**: Analytics (1.5h) - Depends on framework setup
4. **Phase 25**: Validators (1.5h) - Parallel with Phase 23
5. **Phase 26**: CLI & Cache (1.5h)
6. **Meta-Pattern Consolidation** (1.5h):
   - Apply CommonArguments (20 min)
   - Apply ProcessRunner (30 min)
   - Apply FileFormat (20 min)
   - Apply ResultFormatter (30 min)
7. **Phase 27**: Sync (2h) - Can use Meta-Patterns
8. **Phase 28**: Performance (2h) - Can use Meta-Patterns
9. **Phase 29**: Tests (1h) - Can use Meta-Patterns

**Total**: ~14 hours (vs 16+ without optimization)

---

## Key Insights from Pass 3

### 1. Meta-Patterns Account for 3-5% of Total Duplication
- Small individual impacts (100-200 LOC each)
- But affects 8+ different areas
- High ROI to consolidate early

### 2. CLI Is Over-Instrumented
- 15 argument patterns in CLI alone
- Same 7-8 common arguments repeated 15+ times
- CommonArguments pattern can save 100-150 LOC quickly

### 3. Subprocess Handling Is a Major Hidden Duplication
- 45+ instances across scripts/
- 7-8 different wrapper implementations
- Unified ProcessRunner is critical for Phases 27-29

### 4. File Operations Are Scattered
- 30+ instances of JSON/YAML handling
- Already partially addressed (file_format.py exists)
- Needs aggressive adoption + migration scripts

### 5. Generators/Builders Follow Emerging Pattern
- All use similar structure (init → add → build)
- Can be unified into abstract ContentBuilder
- Would help with future development (docs, reports, etc.)

---

## Revised Consolidation Matrix (3 Passes)

| Phase | Area | Hours | LOC Removed | Includes Meta-Patterns |
|-------|------|-------|------------|----------------------|
| 22 | Batch | 1.5 | 1,400 | - |
| 23 | Analytics | 1.5 | 1,200 | Generator pattern |
| 24 | Config | 1.0 | 400 | JSON/YAML handling |
| 25 | Validators | 1.5 | 1,500 | Result formatting |
| 26 | CLI + Cache | 1.5 | 800 | CLI args + File ops |
| MP | Meta-Patterns | 1.5 | 700-850 | All 5 patterns |
| 27 | Sync | 2.0 | 1,800 | Subprocess + CLI args |
| 28 | Performance | 2.0 | 1,200 | File ops |
| 29 | Tests | 1.0 | 400 | - |
| **TOTAL** | | **14.0** | **9,300-9,450** | **Embedded** |

---

## Risk Mitigation for Meta-Patterns

### Pattern Adoption Risk

**Risk**: Meta-pattern frameworks underutilized if not integrated early

**Mitigation**:
1. Create meta-pattern frameworks in Phase 1 (before Phase 22)
2. Use them immediately in Phase 22-26
3. Enforce via code review and linting rules

**Timeline Adjustment**: Add 30 minutes pre-work to create meta-pattern modules

---

## Success Criteria (Final)

✅ **Total Consolidation**: 9,300-9,450 LOC removed (49-50% of 18,600 LOC)
✅ **Frameworks Created**: 8 major + 5 meta-patterns = 13 total
✅ **Test Pass Rate**: 100% (1,611+ tests)
✅ **Zero Regressions**: Verified across all phases
✅ **Performance**: < ±5% variance
✅ **Developer Velocity**: 60-75% faster for extending frameworks
✅ **Code Quality**: 85%+ coverage maintained

---

## Appendix: Quick Meta-Pattern References

### CommonArguments Pattern
```python
# Usage in any CLI module
from scripts.utils.cli_common import CommonArguments

parser = argparse.ArgumentParser()
CommonArguments.apply_to_parser(parser, 'verbose', 'dry_run', 'config')
# Replaces 30+ lines of redundant add_argument() calls
```

### ProcessRunner Pattern
```python
# Usage instead of subprocess.run()
from scripts.utils.process import ProcessRunner

result = ProcessRunner.run(['python', 'script.py'], timeout=30)
result = ProcessRunner.run_git(['status'], cwd=repo_path)
# Replaces 10+ implementations across codebase
```

### FileFormat Pattern
```python
# Usage for JSON/YAML operations
from scripts.utils.file_format import FileFormat

data = FileFormat.read_json(Path('config.json'))
FileFormat.write_yaml(Path('output.yaml'), data)
# Replaces 30+ redundant file I/O patterns
```

### ContentBuilder Pattern
```python
# Usage for generating reports/documents
from scripts.docs.builders import HtmlBuilder, JsonBuilder

html = HtmlBuilder('My Report')
    .add_section('Overview', content)
    .add_section('Details', more_content)
    .set_metadata(author='Claude')
    .build()
# Replaces 20+ separate builder implementations
```

---

**Pass 3 Analysis Date**: 2026-09-03
**Combined Findings**: 18,600-19,000 LOC | 13 frameworks | 49-50% reduction
**Status**: 📋 Ready for execution with automation
**Recommendation**: ✅ Proceed with Phases 22-29 + meta-pattern injection
**Time Savings with Automation**: 20-25% (2-4 hours)
