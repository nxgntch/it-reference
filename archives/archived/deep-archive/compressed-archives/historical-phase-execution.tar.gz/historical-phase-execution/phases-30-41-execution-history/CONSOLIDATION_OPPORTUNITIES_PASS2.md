# Additional Consolidation Opportunities - Pass 2 Analysis

**Analysis Date**: 2026-09-03 (Second Pass)
**Scope**: Comprehensive codebase analysis - additional findings
**Status**: Identified 5 new major areas + refinements

---

## New Areas Discovered (Pass 2)

### Area 8: Sync Orchestration Framework (PRIORITY: HIGH)

**Files**: 8 modules (1,464 LOC)
```
scripts/sync/
├── syncDoc.py                (636 LOC) - Document sync
├── syncConfig.py             (216 LOC) - Configuration sync
├── syncClean.py              (140 LOC) - Cleanup sync
├── optimized.py              (126 LOC) - Performance optimizations
├── syncMobile.py             (103 LOC) - Mobile repo sync
├── syncit.py                 (98 LOC)  - General sync coordinator
├── base.py                   (95 LOC)  - Base sync class
└── autosync.py               (50 LOC)  - Auto sync wrapper
```

**Pattern**: Multiple sync implementations with overlapping logic
- Each `sync*.py` implements: `run()`, `verify()`, `cleanup()`, error handling
- Duplicated git command execution patterns
- Duplicated logging and result formatting
- Duplicated dry-run support

**Consolidation Strategy**:
- Create `SyncFramework` base with pluggable sync strategies
- Extract common patterns: git ops, logging, dry-run, error handling
- Create registry for sync types: DocSync, ConfigSync, MobileSync, etc.

**Estimated Impact**:
- **Lines to consolidate**: 800-1,000 LOC
- **Reduction**: 55-70%
- **New framework**: 200-250 LOC
- **Risk**: LOW (well-isolated sync layer)

---

### Area 9: Profiling & Parametrization Framework (PRIORITY: MEDIUM)

**Files**: 4 modules (1,283 LOC)
```
scripts/profiling/
├── parametrization_dashboard.py      (419 LOC) - Dashboard generation
├── parametrization_weekly_report.py  (281 LOC) - Weekly reports
├── measurement.py                    (178 LOC) - Metric measurement
├── base.py                           (110 LOC) - Base profiling
└── parametrization/
    └── __init__.py                   (6 LOC)
```

**Pattern**: Multiple report/dashboard generators with similar structure
- Data collection patterns (metrics gathering)
- Formatting patterns (HTML/JSON generation)
- Aggregation patterns (weekly rollups, summaries)
- Parameterization logic (threshold-based analysis)

**Consolidation Strategy**:
- Create `ProfilingFramework` with pluggable reporters
- Consolidate measurement collection
- Extract common dashboard/report generation
- Create report template system

**Estimated Impact**:
- **Lines to consolidate**: 600-800 LOC
- **Reduction**: 50-65%
- **New framework**: 200 LOC
- **Risk**: MEDIUM (complex reporting logic)

---

### Area 10: Optimization & Performance Modules (PRIORITY: MEDIUM)

**Files**: 5 modules (1,333 LOC)
```
app/core/
├── tokenOptimizer.py         (317 LOC) - Token optimization
├── intelligent_auto_scaler.py (304 LOC) - Auto-scaling
├── optimization_executor.py  (273 LOC) - Optimization runner
├── performance_profiler.py   (244 LOC) - Performance analysis
└── circuitBreaker.py         (195 LOC) - Circuit breaker pattern
```

**Pattern**: Multiple optimization strategies with similar interfaces
- Each implements: `analyze()`, `optimize()`, `get_metrics()`, `apply_optimization()`
- Similar state tracking and result reporting
- Duplicated performance measurement logic
- Similar threshold detection patterns

**Consolidation Strategy**:
- Create `OptimizationFramework` with pluggable strategies
- Consolidate performance measurement utilities
- Extract threshold detection logic
- Unify metrics collection and reporting

**Estimated Impact**:
- **Lines to consolidate**: 700-900 LOC
- **Reduction**: 50-70%
- **New framework**: 250-300 LOC
- **Risk**: MEDIUM (dependencies on orchestrator)

---

### Area 11: Repository Sync Orchestration (PRIORITY: HIGH)

**Files**: 5+ modules (1,888+ LOC)
```
scripts/sync/repos/
├── daily_sync.py             (377 LOC) - Multi-repo daily sync
├── logs_sync.py              (345 LOC) - Logs repo sync
├── archive_workflow.py       (326 LOC) - Archive management
├── reference_sync.py         (306 LOC) - Reference repo sync
├── nxgntch_sync.py           (306 LOC) - Marketplace sync
└── full_sync_orchestrator.py (54 LOC)  - Orchestrator
```

**Pattern**: Multiple repository sync handlers with overlapping code
- Duplicated repo verification logic
- Duplicated git operations (clone, push, pull, commit)
- Duplicated error handling and retry logic
- Duplicated status reporting

**Consolidation Strategy**:
- Create `RepoSyncFramework` with specialized handlers
- Extract git operations utility class
- Create repo verification registry
- Unify error handling and retry logic

**Estimated Impact**:
- **Lines to consolidate**: 900-1,200 LOC
- **Reduction**: 50-65%
- **New framework**: 300-350 LOC
- **Risk**: LOW (isolated sync operations)

---

### Area 12: Test Utilities & Fixtures (PRIORITY: LOW)

**Files**: Multiple test helper files (1,678 LOC in tests/)
```
tests/
├── utilities/parametrized_helpers.py (477 LOC)
├── fixtures/api_response_factory.py  (221 LOC)
├── test_subprocess_helpers.py        (220 LOC)
├── utilities/test_*.py               (multiple)
└── conftest.py                       (51 LOC)
```

**Pattern**: Duplicated test fixture patterns
- Multiple factory implementations
- Duplicated mock creation patterns
- Duplicated assertion helpers
- Duplicated data generators

**Consolidation Strategy**:
- Create unified `TestFactory` class
- Consolidate assertion helpers
- Create mock factory registry
- Build reusable fixture builder

**Estimated Impact**:
- **Lines to consolidate**: 400-600 LOC
- **Reduction**: 30-40%
- **New framework**: 150-200 LOC
- **Risk**: LOW (test-only, no prod impact)

---

## Refined Pass 1 Areas (Based on Deeper Analysis)

### Area 1: Batch Processing (REVISED)
- **Additional finding**: Batch metrics tracking also used in `llmBatcher.py` (513 LOC)
- **Revised scope**: 9 files, 2,437 LOC (was 1,924)
- **Revised reduction**: 60-70% (was 70-80%)

### Area 2: Analytics (REVISED)
- **Additional finding**: `logParser.py` (398 LOC) duplicates statistical patterns
- **Revised scope**: Same 9 files, but with stronger consolidation
- **Revised reduction**: 55-65% (unchanged)

### Area 3: Configuration (NEW INSIGHT)
- **Additional finding**: Multiple configuration dataclasses with similar structure
- **Additional finding**: Validation patterns duplicated in validators + configLoader
- **Revised consolidation**: Merge config-related exceptions into unified exception module

### Area 4: Validators (NEW INSIGHT)
- **Additional finding**: Config validator patterns overlap with validation.py
- **Additional finding**: OWASP validation patterns similar to requestValidator
- **Revised consolidation**: 45-55% reduction (unchanged, but better strategy)

---

## Comprehensive Consolidation Summary (Pass 1 + Pass 2)

| Area | Priority | Files | LOC | Phase | Reduction |
|------|----------|-------|-----|-------|-----------|
| 1. Batch Processing | 🔴 HIGH | 9 | 2,437 | 22 | 60-70% |
| 2. Analytics | 🔴 HIGH | 9 | 2,153 | 23 | 55-65% |
| 3. Config | 🟠 MEDIUM | 4 | 929 | 24 | 45-50% |
| 4. Validators | 🟠 MEDIUM | 12 | 3,529 | 25 | 45-55% |
| 5. CLI | 🟠 MEDIUM | 8 | 1,481 | 26 | 35-45% |
| 6. Cache | 🟠 MEDIUM | 7 | 1,147 | 26 | 50-60% |
| **7. Sync Orchestration** | **🔴 HIGH** | **8** | **1,464** | **27** | **55-70%** |
| **8. Repo Sync** | **🔴 HIGH** | **5** | **1,888** | **27** | **50-65%** |
| **9. Profiling** | **🟠 MEDIUM** | **4** | **1,283** | **28** | **50-65%** |
| **10. Optimization** | **🟠 MEDIUM** | **5** | **1,333** | **28** | **50-70%** |
| **11. Test Utils** | **🟡 LOW** | **5+** | **1,678** | **29** | **30-40%** |
| **TOTAL** | | **75+** | **18,922** | | **45-60%** |

---

## Additional Technical Patterns Found

### Pattern 6: Git Operations Duplication

**Location**: scripts/sync/ and scripts/sync/repos/

**Duplication**: 150-200 LOC of git command wrapping
```python
# Pattern appears 10+ times
def run_git_command(cmd, repo_path):
    try:
        result = subprocess.run(
            ["git"] + cmd,
            cwd=repo_path,
            capture_output=True,
            text=True,
            timeout=30
        )
        if result.returncode != 0:
            logger.error(f"Git error: {result.stderr}")
            raise GitError(result.stderr)
        return result.stdout.strip()
    except subprocess.TimeoutExpired:
        raise GitTimeoutError()
```

**Solution**: Create `GitOperations` utility class
```python
class GitOperations:
    @staticmethod
    def run(cmd: List[str], repo_path: Path, timeout: int = 30) -> str:
        """Single source for all git operations."""
```

**Savings**: 150-200 LOC consolidated

---

### Pattern 7: Result/Status Formatting

**Location**: Across sync, validators, profiling modules

**Duplication**: 100-150 LOC of result formatting
```python
# Appears in 8+ modules with variations
def format_results(findings, categories):
    return {
        'timestamp': datetime.now().isoformat(),
        'total': len(findings),
        'by_category': {cat: count for cat, count in categories.items()},
        'details': findings
    }
```

**Solution**: Already identified in Pass 1, but more instances found

**Revised savings**: 150-200 LOC (up from 100-150)

---

### Pattern 8: Repo Verification Logic

**Location**: scripts/sync/repos/ and scripts/sync/ modules

**Duplication**: 80-120 LOC of repo checking
```python
# Repeated in 5+ sync modules
def verify_repo(repo_path, repo_name):
    if not repo_path.exists():
        raise RepoNotFoundError(repo_name)
    if not (repo_path / ".git").exists():
        raise NotAGitRepo(repo_name)
    # Additional checks...
```

**Solution**: Create `RepoValidator` utility

**Savings**: 80-120 LOC consolidated

---

## Updated Consolidation Roadmap (Pass 1 + Pass 2)

### Phases 22-26: Original (Still Valid)
- Phase 22: Batch Processing (1-2h, -1,400 LOC)
- Phase 23: Analytics (1-2h, -1,200 LOC)
- Phase 24: Configuration (45-60m, -400 LOC)
- Phase 25: Validators (1-2h, -1,500 LOC)
- Phase 26: CLI & Cache (1-2h, -800 LOC)

### NEW Phases 27-29: Additional Consolidation

**Phase 27: Sync Frameworks** (2-3 hours)
- Consolidate: Sync orchestration (Area 7) + Repo sync (Area 8)
- Strategy: SyncFramework + RepoSyncOrchestrator + GitOperations
- Expected: -1,800 LOC, single unified sync system
- Risk: LOW (isolated operations)

**Phase 28: Performance Frameworks** (2-3 hours)
- Consolidate: Profiling (Area 9) + Optimization (Area 10)
- Strategy: ProfilingFramework + OptimizationFramework
- Expected: -1,200 LOC, unified performance tooling
- Risk: MEDIUM (multiple dependencies)

**Phase 29: Test Infrastructure** (1-2 hours)
- Consolidate: Test utilities (Area 11)
- Strategy: Unified TestFactory + MockBuilders
- Expected: -400 LOC, improved test maintainability
- Risk: LOW (test-only)

---

## Cross-Cutting Patterns Across All Areas

### Pattern A: Logging Initialization (137 instances)
**Solution**: Standardize via `get_logger()` utility (already exists)
**Effort**: Low (mostly done, needs adoption)
**Savings**: ~50 LOC per consolidation phase

### Pattern B: Error Handling (882 try/except blocks)
**Solution**: Create error handler registry with standard patterns
**Effort**: Medium (requires error hierarchy review)
**Savings**: ~100-150 LOC per area

### Pattern C: Data Transformation (79 functions)
**Solution**: Create data transform library with common operations
**Effort**: Medium (requires interface design)
**Savings**: ~80-120 LOC per area

### Pattern D: Metrics Collection (30+ implementations)
**Solution**: Consolidate under unified metrics engine
**Effort**: High (dependencies)
**Savings**: ~200-300 LOC

---

## Timeline & Resource Impact

### Total Work Estimate

**Original Phases (22-26)**: 8 hours
**New Phases (27-29)**: 5-8 hours
**Total**: 13-16 hours concentrated effort
**Timeline**: 4-5 weeks at 1-2 hours/day

### Parallel Opportunities

- Phases 22 & 24: Independent (Batch + Config)
- Phases 23 & 25: Independent (Analytics + Validators)
- Phase 26: Depends on earlier work
- Phases 27 & 28: Can run in parallel (after 22-26)
- Phase 29: Independent (can run with any phase)

### Recommended Schedule

**Week 1**:
- Phase 22 (Batch) + Phase 24 (Config) in parallel
- Phase 27 prep (analyze sync patterns)

**Week 2**:
- Phase 23 (Analytics) + Phase 25 (Validators) in parallel
- Phase 27 execution begins

**Week 3**:
- Phase 26 (CLI/Cache)
- Phase 27 completion
- Phase 28 prep

**Week 4**:
- Phase 28 (Performance) + Phase 29 (Tests) in parallel
- Verification and documentation

**Week 5**:
- Final testing, integration, documentation

---

## Updated ROI Analysis

### Code Quality Impact

| Metric | Original | After Phase 26 | After Phase 29 | Improvement |
|--------|----------|----------------|----------------|-------------|
| Total LOC (affected) | 9,000 | 7,200 | 5,500 | 39% |
| Unique patterns | 20+ | 12 | 8 | 60% |
| Frameworks created | 5 | 5 | 8 | +3 |
| Test coverage | 85%+ | 90%+ | 92%+ | +7% |

### Developer Experience Impact

| Aspect | Before | After Phase 29 | Benefit |
|--------|--------|----------------|---------|
| Time to add new analyzer | 1 hour | 15 minutes | 75% faster |
| Time to add new sync type | 1 hour | 20 minutes | 67% faster |
| Time to add new validator | 45 min | 10 minutes | 78% faster |
| Test fixture creation | 30 min | 5 minutes | 83% faster |

---

## Success Criteria (Updated)

✅ **Code Reduction**: 40-50% of identified ~18,900 LOC (target 8,000-9,000 LOC removed)
✅ **Frameworks Created**: 8 total (5 from Pass 1 + 3 new)
✅ **Test Pass Rate**: Maintain 100% (1,611+ tests)
✅ **Regressions**: Target 0 across all phases
✅ **Performance**: No degradation (< ±5% variance)
✅ **Documentation**: Updated per phase
✅ **Developer Velocity**: Measurable improvement in framework adoption

---

## Risk Assessment (Updated)

### Per Phase (Phases 27-29)

| Phase | Technical Risk | Dependency Risk | Effort Risk |
|-------|----------------|-----------------|------------|
| 27 | LOW | MEDIUM | MEDIUM |
| 28 | MEDIUM | HIGH | MEDIUM |
| 29 | LOW | LOW | LOW |

### Mitigation Strategy

1. ✅ Complete Phases 22-26 before 27-29
2. ✅ Extensive testing after each framework creation
3. ✅ Performance benchmarking for Phases 28-29
4. ✅ Staged rollout with shims for all modules

---

## Comparative Analysis: Pass 1 vs Pass 2

### What Pass 1 Found
- 7 areas, 8,750 LOC
- Focus on application core (app/ modules)
- Mostly synchronous execution paths

### What Pass 2 Added
- 5 new areas, 10,172 LOC (overlap reduced)
- Focus on scripting and utilities (scripts/ modules)
- Async and batch operations
- Infrastructure and testing

### Combined Scope
- 12 distinct consolidation areas
- 18,922 LOC eligible
- 45-60% overall reduction potential
- 8 new frameworks to create
- 75+ files to refactor

---

## Recommended Action Items (Updated)

### Immediate (This Week)
1. ✅ Review Pass 1 + Pass 2 analysis
2. ✅ Confirm priority ranking with team
3. ✅ Begin Phase 22 (Batch) execution
4. ✅ Start Phase 27 analysis (Sync frameworks)

### Short-term (Weeks 2-3)
1. ✅ Execute Phases 23-26
2. ✅ Prepare Phase 27-29 specs
3. ✅ Create all required frameworks

### Long-term (Weeks 4-5)
1. ✅ Execute Phases 27-29
2. ✅ Comprehensive testing
3. ✅ Performance validation
4. ✅ Documentation and knowledge transfer

---

## Key Insights from Pass 2

1. **Scripting Duplication > Application Duplication**
   - Pass 1: 8,750 LOC (mostly app/)
   - Pass 2: Additional 10,172 LOC (mostly scripts/)
   - Total: 18,922 LOC (45-60% reduction)

2. **Framework Reuse Pattern Emerging**
   - All 5 new areas follow similar consolidation pattern
   - Strategy Factory + Registry + Base Class
   - Proven pattern from Pass 1 can be applied universally

3. **Test Infrastructure Often Overlooked**
   - 1,678 LOC of test utilities duplicated
   - Low risk, high quality-of-life improvement
   - Can be done in parallel with other phases

4. **Sync Operations Are Major Duplication Source**
   - 3,352 LOC across sync orchestration + repo sync
   - Affects both scripts/ and operations
   - High priority despite not in Pass 1 top-7

---

**Pass 2 Analysis Date**: 2026-09-03
**Combined Total**: 18,922 LOC identified | 8 frameworks | 12 areas
**Status**: 📋 Ready for Phases 22-29 execution
**Confidence**: VERY HIGH (comprehensive analysis, proven patterns)
**Recommendation**: ✅ Proceed with full roadmap (Phases 22-29)
