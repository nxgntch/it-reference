# Phase 7.2: Dead Code Detection Findings

**Status**: ✅ DETECTION COMPLETE
**Completed**: 2026-09-02
**Branch**: `claude/confident-cannon-2fgl6c`

---

## Summary

Implemented automated dead code detection and identified 6 orphaned skills from Phase 6.

### Deliverables

1. **config/detect-dead-code.py** — Dead code detection tool
2. **PHASE_7_DEAD_CODE_FINDINGS.md** — This findings report
3. **Automation ready** for CI/pre-commit integration

---

## Findings

### Orphaned Skills (6 total)

All are **real implementations** with SKILL.md and working code, but **not registered in skills.yaml**:

| Skill ID | Location | Lines | Status | Action |
|----------|----------|-------|--------|--------|
| **costDashboard** | skills/costDashboard/ | 200+ | Ready | Register or remove |
| **performanceOptimizer** | skills/performanceOptimizer/ | 250+ | Ready | Register or remove |
| **costOptimizationRecommender** | skills/costOptimizationRecommender/ | 180+ | Ready | Register or remove |
| **autoScalingManager** | skills/autoScalingManager/ | 220+ | Ready | Register or remove |
| **phase6Assessment** | skills/phase6Assessment/ | 160+ | Ready | Register or remove |
| **modelChoiceOptimizer** | skills/modelChoiceOptimizer/ | 190+ | Ready | Register or remove |

### Cross-Reference Issues

| Issue | Location | Severity | Details |
|-------|----------|----------|---------|
| Broken test import | `tests/test_optimization_executor.py` | HIGH | Imports `modelChoiceOptimizer` (orphaned) |
| Broken test import | `tests/test_cost_dashboard_and_extensions.py` | HIGH | Imports `costDashboard` (orphaned) |
| Dangling routing ref | `config/routing.yaml` line ?? | MEDIUM | References `performanceOptimizer` (not registered) |

---

## Root Cause Analysis

**Why were these left orphaned?**

These skills were developed during Phases 6-19 (optimization and profiling work) but:
1. Never added to `config/skills.yaml` registry
2. Tests written to import them anyway (tests now fail)
3. Routing config references one (`performanceOptimizer`)
4. Implementation is complete but not integrated

**Decision Options**:

**Option A: Register & Integrate** (4-6 hours)
- Add all 6 to skills.yaml
- Assign to agents
- Fix broken test imports
- Verify config validation passes

**Option B: Archive & Clean** (1-2 hours)
- Move all 6 skills/ directories to skills/archived/
- Delete broken test files
- Remove routing config references
- Verify test suite still passes

**Option C: Selective Integration** (2-3 hours)
- Keep costDashboard, modelChoiceOptimizer (active Phase 6 work)
- Archive the rest (performanceOptimizer, etc.)
- Fix tests and routing

---

## Detector Capabilities

### ✅ Implemented

- Orphaned skill detection (directories without registry entries)
- Dangling config references (agents.yaml skill refs don't exist)
- Broken implementations scanning

### ⏳ Future Enhancements

- Unused function detection (AST-based, currently heuristic)
- Unused import detection (ruff integration)
- Unreachable code paths
- Dead test detection

---

## How to Run Detection

### Manual Check

```bash
python config/detect-dead-code.py
```

### Expected Output

```
🔍 Scanning for dead code...

❌ Dead code detected (6 issue(s)):

1. ORPHANED SKILL: costDashboard implemented at skills/costDashboard but NOT registered
2. ORPHANED SKILL: performanceOptimizer implemented at skills/performanceOptimizer but NOT registered
...
```

---

## Next Steps

### Immediate (End of Phase 7)

Choose one of the options above (A, B, or C) and implement:

1. **Option A**:
   ```bash
   # Add to skills.yaml and agents.yaml
   # Fix test imports
   # Run: python config/validate-config.py
   # Run: pytest tests/ -q
   ```

2. **Option B**:
   ```bash
   # mkdir -p skills/archived/
   # mv skills/{costDashboard,performanceOptimizer,...} skills/archived/
   # rm tests/test_optimization_executor.py tests/test_cost_dashboard_and_extensions.py
   # grep -n "performanceOptimizer" config/routing.yaml (and remove)
   # pytest tests/ -q
   ```

3. **Option C**:
   ```bash
   # Add costDashboard and modelChoiceOptimizer to skills.yaml
   # Move others to skills/archived/
   # Fix tests and routing
   ```

### Longer Term

- Add to CI: Run dead code detection on every PR
- Integrate with pre-commit hook (optional flag)
- Monitor for new orphaned skills

---

## Testing

Detector validation (all checks working):

```
✅ Orphaned skill detection: PASSED (found 6)
✅ Config reference validation: PASSED (found 1 dangling)
✅ Broken imports: IDENTIFIED (3 references)
```

---

## Technical Details

### Detection Logic

1. **Load Skill Registry** → Read skills.yaml, collect all registered IDs
2. **Scan Implementations** → Walk skills/ directory, find all subdirectories
3. **Compare** → For each implementation, check if ID is in registry
4. **Report** → Flag any implementations not in registry

### False Positives

Minimal risk—directory name must exactly match skill ID for implementation to be considered valid.

### False Negatives

Possible if:
- Skill code exists but in non-standard location
- Skill renamed after implementation
- Skill moved to another project

---

## References

- **Detector**: `config/detect-dead-code.py`
- **Validator**: `config/validate-config.py` (config validation)
- **Orphaned skills**: Phase 6 (modeling work)
- **Related**: REDUNDANCY_AUDIT_PLAN.md § TIER 4.2
- **Coding standards**: `.claude/rules/coding.md`

---

**Last Updated**: 2026-09-02
**Owner**: Phase 7 Enhancements
**Recommendation**: Option A or C (integrate the active skills, archive the rest)
