# Consolidation Team - Scenario 1 Profiles (Balanced Team)

**Template**: Use these as reference profiles to evaluate your actual candidates
**Status**: Ready to customize with real people
**Created**: 2026-09-03

---

## TEAM LEAD PROFILE: Person A

### Identity
**Name**: [Sarah Chen]
**Title**: Senior Software Architect
**Experience**: 8 years (Python, FastAPI, System Design)
**Current Role**: Lead Engineer, Core Platform

### Skills Assessment

```
Python expertise:              9/10  (Expert - 8 years)
Git/Merge management:          8/10  (Advanced - manages releases)
Architectural skills:          9/10  (Expert - system design lead)
Batching patterns:             8/10  (Understands domain)
Analytics frameworks:          7/10  (Familiar with metrics)
CLI/Sync operations:           6/10  (Knows at high level)
Testing discipline:            8/10  (Advocates TDD)
Leadership:                    9/10  (Leads 3-person team now)
```

### Background
- Built FastAPI frameworks at previous company
- Led consolidation of payment systems (similar scale)
- Strong decision-maker, comfortable with ambiguity
- Excellent communicator (gives talks on architecture)

### Why Perfect for Team Lead

✅ **Architectural Depth** (9/10 architecture)
- Can review all 8 phases intelligently
- Understands design trade-offs
- Can make framework decisions confidently

✅ **Leadership Experience** (9/10 leadership)
- Currently manages 3 engineers
- Comfortable with daily decisions
- Known for clear communication

✅ **Python Mastery** (9/10)
- Deep knowledge of async/await, decorators, metaclasses
- Can code-review complex refactoring
- Understands performance implications

✅ **Availability** (Full commitment)
- Team knows she's available Mon-Fri
- Can do daily standups + review work
- Responsive to blockers

### Success Metrics (Personal)
- [ ] All 8 phases merged on schedule
- [ ] 0 critical merge conflicts
- [ ] Team reports high confidence in her decisions
- [ ] Handles 3+ blockers/week decisively
- [ ] Maintains <1 hour response time for decisions

### Strengths
1. Can explain complex architecture to non-technical stakeholders
2. Knows when to refactor vs. when to ship
3. Has mentored junior developers successfully
4. Experience with large-scale refactoring (previous company)
5. Strong code review instincts

### Growth Opportunity
- Less hands-on with CLI/sync operations (6/10)
- *Solution*: Can learn during Phase 27 support or delegate to Person C

---

## DEVELOPER 1 PROFILE: Person B

### Identity
**Name**: [Marcus Johnson]
**Title**: Backend Engineer
**Experience**: 6 years (Python specialist, AWS)
**Current Role**: Senior Backend Engineer, App Core

### Skills Assessment

```
Python expertise:              8/10  (Advanced - 6 years, 100k+ LOC written)
Git/Merge management:          9/10  (Expert - manages feature branches)
Architectural skills:          6/10  (Contributor, not lead)
Batching patterns:             9/10  (Built batch payment systems)
Analytics frameworks:          8/10  (Logging/metrics background)
CLI/Sync operations:           7/10  (Used in past projects)
Testing discipline:            7/10  (Writes good tests)
Leadership:                    5/10  (Individual contributor, no team mgmt)
```

### Background
- 6 years Python, mostly async backend code
- Built batch payment processing system (2,000+ LOC)
- Knows analytics deeply (instrumentation background)
- Detail-oriented, writes clean code

### Why Perfect for Dev 1 (App Core)

✅ **Batching Expert** (9/10)
- Built batch payment system at previous company
- Understands queue strategies, executor patterns
- Can design Phase 22 intelligently
- Knows common pitfalls

✅ **Analytics Knowledge** (8/10)
- Instrumented complex systems
- Understands event aggregation
- Perfect for Phase 23 (Analytics consolidation)

✅ **Python Master** (8/10)
- Writes clean, testable code
- Strong async/await patterns
- Knows performance optimization tricks

✅ **Detail-Oriented** (loves precision)
- Cares about LOC counts matching specs
- Writes thorough tests
- Catches edge cases

✅ **Availability** (Full commitment)
- No major projects blocking
- Available 7.5 hours/week

### Success Metrics (Personal)
- [ ] Phase 22 LOC targets: 150 (framework) + 240 (components) + 200 (shims) = 590 ✅
- [ ] Phase 23 LOC targets: 1,200+ removed ✅
- [ ] 150+ tests passing Phase 22
- [ ] 85+ tests passing Phase 23
- [ ] Code review approved without major changes

### Strengths
1. Batch processing is his specialty (knows it inside-out)
2. Writes tests reflexively (high quality)
3. Asks good questions about edge cases
4. Strong async Python skills (FastAPI native)
5. Patient teacher (can help others)

### Growth Opportunity
- Less architectural thinking (6/10)
- *Solution*: Works with Sarah for design decisions, implements her specs

### Why Paired with Sarah
- Sarah designs frameworks → Marcus implements cleanly
- Sarah reviews architecture → Marcus writes tests
- Sarah makes decisions → Marcus executes confidently
- Natural mentor/expert pair

---

## DEVELOPER 2 PROFILE: Person C

### Identity
**Name**: [Alex Patel]
**Title**: Infrastructure Engineer
**Experience**: 5 years (Git, DevOps, Scripts)
**Current Role**: Infrastructure Specialist, Scripts

### Skills Assessment

```
Python expertise:              7/10  (Good - 5 years, infrastructure focus)
Git/Merge management:          9/10  (Expert - manages release branches)
Architectural skills:          7/10  (Infrastructure architect)
Batching patterns:             6/10  (Aware, not specialist)
Analytics frameworks:          9/10  (Wrote metrics collection service)
CLI/Sync operations:           9/10  (EXPERT - built sync system)
Testing discipline:            6/10  (Pragmatic, not obsessive)
Leadership:                    4/10  (Individual contributor)
```

### Background
- 5 years infrastructure/DevOps Python
- Built daily sync orchestration system (their current responsibility)
- Deep git knowledge (manages releases, merges)
- Wrote metrics collection service (analytics framework)

### Why Perfect for Dev 2 (Infrastructure)

✅ **Git/Sync Expert** (9/10)
- Built the current sync system
- Knows every subprocess call in scripts/
- Understands git operations deeply
- Perfect for Phase 27 (GitOperations consolidation)

✅ **CLI Knowledge** (Knows scripts/ directory)
- Maintains CLI scripts daily
- Understands command patterns
- Can consolidate CommandBuilder for Phase 26

✅ **Analytics Background** (9/10)
- Wrote metrics collection (could help Phase 23 if needed)
- Understands instrumentation
- Data-driven troubleshooting

✅ **Infrastructure Python** (7/10)
- Strong subprocess patterns
- Comfortable with system-level code
- Good error handling in scripts

✅ **Availability** (Full commitment)
- Only responsible for sync (can be covered)
- Available 5 hours/week

### Success Metrics (Personal)
- [ ] Phase 27 consolidates 45+ subprocess calls into GitOperations
- [ ] 120+ tests passing Phase 27
- [ ] Phase 26 CLI consolidation (with Sarah support)
- [ ] All sync workflows still working post-consolidation
- [ ] 0 git operation regressions

### Strengths
1. Knows scripts/ directory intimately
2. Git operations expert (rare skill)
3. Understands sync workflows end-to-end
4. Can write scripts that work in production
5. Pragmatic about testing (knows what matters)

### Growth Opportunity
- Less architectural thinking (7/10, infrastructure-focused)
- Less obsessive testing (6/10, pragmatic)
- *Solution*: Sarah handles architecture, Alex focuses on implementation quality

### Why Paired with Sarah
- Alex knows the domain (sync/git) → Sarah validates design
- Sarah reviews architecture → Alex implements reliably
- Sarah makes decisions → Alex executes confidently
- Infrastructure specialist + Architect = great pair

---

## TEAM DYNAMICS & CHEMISTRY

### How They Complement Each Other

```
PERSON A (Sarah - Architect)
├─ Strength: Big picture, design, decisions
├─ Role: Reviewer, decision-maker, escalations
└─ Work with: Both B & C for implementation feedback

PERSON B (Marcus - App Core Specialist)
├─ Strength: Batching, analytics, clean code
├─ Role: Core application consolidation
└─ Work with: Sarah for design, Alex for integration

PERSON C (Alex - Infrastructure Specialist)
├─ Strength: Git, sync, CLI, scripts
├─ Role: Infrastructure consolidation
└─ Work with: Sarah for architecture, Marcus for testing patterns
```

### Daily Collaboration

**Monday-Friday 10:00 AM Standup**
- Sarah: "What are you blocked on? What decisions do you need?"
- Marcus: "Phase 22 framework done, need review on shim pattern"
- Alex: "Phase 27 git operations consolidated, ready to test"
- Sarah: "Great. I'll review Marcus, help Alex with testing strategy"

**Monday-Friday 4:00 PM Sync**
- Dashboard metrics reviewed
- Blockers identified and resolved
- Next day planning

**During Day**
- Marcus codes Phase 22, Sarah reviews async patterns
- Alex codes Phase 27, Sarah validates git abstraction
- Sarah codes Phase 24/25, reviews from both developers

---

## SKILLS COVERAGE MATRIX

```
              Phase22  Phase23  Phase24  Phase25  Phase26  Phase27  Phase28  Phase29
              Batch    Analytics Config  Validators CLI/Cache Sync   Performance Tests
              ─────────────────────────────────────────────────────────────────────────
Sarah (A)      8/10     7/10     9/10    9/10     8/10     6/10    7/10     8/10
  Lead role:   ✅       ✅       ✅      ✅       ✅       ✅      ✅       ✅

Marcus (B)     9/10     9/10     3/10    4/10     3/10     3/10    9/10     4/10
  Focus:       ✅✅     ✅✅     (A)     (A)      (A)      (A)     ✅✅     (A)

Alex (C)       4/10     9/10     5/10    3/10     9/10     9/10    3/10     3/10
  Focus:       (A)      ✅✅     (A)     (A)      ✅✅     ✅✅     (A)      (A)

Legend: ✅✅ = Strong focus | ✅ = Review/Support | (A) = Lead handles
```

### Coverage Summary
- ✅ All 8 phases have primary owner
- ✅ All phases have secondary reviewer
- ✅ No gaps in coverage
- ✅ Specialties don't conflict
- ✅ All have growth opportunities

---

## WHY THIS IS THE "BALANCED TEAM"

### ✅ Skill Balance
- No overlap (Marcus not doing Sync, Alex not doing Analytics)
- Complementary expertise (Architect + Core Dev + Infrastructure)
- Everyone at expert level in their domain (8-9/10)

### ✅ Communication Balance
- Sarah: Strategic + clear decisions
- Marcus: Detail-oriented + meticulous
- Alex: Pragmatic + hands-on
- *Result*: Different perspectives prevent blind spots

### ✅ Personality Balance
- Sarah: Confident leader
- Marcus: Careful detail-person
- Alex: Pragmatic operator
- *Result*: Good dynamic, no personality conflicts

### ✅ Availability Balance
- All 3 can commit full hours
- No vacation conflicts
- No overlapping major projects
- *Result*: 100% focus for 2 weeks

---

## INTERVIEW RESPONSES (What They Said)

### Sarah Chen (Person A)
**Q: "Tell me about a time you led a technical initiative."**
> "I led the refactoring of our payment processor from monolith to microservices. Took 4 months with a 3-person team. Biggest challenge was maintaining backward compatibility—we used shims extensively. The project resulted in 30% performance improvement and 20% LOC reduction. Taught me how to design big changes incrementally."

**Q: "How do you handle a blocker that needs resolution in 30 minutes?"**
> "First, I listen to understand the real constraint. Is it technical or organizational? Then I involve the right people—maybe Person B, maybe a subject matter expert. I'm comfortable making a decision with 70% information if we need to move. But I always check back after—was the decision right? Could we have handled it differently?"

**Q: "Describe a trade-off decision you made."**
> "In the payment refactoring, we had to choose: (1) Build comprehensive new architecture vs. (2) Incremental refactoring with shims. New architecture was cleaner but riskier. We chose shims—took longer but gave us safety. Worth it. Sometimes shipping is more important than perfection."

### Marcus Johnson (Person B)
**Q: "Show me code you've written that consolidates duplicated logic."**
> "Built the batch payment system. We had 8 different payment processors, each with duplicate queue logic. I created a BatchQueue abstraction that all 8 use now. Reduced duplicated code from 800 LOC to 150 LOC. The key was testing—I added parametrized tests for each processor to ensure nothing broke."

**Q: "How do you ensure tests pass during large refactors?"**
> "I work in small increments. (1) Green tests first. (2) Make change. (3) Run tests immediately. If red, fix before moving on. Never commit with red tests. I also write the test for the new pattern first, then refactor to pass it—test-driven refactoring."

**Q: "What's your experience with batch processing?"**
> "Built a batch payment system processing 10k transactions/day. Learned about queue saturation, executor starvation, when to batch vs. stream. Know about burst handling, backpressure, circuit breakers. This is my domain."

### Alex Patel (Person C)
**Q: "Describe a time you consolidated duplicate shell/Python scripts."**
> "We had 45+ subprocess calls scattered across 12 sync scripts. Built a GitOperations wrapper that all sync scripts use. Reduced subprocess boilerplate from 600 LOC to 80 LOC unified. Added comprehensive error handling so we could see what was failing. Dropped error-debugging time by 50%."

**Q: "What's your experience with git operations and repository sync?"**
> "I built our daily sync orchestration. Manage 15+ repositories, daily syncs, merge conflict handling. Know about git internals—hooks, refs, object database. Understand rebase/merge trade-offs. This is what I do every day."

**Q: "How would you test a consolidated git wrapper?"**
> "I'd mock the git subprocess calls with known outputs, test error paths (broken repo, permission denied, merge conflicts). For integration, I'd use temporary test repos—git init in /tmp, do operations, verify results, clean up. Pragmatic testing—no need for 100% coverage on git internals."

---

## RECOMMENDATION

This team is **ready to execute Phase 22-29 consolidation** immediately because:

1. **Sarah** can architect and lead (9/10 leadership + 9/10 design skills)
2. **Marcus** can build app core phases with confidence (9/10 batching + 9/10 analytics)
3. **Alex** can consolidate infrastructure with expertise (9/10 git + 9/10 CLI)
4. **All three** communicate well and respect each other's expertise
5. **No conflicts** in personality or availability

---

## HOW TO USE THESE PROFILES

### For Your Own Team Selection:

1. **Review each profile** — Note their strengths, growth areas, background
2. **Compare to your candidates** — Who matches these patterns in your org?
3. **Look for similar traits**:
   - Team Lead: Leadership experience + architectural thinking + decision confidence
   - Dev 1: Deep Python + specialty domain knowledge + testing discipline
   - Dev 2: Infrastructure knowledge + pragmatism + systems thinking

4. **Customize the interview responses** — If your candidates say similar things, they might fit

5. **Use the skills matrix** — Rate your actual candidates the same way

---

## ALTERNATIVE CANDIDATES (If These Aren't Available)

### If Sarah isn't available
- Look for: Senior developer with 5+ years, has mentored others, made big decisions
- Must have: 8/10+ Python, 8/10+ architecture thinking, strong communication

### If Marcus isn't available
- Look for: Backend engineer with 4+ years, batch/analytics experience
- Must have: 8/10+ Python, testing discipline, detail-oriented

### If Alex isn't available
- Look for: DevOps/infrastructure engineer, knows git operations, CLI experience
- Must have: 9/10 git/subprocess, infrastructure architecture knowledge

---

**These profiles are templates. Use them to evaluate your actual team. 🚀**
