# Phase 3: Test Module Archival Plan

## Files to Archive

### High Priority (Templates & Phase-Specific)

- `test_phase_release_comprehensive.py` (66.5KB)
  - Type: Phase-specific (reference only)
- `test_parametrized_template.py` (10.6KB)
  - Type: Template/Example
- `test_phase5_sync_scripts.py` (9.5KB)
  - Type: Phase-specific (reference only)

### Medium Priority (Low-Priority Features)

- `test_encryption_utilities_comprehensive.py` (95.7KB)
  - Type: Non-critical feature
- `test_logging_analytics_comprehensive.py` (29.1KB)
- `test_llm_processing_concurrency_comprehensive.py` (22.9KB)
- `test_idempotency_tracker_comprehensive.py` (9.2KB)
- `test_docs_base_generator.py` (6.3KB)
  - Type: Documentation generation (can defer)
- `test_docs_phase_status.py` (5.0KB)
  - Type: Documentation generation (can defer)
- `test_docs_audit_validator.py` (4.0KB)
  - Type: Documentation generation (can defer)
- `test_docs_active_tasks.py` (3.8KB)
  - Type: Documentation generation (can defer)
- `test_docs_link_map.py` (3.0KB)
  - Type: Documentation generation (can defer)

## Archive Structure

```
tests/archive/
├── phase-completed/
│   ├── test_phase5_sync_scripts.py
│   └── test_phase_release_comprehensive.py
├── templates/
│   └── test_parametrized_template.py
└── deferred/
    ├── test_docs_*.py (5 files)
    └── test_*_comprehensive.py (4 files)
```

## Expected Savings

- Files archived: 12
- Size reduction: 265.6KB
- Lines removed: 8,242
- Context reduction: ~20-25% (Phase 3 target)

## Execution Steps

1. Create `tests/archive/` directory structure
2. Move high-priority files to archive/phase-completed/ or archive/templates/
3. Move medium-priority files to archive/deferred/
4. Update .gitignore to exclude archive/ from coverage
5. Run test suite to verify core tests still pass
6. Commit and push
