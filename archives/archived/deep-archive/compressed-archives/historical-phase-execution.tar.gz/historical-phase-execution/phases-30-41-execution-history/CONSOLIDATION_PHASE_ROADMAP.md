# Consolidation Roadmap: Phase 22-26

**Plan Duration**: 2 phases per week (realistic for parallel work)
**Total Timeline**: 2.5-3 weeks for full implementation
**Current Status**: Phase 21 COMPLETE, ready for Phase 22

---

## Phase Summary Matrix

| Phase | Area | Duration | LOC Removed | Impact | Risk | Status |
|-------|------|----------|------------|--------|------|--------|
| 22 | Batch Processing | 1-2h | 1,400-1,600 | HIGH | LOW | 📋 PLANNED |
| 23 | Analytics Framework | 1-2h | 1,200-1,400 | HIGH | MEDIUM | 📋 PLANNED |
| 24 | Configuration | 45-60m | 400-500 | MEDIUM | LOW | 📋 PLANNED |
| 25 | Validators | 1-2h | 1,500-1,800 | HIGH | LOW | 📋 PLANNED |
| 26 | CLI & Cache | 1-2h | 800-1,000 | MEDIUM | MEDIUM | 📋 PLANNED |

**Total Effort**: 5-9 hours | **Total Impact**: 5,300-6,300 LOC | **Overall Reduction**: 60-75% of identified duplication

---

## Phase 22: Batch Processing Consolidation

### Objectives
✅ Consolidate 8 batch modules into unified framework
✅ Establish component-based architecture
✅ Maintain 100% backward compatibility
✅ Achieve 70-80% LOC reduction

### Scope

**Files Involved** (8 files, 1,924 LOC):
- `app/core/batchProcessor.py` (489 LOC)
- `app/core/batchExecutor.py` (281 LOC)
- `app/core/batchSizeOptimizer.py` (257 LOC)
- `app/core/batchStats.py` (208 LOC)
- `app/core/batchExecution.py` (189 LOC)
- `app/core/batchAnalyzer.py` (185 LOC)
- `app/core/batchFormationCache.py` (182 LOC)
- `app/core/batchQueueManager.py` (133 LOC)

### Deliverables

**New Framework** (150-200 LOC):
```
scripts/utils/batching_framework.py
- BaseBatchingStrategy
- BatchComponentRegistry
- BatchingPipeline
```

**Core Components** (~300 LOC):
```
app/core/batchingCore/
├── __init__.py
├── framework.py                    (200 LOC)
└── components/
    ├── analyzer_strategy.py        (80 LOC)
    ├── optimizer_strategy.py       (100 LOC)
    ├── queue_strategy.py           (60 LOC)
    └── executor_engine.py          (120 LOC)
```

**Backward Compatibility** (400-500 LOC shims):
```
app/core/batchingCore/shims/
├── batchProcessor_shim.py         (re-exports)
├── batchExecutor_shim.py          (re-exports)
├── batchStats_shim.py
├── batchAnalyzer_shim.py
├── batchExecution_shim.py
├── batchQueueManager_shim.py
├── batchSizeOptimizer_shim.py
└── batchFormationCache_shim.py
```

### Testing Strategy
1. ✅ Create 20+ component-specific tests
2. ✅ Migrate existing 150+ batch tests to use shims
3. ✅ Verify zero regressions
4. ✅ Performance benchmarks (new vs old)

### Expected Outcomes
- **LOC Removed**: 1,400-1,600 (70-80% of 1,924)
- **New LOC**: 400 (framework + components)
- **Net Reduction**: 1,000-1,200 LOC
- **Test Status**: 150+ tests passing with 0 failures
- **Performance**: Same or better (component isolation)

### Success Criteria
✅ All batch tests pass
✅ No performance regression (< 5% delta)
✅ Zero breaking changes to public API
✅ Shims work for legacy code
✅ Documentation updated

---

## Phase 23: Analytics Framework Consolidation

### Objectives
✅ Consolidate 9 analytics modules into plugin architecture
✅ Unify statistical calculations
✅ Create standardized reporting
✅ Achieve 55-65% LOC reduction

### Scope

**Files Involved** (9 files, 2,153 LOC):
- `app/analytics/logParser.py` (398 LOC)
- `app/analytics/costForecaster.py` (311 LOC)
- `app/analytics/performanceTrendAnalyzer.py` (309 LOC)
- `app/analytics/reportGenerator.py` (281 LOC)
- `app/analytics/metricsAlerts.py` (281 LOC)
- `app/analytics/metricsTimeSeries.py` (268 LOC)
- `app/analytics/base.py` (251 LOC)
- `app/analytics/base_shim.py` (29 LOC)
- `app/analytics/metricsTimeSeries_shim.py` (25 LOC)

### Deliverables

**Unified Statistics** (100-150 LOC):
```
app/analytics/analyticsCore/
├── __init__.py
├── statistics_engine.py           (120 LOC)
│   - mean(), stdev(), trend()
│   - forecast_linear()
│   - detect_anomalies()
└── pipeline.py                    (150 LOC)
    - Data Ingestion Phase
    - Normalization Phase
    - Analysis Phase
    - Reporting Phase
```

**Plugin Analyzers** (300-400 LOC):
```
app/analytics/analyticsCore/
└── analyzers/
    ├── base_analyzer.py           (80 LOC)
    ├── cost_analyzer.py           (120 LOC)
    ├── performance_analyzer.py    (100 LOC)
    ├── log_analyzer.py            (80 LOC)
    └── alerts_analyzer.py         (80 LOC)
```

**Unified Reporting** (80-100 LOC):
```
app/analytics/analyticsCore/
└── reporter.py                    (100 LOC)
    - format_json()
    - format_html()
    - format_alert()
```

### Testing Strategy
1. ✅ Create unified statistics tests (20+)
2. ✅ Migrate analyzer tests (50+)
3. ✅ Create integration tests (15+)
4. ✅ Benchmark: cost forecasting accuracy

### Expected Outcomes
- **LOC Removed**: 1,200-1,400 (55-65% of 2,153)
- **New LOC**: 400-500 (core framework)
- **Net Reduction**: 700-1,000 LOC
- **Test Status**: 85+ tests passing
- **Performance**: Improved (shared utilities)

### Success Criteria
✅ All analytics tests pass
✅ Forecasting accuracy maintained (±2%)
✅ Report generation faster (cached statistics)
✅ Easier to add new analyzers (plugin pattern)

---

## Phase 24: Configuration Consolidation

### Objectives
✅ Unify config loading and caching
✅ Create single API for config access
✅ Eliminate duplicate validation
✅ Achieve 45-50% LOC reduction

### Scope

**Files Involved** (4 core + related):
- `app/core/configLoader.py` (454 LOC)
- `app/core/configUtils.py` (210 LOC)
- `app/core/configCache.py` (265 LOC)
- `app/core/agentConfigCache.py` (305 LOC)
- Related: `scripts/utils/yaml_validator.py`, `scripts/validate/config_validator.py`

### Deliverables

**Unified Configuration Manager** (300-350 LOC):
```
app/core/configManagement/
├── __init__.py
├── manager.py                     (250 LOC)
│   - load_config(path)
│   - get_agent_config(agent_id)
│   - get_section(name)
│   - validate_config()
└── cache.py                       (100 LOC)
    - Uses cacheFramework
```

**Removed Files**:
- `app/core/configCache.py` (consolidated into manager)
- `app/core/agentConfigCache.py` (consolidated into manager)
- `app/core/configUtils.py` (functions merged into manager)

### Migration Steps
1. Create new `manager.py` with unified API
2. Implement using `cacheFramework` + unified validation
3. Create backward-compatible shims for old modules
4. Migrate existing imports (script: `migrate_config.py`)
5. Remove old files after verification

### Expected Outcomes
- **LOC Removed**: 400-500 (45-50% of 929)
- **New LOC**: 300-350 (unified manager)
- **Net Reduction**: 100-200 LOC
- **Test Status**: 30+ tests passing
- **API**: Single import point

### Success Criteria
✅ All config tests pass
✅ Agent config loads correctly
✅ Cache behavior unchanged
✅ Validation consistent

---

## Phase 25: Validator Framework Enhancement

### Objectives
✅ Create unified validator base
✅ Standardize result formatting
✅ Implement batch validation
✅ Achieve 45-55% LOC reduction

### Scope

**Files Involved** (12 validators, 3,529 LOC):
- Group by domain:
  - **Config Validators**: config, consistency, semantic (1,090 LOC)
  - **Doc Validators**: links, dead code, drift (710 LOC)
  - **Security Validators**: OWASP, API consistency (1,195 LOC)
  - **Skill Validators**: registry, redundancy (534 LOC)

### Deliverables

**Enhanced Base Class** (150-200 LOC):
```
scripts/validate/base.py (extend from 74 to 250 LOC)
- BaseValidator class improvements
- StandardResult dataclass
- ResultFormatter with templates
- SeverityLevel enum
- BatchValidationOrchestrator
```

**Validator Groups** (900-1,000 LOC):
```
scripts/validate/
├── validators/
│   ├── config_validators.py       (300 LOC)
│   │   - ConfigValidator
│   │   - ConfigConsistencyValidator
│   │   - SemanticValidator
│   ├── doc_validators.py          (200 LOC)
│   │   - LinkValidator
│   │   - DeadCodeDetector
│   │   - DriftDetector
│   ├── security_validators.py     (300 LOC)
│   │   - OWASPAuditValidator
│   │   - APIConsistencyValidator
│   └── skill_validators.py        (200 LOC)
│       - SkillRegistryValidator
│       - RedundancyDetector
└── orchestrator.py                (150 LOC)
    - BatchValidationOrchestrator
```

### Testing Strategy
1. ✅ Create unified result tests (25+)
2. ✅ Migrate validator tests (100+)
3. ✅ Create batch validation tests (20+)
4. ✅ Verify result consistency

### Expected Outcomes
- **LOC Removed**: 1,500-1,800 (45-50% of 3,529)
- **New LOC**: 900-1,000 (organized groups + enhancements)
- **Net Reduction**: 500-900 LOC
- **Test Status**: 145+ tests passing
- **DX**: Easier to add validators, consistent reporting

### Success Criteria
✅ All validators working
✅ Result format consistent (JSON schema)
✅ Batch validation 10+ times faster
✅ New validators easier to write

---

## Phase 26: CLI & Cache Consolidation

### Objectives
✅ Unify CLI command handling
✅ Complete cache framework migration
✅ Achieve 35-40% LOC reduction
✅ Finalize Phase 25 work

### Scope

**Files Involved**:
- CLI: 8 files (1,481 LOC)
- Cache: 7 files (1,147 LOC)

### Deliverables

**CLI Command Builder** (150-200 LOC):
```
scripts/cli/
├── command_builder.py             (150 LOC)
│   - CommandBuilder class
│   - StandardArguments
│   - OutputFormatter
└── shims/ (4-5 shim files)
```

**Cache Framework Migration** (200-300 LOC):
```
app/core/
├── cacheFramework/ (already exists)
│   └── factory.py                 (100 LOC)
│       - get_cache(type)
│       - ConfigCache factory
│       - ResponseCache factory
└── remove: old cache files
    - configCache.py (replaced)
    - responseCache.py (replaced)
    - cacheBase.py (deprecated)
    - cacheBase_shim.py (deprecated)
```

### Expected Outcomes
- **LOC Removed**: 800-1,000
- **New LOC**: 300-400
- **Net Reduction**: 500-700 LOC
- **CLI DX**: Consistent, standardized commands
- **Cache System**: Unified, performant

### Success Criteria
✅ All CLI commands work
✅ All cache tests pass
✅ Performance consistent
✅ Interface clean and simple

---

## Consolidated Impact Summary

### Phase-by-Phase Progress

| Phase | Start | End | Net Change | Cumulative |
|-------|-------|-----|-----------|-----------|
| 21 | 10,400 LOC (baseline) | ~9,000 | -1,400 | 9,000 |
| 22 | 9,000 | 7,900 | -1,100 | 7,900 |
| 23 | 7,900 | 7,000 | -900 | 7,000 |
| 24 | 7,000 | 6,800 | -200 | 6,800 |
| 25 | 6,800 | 6,200 | -600 | 6,200 |
| 26 | 6,200 | 5,500 | -700 | **5,500** |

**Overall Achievement**: 47% codebase reduction (10,400 → 5,500 LOC in affected areas)

### Key Metrics by Phase

| Phase | Tests | Coverage | Regressions | Risk Level |
|-------|-------|----------|-------------|-----------|
| 22 | 150+ | 95%+ | 0 | 🟢 LOW |
| 23 | 85+ | 92%+ | 0 | 🟡 MEDIUM |
| 24 | 30+ | 95%+ | 0 | 🟢 LOW |
| 25 | 145+ | 90%+ | 0 | 🟢 LOW |
| 26 | 100+ | 92%+ | 0 | 🟡 MEDIUM |

---

## Resource Allocation

### Recommended Schedule

**Week 1**:
- Phase 22 (Batch) - High impact, low risk
- Phase 24 (Config) - Quick win for foundation

**Week 2**:
- Phase 23 (Analytics) - High impact, medium risk
- Phase 25 (Validators) - High impact, low risk

**Week 3**:
- Phase 26 (CLI/Cache) - Finalization
- Testing & verification
- Documentation updates

### Parallel Work Opportunities
- Phases 22 & 24 can run in parallel (independent)
- Phases 23 & 25 can run in parallel (independent)
- Phase 26 depends on earlier work

### Person-Hours Estimate
- **Phase 22**: 1.5 hours
- **Phase 23**: 1.5 hours
- **Phase 24**: 1 hour
- **Phase 25**: 1.5 hours
- **Phase 26**: 1.5 hours
- **Overhead**: 1 hour (testing, documentation)
- **Total**: 8 hours concentrated effort

---

## Risk Assessment

### Technical Risks

| Risk | Probability | Impact | Mitigation |
|------|-------------|--------|-----------|
| API Breaking | LOW | HIGH | Comprehensive shims (30% effort) |
| Test Failures | MEDIUM | MEDIUM | Pre-consolidation refactoring |
| Performance | LOW | MEDIUM | Benchmarking before/after |
| Migration Issues | MEDIUM | LOW | Automated migration scripts |

### Mitigation Strategy
1. ✅ Create comprehensive test coverage first
2. ✅ Build shims before removing old code
3. ✅ Validate migrations with automated scripts
4. ✅ Benchmark critical paths

---

## Success Criteria

### Per-Phase
- ✅ All tests passing (0 regressions)
- ✅ Code coverage ≥85%
- ✅ Performance delta < ±5%
- ✅ Backward compatibility maintained
- ✅ Documentation updated

### Overall
- ✅ 5,000-6,000 LOC consolidated
- ✅ 40-50% reduction in identified duplication areas
- ✅ 0 regressions across 1,611+ tests
- ✅ Improved developer experience
- ✅ Foundation for Phase 27+ improvements

---

## Next Steps

### Immediate (Week 1)
1. ✅ Review this roadmap with team
2. ✅ Begin Phase 22 scoping
3. ✅ Set up parallel work streams

### Short-term (Week 2-3)
1. ✅ Execute Phase 22-26
2. ✅ Verify zero regressions
3. ✅ Update documentation

### Future (Phase 27+)
- Test utility consolidation (Area 7)
- Performance optimization using new frameworks
- Extension framework documentation
- Automation tooling for future consolidations

---

**Roadmap Created**: 2026-09-03
**Target Timeline**: 2.5-3 weeks
**Status**: 📋 Ready for Execution
**Approval Needed**: Review & signoff before Phase 22 start
